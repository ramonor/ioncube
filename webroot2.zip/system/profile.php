<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


require('../includes/core/includes/user/session.inc.php');
require('../includes/config.inc.php');

$GameCP->CheckPermissions('profile');

$GameCP->SetURLCookie();

$smarty->assign('page_title', $LNG_CLIENTMANAGEMENT);

$idd=$_SESSION['gamecp']['userinfo']['id'];

if($mode == "cancel" && DEMO != "yes"){
	if ($_SESSION['gamecp']['userinfo']['ulevel'] != "0") { 
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$Panel->ErrorExit("Invalid access");
	}

	$GameCP->loadIncludes("suspend");
	$Suspend=new Suspend();
	$Suspend->User($idd);

	sql_query($safesql->query("INSERT INTO ttsystem SET 
		title='Server Canceled.', 
		subject='Server Canceled.',
		date='$todaysTimestamp',
		updated='".time()."',
		cid='%i', 
		status='Open', 
		resolved='No', 
		message='This user has canceled their server ".date(dateformat, time()).". It has been shut-down and suspended.', 
		reply='', summary='Server Canceled.'", array($idd))) or die(mysql_error());

	sql_query($safesql->query("UPDATE billing B, userbills UB SET B.status = 'Canceled' WHERE B.cid='%i' AND UB.bid = B.id", array($idd))) or die(mysql_error());

	echo $LNG_CANCELACCOUNTFINAL;
}

if ($mode == "update" && DEMO != "yes") {	
	if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes"){	
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$Panel->ErrorExit("You do not have permission to view this location"); 
	}

	if(clientchangemail != '1'){
		sql_query($safesql->query("UPDATE users SET  email = '%s' WHERE id = '%i'", array(
			$GameCP->whitelist($femail, "useredit"),
			$GameCP->whitelist($idd, "int")
		)))  or die(mysql_error()); 
		if($femail) $_SESSION['gamecp']['userinfo']['email']=$GameCP->whitelist($femail, "useredit");
	}

	sql_query($safesql->query("UPDATE users SET 
		smsaddress = '%s', 
		clan = '%s',  
		phone = '%s', 
		address = '%s', 
		city = '%s', 
		state = '%s', 
		country = '%s', 
		zip = '%s',
		website = '%s',
		firstname = '%s',
		lastname = '%s',
		address2 = '%s',
		payment = '%s',
		signature = '%s',
		location = '%s',
		lang = '%s'
	WHERE id = '%i'", array(
		$GameCP->whitelist($smsaddress, "useredit"),
		$GameCP->whitelist($clan, "useredit"),
		$GameCP->whitelist($phone, "useredit"),
		$GameCP->whitelist($address, "useredit"),
		$GameCP->whitelist($city, "useredit"),
		$GameCP->whitelist($state, "useredit"),
		$GameCP->whitelist($country, "useredit"),
		$GameCP->whitelist($zip, "useredit"),
		$GameCP->whitelist($clienturl, "useredit"),
		$GameCP->whitelist($firstname, "useredit"),
		$GameCP->whitelist($lastname, "useredit"),
		$GameCP->whitelist($address2, "useredit"),
		$GameCP->whitelist($payment, "useredit"),
		$GameCP->whitelist($signature, "useredit"),
		$GameCP->whitelist($location, "useredit"),
		$GameCP->whitelist($_REQUEST['lang'], "useredit"),
		$GameCP->whitelist($idd, "int")
	)))  or die(mysql_error()); 

	echo "Saved";

	/* reset their session for what we typically see - could use name etc or a cleanr session cache */
	if($_REQUEST['lang']) $_SESSION['gamecp']['lang']=$GameCP->whitelist($_REQUEST['lang'], "useredit");

}

if($mode =="changepw" && DEMO != "yes") { 
	$GameCP->loadIncludes("user");
	$User=new User();
	$User->ChangePassword($idd, $_POST['pass']);
	$mode="edit2";
} 

if($mode == "edit2" || !$mode){
	$GameCP->loadIncludes("user");
	$User=new User();
	$User->Profile($idd, true);
}

?>