<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

require('../includes/core/includes/user/session.inc.php');
require('../includes/config.inc.php');

if(!isset($mode)) $mode="editconfigs";

$GameCP->CheckPermissions('configs');

$GameCP->SetURLCookie();

$smarty->assign('page_title', $LNG_USERGAMEMANAGEMENT);

if(isset($_REQUEST['ugid']))$_REQUEST['ugid']=$GameCP->whitelist($_REQUEST['ugid'], "int");
if(isset($_REQUEST['cfid']))$_REQUEST['cfid']=$GameCP->whitelist($_REQUEST['cfid'], "int");

if(!empty($_GET)) extract($_GET, EXTR_SKIP);
if(!empty($_POST)) extract($_POST, EXTR_SKIP);

if(!isset($ugid) && isset($_SESSION['gamecp']['user']['browseGame'])) $ugid=$_SESSION['gamecp']['user']['browseGame'];

function GetBuilderConfig($builderid, $ugid){
	global $GameCP, $safesql;

	$GameCP->loadIncludes("panel");
	$Panel=new Panel();

	$builders=$Panel->FetchMultiArray($safesql->query("SELECT * FROM config_builderitems WHERE builderid='%i' ORDER BY rank ASC", array($GameCP->whitelist($builderid, 'int'))));
	
	$saved=array();
	$edited=$Panel->FetchMultiArray($safesql->query("SELECT itemid, value FROM config_buildersave WHERE ugid='%i' AND builderid='%i'", array($GameCP->whitelist($ugid, 'int'), $GameCP->whitelist($builderid, 'int'))));
	foreach($edited as $d) $saved[$d['itemid']]=$d['value'];

	$builder=array();
	foreach($builders as $b => $d){
		if($d['type'] == 'select' || $d['type'] == 'multiselect' || $d['type'] == 'radio' || $d['type'] == 'checkbox'){
			$d['value']=explode(',',$d['value']);
			$default = is_array($d['value']) ? $d['value'][0] : $d['value'];
		} else $default='';

		if(isset($saved[$d['id']]) && $d['editable'] == '1'){
			if($d['type'] == "input" || $d['type'] == "textarea" || $d['type'] == "hidden"){
				$d['value']=$saved[$d['id']];
			} elseif($d['type'] == "quantity"){
				$d['value']=$GameCP->whitelist($saved[$d['id']], 'int');
			} elseif($d['type'] == 'select'){
				if($saved[$d['id']]){
					$d['selected']=$saved[$d['id']];
				} else $d['selected']=$default;
			} elseif($d['type'] == 'multiselect' || $d['type'] == 'select' || $d['type'] == 'checkbox' || $d['type'] == 'insert'){
				if($saved[$d['id']]){
					$d['selected']=@unserialize($saved[$d['id']]);
				} else $d['selected']=$default;
				if(!is_array($d['selected'])) $d['selected']=array();
			} elseif($d['type'] == 'radio'){
				$d['selected']=$saved[$d['id']];
			}
		}
		
		$builder[]=$d;
	}
	return $builder;
}

function SetUGDetails($ugid){
	global $GameCP, $safesql, $smarty, $sqlA;
	$gnameQ=sql_query($safesql->query("SELECT G.id, U.name, U.id, UG.ip, UG.port FROM game G, usergames UG, users U WHERE U.id=UG.cid AND G.id=UG.gid AND UG.id='%i' $sqlA LIMIT 1", array($GameCP->whitelist($ugid, "int")))) or die(mysql_error());
	$gname=mysql_fetch_row($gnameQ);
	$smarty->assign("ggid", $gname[0]);
	$smarty->assign("fname", $gname[1]);
	$smarty->assign("cid", $gname[2]);
	$smarty->assign("fip", $gname[3]);
	$smarty->assign("fport", $gname[4]);
}

if(isset($_REQUEST['cfid'])){
	$configOwnerQ=sql_query($safesql->query("SELECT UG.id, UG.cid FROM usergames UG, userconfigs UC WHERE UG.id = UC.ugid AND UC.id = '%i' LIMIT 1;",
	array($GameCP->whitelist($_REQUEST['cfid'], "int")))) or die(mysql_error());
	$configDetails=mysql_fetch_array($configOwnerQ);
	$_REQUEST['ugid']=$configDetails['id'];
}

if(isset($_REQUEST['ugid']) || isset($_SESSION['gamecp']['user']['browseGame']) && $_SESSION['gamecp']['user']['browseGame']){
	if(!isset($_REQUEST['ugid'])) $_REQUEST['ugid']= $_SESSION['gamecp']['user']['browseGame'];
	$GameCP->UserGameAccess($_REQUEST['ugid'], "configs");
} else {
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("Missing service id");
}

if($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
	$sqlB=" AND cid=".$_SESSION['gamecp']['userinfo']['id'];
	$sqlA=" AND UG.cid=".$_SESSION['gamecp']['userinfo']['id'];
	$sqlC="";
} else {
	if(!isset($edittype)) $edittype="";
	$sqlA="";
	$sqlB="";
	$sqlC=", edittype='$edittype'";
}

if($mode == "builder" && DEMO != "yes") { 
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$userGameDetails=$Panel->GetUserGame($ugid);

	SetUGDetails($ugid);


	$builder=GetBuilderConfig($builderid, $ugid);
	$smarty->assign("builders", $builder);
	$smarty->assign("gameInfo", $userGameDetails);
	$smarty->display("configbuilder/userbuilder-edit.tpl");
}

if($mode == "builderedit" && DEMO != "yes") { 
	if(is_array($_REQUEST['edited'])){
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$builders=$Panel->FetchMultiArray($safesql->query("SELECT * FROM config_builderitems WHERE builderid='%i' ORDER BY rank ASC", array($GameCP->whitelist($builderid, 'int'))));
		$builder=array();
		foreach($builders as $d) $builder[$d['id']]=$d['editable'];
		$regexps=array();
		foreach($builders as $d) $regexps[$d['id']]=$d['regexp'];
		$denychars=array();
		foreach($builders as $d) $denychars[$d['id']]=$d['denychars'];
		
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		sql_query($safesql->query("DELETE FROM config_buildersave WHERE ugid='%i' AND builderid='%i';", array($GameCP->whitelist($ugid, 'int'),$GameCP->whitelist($builderid, 'int'))))or die(mysql_error());

		foreach($_REQUEST['edited'] as $id => $data){
			if(isset($builder[$id])){
				if(is_array($data)){
					if(isset($regexps[$id]) && $regexps[$id] != ''){
						foreach($data as $d=>$a) {
							if(!preg_match($regexps[$id], $data[$d])) unset($data[$d]);
						}
					}
					if(isset($denychars[$id]) && $denychars[$id] != ''){
						foreach($data as $d=>$a) {
							$data[$d]=preg_replace($denychars[$id], '', $data[$d]);
						}
					}
					
					$data=serialize($data);
				} else {
					$data=$GameCP->whitelist($data, 'clean');
					if(isset($regexps[$id]) && $regexps[$id] != ''){
						if(!preg_match($regexps[$id], $data)) unset($data);
					}
					if(isset($denychars[$id]) && $denychars[$id] != ''){
						$data=preg_replace($denychars[$id], '', $data);
					}
				}
				
				if(isset($data)) sql_query($safesql->query("INSERT INTO config_buildersave SET ugid='%i', builderid='%i', itemid='%i', value='%s'", array($GameCP->whitelist($ugid, 'int'),$GameCP->whitelist($builderid, 'int'), $GameCP->whitelist($id, 'int'), $data)))or die(mysql_error());
			}
		}
	}

	$mode = "builderrun";
}

if($mode == "builderrun" && DEMO != "yes") { 
	$confQ=sql_query($safesql->query("SELECT UC.name, UC.config, UC.contents, G.name, UG.id, UC.configdir, UC.hidecfg FROM userconfigs UC, usergames UG, game G WHERE UC.id='%i' AND G.id=UG.gid AND UG.id=UC.ugid $sqlA LIMIT 1", array($GameCP->whitelist($cfid, "int")))) or die(mysql_error());
	$conf=mysql_fetch_row($confQ);
	if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($conf[4], $_SESSION['gamecp']['subuser']['games'])) exit;
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "0" && isset($cfg) && $cfg['hidecfg'] == "1"){
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$Panel->ErrorExit("You do not have permission to view this page.");
	}

	$gameDetails=$Panel->GetUserGame($conf[4]);
	$smarty->assign("gameInfo", $gameDetails);

	$smarty->assign("fconfigdir", $conf[5]);
	$smarty->assign("fconfig", $conf[1]);
	$smarty->assign("builderid", $builderid);
	$smarty->assign("cfid", $cfid);
	$smarty->assign("ugid", $ugid);

	$smarty->display("manageuserconfigs/executecb-conf.tpl");
}

if($mode == "builderrunconfirm" && DEMO != "yes") { 
	if(isset($_REQUEST['doityes'])){
		$confQ=sql_query($safesql->query("SELECT UC.name, UC.config, UC.contents, G.name, UG.id, UC.configdir, UC.hidecfg FROM userconfigs UC, usergames UG, game G WHERE UC.id='%i' AND G.id=UG.gid AND UG.id=UC.ugid $sqlA LIMIT 1", array($GameCP->whitelist($cfid, "int")))) or die(mysql_error());
		$conf=mysql_fetch_array($confQ);
		if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($conf[4], $_SESSION['gamecp']['subuser']['games'])) exit;
		if($_SESSION['gamecp']['userinfo']['ulevel'] == "0" && $conf['hidecfg'] == "1"){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->ErrorExit("You do not have permission to view this page.");
		}

		$configbuilder=GetBuilderConfig($builderid, $ugid);
		$config='';
		foreach($configbuilder as $c => $fg){
			$val='';
			if(isset($fg['selected'])){
				$check=$fg['selected'];
			} else $check=$fg['value'];

			if(is_array($check)){

				if($fg['type'] == 'checkbox'){
					$checka=array();
					foreach($fg['value'] as $v => $u) $checka[$u]=$fg['offval'];
					$check=array_merge($checka, $check);
				}

				$val='';
				foreach($check as $da) $val.=$da.$fg['delimiter'];	
				$val=rtrim($val, $fg['delimiter']);

			} elseif($fg['type'] != 'insert') $val=$check;


			$config.=$fg['cvar'].' '.$fg['seperator'].' '.$fg['prefix'].$val.$fg['suffix']."\n";
		}

		$GameCP->loadIncludes("game");
		$Game=new Game();
		$Game->ConfigCreate($ugid, $cfid, false, false, false, $config);

		if(isset($restart) && $restart == "yes"){
			$GameCP->loadIncludes("control");
			$Control=new Control();
			$Control->Usergame($ugid, "restart");
		}

		$smarty->assign("showSaved", true);
	}
	$mode="editconfigs";
}

/* ADD CONFIG */
if($mode == "add" && DEMO != "yes") { 
	if(!isset($hideusercfg)) $hideusercfg="0";
	if(!isset($autoexec)) $autoexec="0";
	if(!isset($editable)) $editable="0";
	if(!isset($configbuilder)) $configbuilder="0";

	if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($ugid, $_SESSION['gamecp']['subuser']['games'])) exit;
	sql_query($safesql->query("INSERT INTO userconfigs SET 
		name='%s',
		config='%s',
		contents='%s',
		ugid='%i',
		autoexec='%i',
		hidecfg='%i',
		editable='%i',
		configbuilder='%i',
		configdir='%s'
		$sqlC", 
		array($GameCP->whitelist($fname, "useredit"),
			$GameCP->whitelist(str_replace('..','',$fconfig), "useredit"),
			$GameCP->whitelist($fcontents, "web"),
			$GameCP->whitelist($ugid, "int"),
			$GameCP->whitelist($autoexec, "useredit"),
			$GameCP->whitelist($hideusercfg, "useredit"),
			$GameCP->whitelist($editable, "int"),
			$GameCP->whitelist($configbuilder, "int"),
			$GameCP->whitelist(str_replace('..','',$fconfigdir), "useredit")))) or die(mysql_error());

	
	$cfid=mysql_insert_id();
	$_REQUEST['cfid']=$cfid;
	$mode="execute";
}

/* UPDATE CONFIG */
if($mode == "update" && DEMO != "yes") { 
	if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($ugid, $_SESSION['gamecp']['subuser']['games'])) exit;
	if(!isset($hideusercfg)) $hideusercfg="0";
	if(!isset($autoexec)) $autoexec="0";
	if(!isset($editable)) $editable="0";
	if(!isset($cfgid)) $cfgid="0";
	if(!isset($configbuilder)) $configbuilder="0";
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
		sql_query($safesql->query("UPDATE userconfigs SET 
			name='%s',
			config='%s',
			contents='%s',
			configdir='%s'
			WHERE id='%i'", array($GameCP->whitelist($fname, "useredit"),
			$GameCP->whitelist(str_replace('..','',$fconfig), "useredit"),
			$GameCP->whitelist($fcontents, "web"),
			$GameCP->whitelist(str_replace('..','',$fconfigdir), "useredit"),
			$GameCP->whitelist($cfid, "useredit")
			))) or die(mysql_error());
	} else sql_query($safesql->query("UPDATE userconfigs SET 
			name='%s',
			config='%s',
			contents='%s',
			ugid='%i',
			configdir='%s',
			edittype='%s',
			autoexec='%i',
			fencoding='%s',
			editable='%i',
			cfgid='%i',
			configbuilder='%i',
			hidecfg='%i' WHERE id='%i'", array($GameCP->whitelist($fname, "useredit"),
			$GameCP->whitelist(str_replace('..','',$fconfig), "useredit"),
			$GameCP->whitelist($fcontents, "web"),
			$GameCP->whitelist($ugid, "int"),
			$GameCP->whitelist(str_replace('..','',$fconfigdir), "useredit"),
			$GameCP->whitelist($edittype, "useredit"),
			$GameCP->whitelist($autoexec, "useredit"),
			$GameCP->whitelist($fencoding, "useredit"),
			$GameCP->whitelist($editable, "int"),
			$GameCP->whitelist($cfgid, "int"),
			$GameCP->whitelist($configbuilder, "int"),
			$GameCP->whitelist($hideusercfg, "useredit"),
			$GameCP->whitelist($cfid, "useredit")
				))) or die(mysql_error());

		//$mode="editconfigs";
		$mode="execute";
}

/* EXECUTE CONFIG CONFIRM DIALOG */
if($mode == "execute") { 

	$GameCP->loadIncludes("panel");
	$Panel=new Panel();

	$confQ=sql_query($safesql->query("SELECT UC.name, UC.config, UC.contents, G.name, UG.id, UC.configdir, UC.hidecfg FROM userconfigs UC, usergames UG, game G WHERE UC.id='%i' AND G.id=UG.gid AND UG.id=UC.ugid $sqlA LIMIT 1", array($GameCP->whitelist($cfid, "int")))) or die(mysql_error());
	$conf=mysql_fetch_row($confQ);
	if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($conf[4], $_SESSION['gamecp']['subuser']['games'])) exit;
		if($_SESSION['gamecp']['userinfo']['ulevel'] == "0" && $cfg['hidecfg'] == "1"){
			$Panel->ErrorExit("You do not have permission to view this page.");
		}

	$gameDetails=$Panel->GetUserGame($conf[4]);
	$smarty->assign("gameInfo", $gameDetails);

	
	$smarty->assign("cfid", $cfid);
	$smarty->assign("ugid", $conf[4]);
	$smarty->assign("fconfigdir", $conf[5]);
	$smarty->assign("fconfig", $conf[1]);
	$smarty->assign("fname", $conf[0]);

	$smarty->display("manageuserconfigs/execute-conf.tpl");
}
/* END EXECUTE CONFIG  CONFIRM DIALOG*/

/* DO EXECUTION */
if($mode == "executeconfirm" && DEMO != "yes"){
	
	$smarty->assign("showSaved", true);
		if(isset($_REQUEST['doityes'])){

			$sidQ = sql_query($safesql->query("SELECT S.sid, G.installfile, S.os, G.id, S.winport, UG.ip, UG.port, UG.maxplayers, UG.rconpass, U.id, U.name, UG.sci, UG.subdirectory FROM servers S, game G, usergames UG, iptable I, users U WHERE U.id = UG.cid AND UG.ip = I.ip AND I.sid = S.sid AND UG.gid = G.id AND UG.id='%i' $sqlA LIMIT 1", array($GameCP->whitelist($ugid, "int")))) or die(mysql_error());
			$query=mysql_fetch_row($sidQ);


			$confQ=sql_query($safesql->query("SELECT
			UC.name, UC.config, UC.contents, G.name, UG.id, UC.configdir, UC.hidecfg, UC.editable
				FROM userconfigs UC, usergames UG, game G
			WHERE UC.id='%i' 
			AND G.id=UG.gid
			AND UG.id=UC.ugid $sqlA
			LIMIT 1", array($GameCP->whitelist($cfid, "int")))) or die(mysql_error());
			$cfg=mysql_fetch_array($confQ);
			if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($cfg[4], $_SESSION['gamecp']['subuser']['games'])) exit;
			if($_SESSION['gamecp']['userinfo']['ulevel'] == "0" && ($cfg['hidecfg'] == "1" || $cfg['editable'] != "1")){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				$Panel->ErrorExit("You do not have permission to view this page.");
			}


			$sid=$query[0];
			$installFile=$query[1];
			$os=$query[2];
			$gid=$query[3];
			$winport=$query[4];
			$fip=$query[5];
			$fport=$query[6];
			$fmaxclients=$query[7];
			$RCONPASSWORD=$query[8];
			$foname=$query[10];
			$sci=$query[11];
			$cid=$query[9];
			
			$subdir=$query[12];
		
			$fconfig=$cfg['config'];

			if(!$fconfig) return false;

			if(isset($makedefault) && $makedefault == "yes") sql_query($safesql->query("UPDATE `usergames` SET `config`='%s' WHERE id='%i'", array($fconfig, $GameCP->whitelist($ugid))));
			
			$GameCP->loadIncludes("control");
			$GameCP->loadIncludes("game");
			$Control=new Control();
			$Game=new Game();

			$Control->Build($ugid, "update"); 
			$Game->ConfigCreate($ugid, $cfid);
			
			if(isset($restart) && $restart == "yes") $Control->Usergame($ugid, "restart");
			
			$mode="editconfigs";

		} else $mode="editconfigs";
}
/* END DO EXECUTION */

/* REMOVE CONFIG */
if($mode == "remove") { 
		$confQ=sql_query($safesql->query("SELECT UC.name, UC.config, UC.contents, G.name, UG.id, UC.configdir FROM userconfigs UC, usergames UG, game G WHERE UC.id='%i' AND G.id=UG.gid AND UG.id=UC.ugid $sqlA LIMIT 1", array($GameCP->whitelist($cfid, "int")))) or die(mysql_error());
		$conf=mysql_fetch_row($confQ);
		if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($conf[4], $_SESSION['gamecp']['subuser']['games'])) exit;

		$gameDetails=$Panel->GetUserGame($conf[4]);
		$smarty->assign("gameInfo", $gameDetails);
	
		$smarty->assign("cfid", $cfid);
		$smarty->assign("ugid", $conf[4]);
		$smarty->assign("fconfigdir", $conf[5]);
		$smarty->assign("fconfig", $conf[1]);
		$smarty->assign("fname", $conf[0]);

		$smarty->display("manageuserconfigs/remove-conf.tpl");
}

if($mode == "removeconfirm" && DEMO != "yes"){
		$confQ=sql_query($safesql->query("SELECT
		UC.name, UC.config, UC.contents, G.name, UG.id, UC.configdir, UC.hidecfg, UC.cfgid
			FROM userconfigs UC, usergames UG, game G
		WHERE UC.id='%i' 
		AND G.id=UG.gid
		AND UG.id=UC.ugid
		$sqlA
		LIMIT 1", array($GameCP->whitelist($cfid, "int")))) or die(mysql_error());

		if(mysql_num_rows($confQ) == '0'){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->ErrorExit("Configuration already removed.");
		}

		$cfg=mysql_fetch_array($confQ);

		$configid=$cfg['cfgid'];

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($cfg[4], $_SESSION['gamecp']['subuser']['games'])) exit;
		
		if($_SESSION['gamecp']['userinfo']['ulevel'] == "0" && $cfg['hidecfg'] == "1"){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->ErrorExit("You do not have permission to view this page.");
		}

		$userGameDetails=$Panel->GetUserGame($cfg[4]);
		$serverDetails=$Panel->GetServer('', $userGameDetails['ip']);

		$os=$serverDetails['os'];
		$sid=$serverDetails['sid'];
		$fname=$userGameDetails['username'];


		if($userGameDetails['subdirectory'] == "yes"){ 
			if(ipsubdir == "true"){
				$thesubdir=$userGameDetails['ip']."-".$userGameDetails['port']."/";
			} else $thesubdir="service".$cfg[4]."/";
		}

		$fullpath="/home/$fname/$thesubdir".str_replace('..','',$cfg['configdir'])."/".str_replace('..','',$cfg['config']);
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		if(isset($delfile) && $delfile=="yes"){
			if($os == "1"){
				$fullpath=str_replace("/", "\\", $fullpath);
				$fullpath=str_replace(":_:", " ", $fullpath);
				$Backend->QueryResponse($sid, $winport, "deletefile:_:\$MAINDIR$fullpath");
			} else $Backend->QueryResponse($sid, $winport, "deletefile:_:$fullpath", $fname);
		}

		sql_query($safesql->query("DELETE FROM userconfigs WHERE id = '%i' LIMIT 1", array($GameCP->whitelist($cfid, "int")))) or die(mysql_error()); 
		sql_query($safesql->query("DELETE FROM config_buildersave WHERE builderid = '%i' AND ugid='%i'", array($GameCP->whitelist($configid, "int"), $GameCP->whitelist($cfg[4], "int")))) or die(mysql_error()); 
	
	$smarty->assign("showSaved", true);
		
	$mode="editconfigs";
}

/* NEW CONFIG */
if($mode == "new") { 
	if(!$ugid) die("Error: Missing user game id");
	$_SESSION['gamecp']['user']['browseGame']=$GameCP->whitelist($ugid, "int");

	$gnameQ=sql_query($safesql->query("SELECT G.name, G.id FROM game G, usergames UG WHERE G.id=UG.gid AND UG.id='%i' $sqlA LIMIT 1", array($GameCP->whitelist($ugid, "int")))) or die(mysql_error());
	$gname=mysql_fetch_row($gnameQ);
	$gid=$gname[1];

	$cfgQ=sql_query($safesql->query("SELECT configdir, configfile, config FROM gameconfigs WHERE gid='%i' AND install='1' AND defaultconfig='1' LIMIT 1", array($GameCP->whitelist($gid, "int")))) or die(mysql_error());
	$cfg=mysql_fetch_row($cfgQ);
	
	if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($ugid, $_SESSION['gamecp']['subuser']['games'])) exit;
	$smarty->assign("ugid", $ugid);
	$smarty->assign("gname", $gname[0]);
	$smarty->assign("fconfig", $cfg[1]);
	$smarty->assign("fconfigdir", $cfg[0]);
	$smarty->assign("fcontents", $cfg[2]);
	$smarty->assign("subMode", "add");


	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$userGameDetails=$Panel->GetUserGame($ugid);
	$serverDetails=$Panel->GetServer('', $userGameDetails['ip']);
	
	$smarty->assign("gameInfo", $userGameDetails);

	$fname=$userGameDetails['username'];

	$smarty->assign("fip", $userGameDetails['ip']);
	$smarty->assign("fport", $userGameDetails['port']);

	$smarty->assign("fname", $GameCP->whitelist("Config". time(), "useredit"));


	$smarty->display("manageuserconfigs/manageuserconfigs.tpl");
}	
/* END NEW CONFIG */

/* EDIT CONFIG */
if($mode == "edit") { 

	$confQ=sql_query($safesql->query("SELECT
		UC.name, UC.config, UC.contents, G.name, UG.id, UC.configdir, UC.edittype, UC.hidecfg, UC.autoexec, UC.fencoding, UC.editable, UC.configbuilder, UC.cfgid, G.id as 'gid'
			FROM userconfigs UC, usergames UG, game G
		WHERE UC.id='%i' 
		AND G.id=UG.gid
		AND UG.id=UC.ugid
		$sqlA
		LIMIT 1", array($GameCP->whitelist($cfid, "int")))) or die(mysql_error());
		$cfg=mysql_fetch_array($confQ);

		if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($cfg[4], $_SESSION['gamecp']['subuser']['games'])) exit;
		if($_SESSION['gamecp']['userinfo']['ulevel'] == "0" && $cfg['hidecfg'] == "1"){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->ErrorExit("You do not have permission to view this page.");
		}

		/* beta code to read real file */
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$userGameDetails=$Panel->GetUserGame($cfg[4]);
		$serverDetails=$Panel->GetServer('', $userGameDetails['ip']);

	
		$smarty->assign("gameInfo", $userGameDetails);


		$os=$serverDetails['os'];
		$sid=$serverDetails['sid'];
		$fname=$userGameDetails['username'];


		if($userGameDetails['subdirectory'] == "yes"){ 
			if(ipsubdir == "true"){
				$thesubdir=$userGameDetails['ip']."-".$userGameDetails['port']."/";
			} else $thesubdir="service".$cfg[4]."/";
		} else $thesubdir="";

		if($cfg['config']){
			$fullpath="/home/$fname/$thesubdir".str_replace('..','',$cfg['configdir'])."/".str_replace('..','',$cfg['config']);

			$GameCP->loadIncludes("backend");
			$Backend=new Backend();

			$content="";
			if($cfg[6] !=  "database"){
				if($os == "1"){
					$fullpath=str_replace("/", "\\", $fullpath);
					$fullpath=str_replace(":_:", " ", $fullpath);
					$content=$Backend->QueryResponse($sid, '', "readfile:_:\$MAINDIR$fullpath");
				} else $content = $Backend->QueryResponse($sid, '', "readfile:_:$fullpath", $fname);
			}

			if($content == "Unable to connect to the remote")$content="";
		} else {
			$content="";
			$Panel->ErrorExit("Configuration file not defined");
		}


		// get list of configs for this game for the cfgid list
		$configsq=sql_query($safesql->query("SELECT id, name FROM gameconfigs WHERE gid='%i'", array($GameCP->whitelist($cfg['gid'], "int")))) or die(mysql_error());
		$cfgs=array();
		while($configs=mysql_fetch_assoc($configsq)){
			if(!$configs['name']) $configs['name']="Config #".$configs['id'];
			$cfgs[$configs['id']]=$configs['name'];
		}
		$smarty->assign("cfgs",  $cfgs);


		// check if there are builders
		$buildersq=sql_query($safesql->query("SELECT * FROM config_builderitems WHERE builderid='%i' LIMIT 1", array($GameCP->whitelist($cfg['cfgid'], "int")))) or die(mysql_error());
		$builder=mysql_num_rows($buildersq);

		// real file was empty, do db file
		if(!$content) $content=$cfg[2];

		$smarty->assign("fip", $userGameDetails['ip']);
		$smarty->assign("fport", $userGameDetails['port']);

		$smarty->assign("username", $GameCP->whitelist($fname, "useredit"));
		$smarty->assign("fname", $GameCP->whitelist($cfg[0], "useredit"));
		$smarty->assign("fconfig", $GameCP->whitelist($cfg[1], "useredit"));
		$smarty->assign("fcontents",  $GameCP->whitelist($content, "web"));
		$smarty->assign("gname", $GameCP->whitelist($cfg[3], "useredit"));
		$smarty->assign("ugid", $GameCP->whitelist($cfg[4], "int"));
		$smarty->assign("cfid", $GameCP->whitelist($cfid, "int"));
		$smarty->assign("cfgid", $GameCP->whitelist($cfg[12], "int"));
		$smarty->assign("fconfigdir", $GameCP->whitelist($cfg[5], "useredit"));
		$smarty->assign("edittype", $GameCP->whitelist($cfg[6], "useredit"));
		$smarty->assign("hidecfg", $GameCP->whitelist($cfg[7], "useredit"));
		$smarty->assign("autoexec", $GameCP->whitelist($cfg[8], "useredit"));
		$smarty->assign("fencoding", $GameCP->whitelist($cfg[9], "useredit"));
		$smarty->assign("editable", $GameCP->whitelist($cfg[10], "useredit"));
		$smarty->assign("builder", $GameCP->whitelist($builder, "useredit"));
		$smarty->assign("builderid", $GameCP->whitelist($cfg['cfgid'], "useredit"));
		$smarty->assign("configbuilder", $GameCP->whitelist($cfg[11], "useredit"));
		$smarty->assign("subMode", "edit");
		$smarty->assign("cid", $userGameDetails['cid']);
		if(isset($_REQUEST['showSaved'])) $smarty->assign("showSaved", true);

		$smarty->display("manageuserconfigs/manageuserconfigs.tpl");
}	
/* END EDIT CONFIG */

/* CONFIG LIST */
if($mode == "editconfigs") { 
	if(!$ugid) die("Error: Missing user game id");

	if($_SESSION['gamecp']['userinfo']['ulevel'] == "0") $idd = $_SESSION['gamecp']['userinfo']['id']; 

	$_SESSION['gamecp']['user']['browseGame']=$GameCP->whitelist($ugid, "int");
	if(isset($ugid) && isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($ugid, $_SESSION['gamecp']['subuser']['games'])) exit;


	SetUGDetails($ugid);


	$result=sql_query($safesql->query("SELECT UC.name, UC.config, UC.contents, UC.edittype, UG.id, UC.id, UC.hidecfg, UC.cfgid, UC.editable, UC.configbuilder FROM userconfigs UC, usergames UG, game G WHERE G.id=UG.gid AND UG.id=UC.ugid AND UG.id='%i' $sqlA", array($GameCP->whitelist($ugid, "int")))) or die(mysql_error());
	$configList="";
	 /* build nice array for smarty */
	 while ($configResult = mysql_fetch_array($result)) { 
		$builders=sql_query($safesql->query("SELECT * FROM config_builderitems WHERE builderid='%i' LIMIT 1", array($GameCP->whitelist($configResult[7], "int")))) or die(mysql_error());
		$configList[]=array("name" => $GameCP->whitelist($configResult[0], "useredit"),
			 "config" => $GameCP->whitelist($configResult[1], "web"), 
			 "edittype" => $GameCP->whitelist($configResult[3], "useredit"),
			 "ugid" => $GameCP->whitelist($configResult[4], "int"), 
			 "ucid" => $GameCP->whitelist($configResult[5], "int"),
			 "hidecfg" => $GameCP->whitelist($configResult[6], "useredit"),
			 "cfgid" => $GameCP->whitelist($configResult['cfgid'], "useredit"),
			 "editable" => $GameCP->whitelist($configResult['editable'], "useredit"),
			 "configbuilder" => $GameCP->whitelist($configResult['configbuilder'], "useredit"),
			 "builder" => $GameCP->whitelist(mysql_num_rows($builders), "useredit")
		);
	 }

	$smarty->assign("ugid", $ugid);
	$smarty->assign("userConfigList", $configList);

	$smarty->display("manageuserconfigs/userconfiglist.tpl");
} 
/* END CONFIG LIST */


require_once(path.'/includes/core/editable/footer.inc.php');

?>