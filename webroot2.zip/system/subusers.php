<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

/* has not been security reviewd in 2013 */

require('../includes/core/includes/user/session.inc.php');
require('../includes/config.inc.php');

$GameCP->CheckPermissions('subusers');

$GameCP->SetURLCookie();

$smarty->assign('page_title', $LNG_CLIENTMANAGEMENT);

function check_permissions(){
	global $GameCP;
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
		if(!isset($_SESSION['gamecp']['userinfo']['permissions']['clients']['editsubaccount'])){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->ErrorExit("You do not have permission to view this location"); 
		}
	}
}

if(isset($_REQUEST['subid'])){
	$_REQUEST['subid']=$GameCP->whitelist($_REQUEST['subid'], "int");
	$subid=$_REQUEST['subid'];
}
if(isset($_REQUEST['subid'])){
	$_REQUEST['subid']=$GameCP->whitelist($_REQUEST['subid'], "int");
	$subid=$_REQUEST['subid'];
}



if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "4"){
	$sqlQ=" AND cid='".$_SESSION['gamecp']['userinfo']['id']."'";
} else $sqlQ='';


/* REMOVE SUB USER */
if($mode == "removesubuser"){
	check_permissions();

	$subUsersQ = sql_query($safesql->query("SELECT * FROM usersubaccounts WHERE id='%i' $sqlQ LIMIT 1", array($subid))) or die(mysql_error());
	$subUsers = mysql_fetch_array($subUsersQ);

	if(!$GameCP->UserCanEdit($subUsers['cid'])){
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$Panel->ErrorExit("You do not have permission to view this page.");
	}

	sql_query($safesql->query("DELETE FROM usersubaccounts WHERE id='%i' $sqlQ LIMIT 1;", array($subid))) or die(mysql_error());

	echo "<meta http-equiv=\"Refresh\" content=\"".$pgrefresh.";url=?mode=edit\">";
}
/* END REMOVE SUB USER */


/* UPDATE SUB ACCOUNT */
if($mode == "updatesub" && DEMO != "yes"){
	check_permissions();
	if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "4") $sqlQ=" AND cid='".$_SESSION['gamecp']['userinfo']['id']."'";

	$fname=$GameCP->whitelist(str_replace(" ", "", $fname));
	$femail=$GameCP->whitelist($femail, "useredit");
	$fpassword=$GameCP->whitelist($fpassword, "password");
	$subid=$GameCP->whitelist($subid, "int");
	$factive=$GameCP->whitelist($factive, "int");
	$ucid=$GameCP->whitelist($ucid, "int");

	if(isset($fperms) && is_array($fperms)){
		foreach($fperms as $f){
			if($f) $perms[$GameCP->whitelist($f, "int")]=$GameCP->whitelist($f, "int");
		}
	} else $fperms=array();

	if(isset($feditcfg) && is_array($feditcfg)){
		foreach($feditcfg as $f){
			if($f) $editcfg[]=$GameCP->whitelist($f, "useredit");
		}
	} else $feditcfg=array();

	if(isset($item) && is_array($item)){
		$item2=array();
		foreach($item as $f){
			if($f) $item2[]=$GameCP->whitelist($f);
		}
	} else $item2=array();



	sql_query($safesql->query("UPDATE usersubaccounts SET name='%s', email='%s', perms='%s', `files`='%s', `games`='%s', active='%i' WHERE id='%i' $sqlQ", 
		array(strtolower($fname), $femail, serialize($perms), serialize($item2), serialize($fgames), $factive,$subid))) or die(mysql_error());

	$GameCP->loadIncludes("user");
	$User=new User();
	$GameCP->SetPassword($subid, $fpassword, true);

	$_REQUEST['mode'] = "editsubaccount";
	$mode="editsubaccount";
	$_REQUEST['showSaved']=true;
}
/* END UPDATE SUB ACCOUNT */


/* MANAGE SUB ACCOUNT */
if(($mode == "newsubaccount" || $mode == "editsubaccount")  && DEMO != "yes"){
	check_permissions();
	if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "4") $sqlQ=" AND cid='".$_SESSION['gamecp']['userinfo']['id']."'";

	if(!isset($_SESSION['gamecp']['subaccount']) || isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] != "yes"){
		/* Generate data for edit page */
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		if($mode == "editsubaccount"){
			$subUsersQ = sql_query($safesql->query("SELECT * FROM usersubaccounts WHERE id='%i' $sqlQ LIMIT 1", array($subid))) or die(mysql_error());
			$subUsers = mysql_fetch_array($subUsersQ);

			if(!$GameCP->UserCanEdit($subUsers['cid'])){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				$Panel->ErrorExit("You do not have permission to view this page.");
			}

			$GameCP->loadIncludes("user");
			$User=new User();
			$pass=$User->Password($subUsers['cid'], "usersubaccounts");

			$subfiles=unserialize($subUsers['files']);
			$subperms=unserialize($subUsers['perms']);
			$ggames=unserialize($subUsers['games']);
			if(!is_array($subfiles))$subfiles=array();
			if(!is_array($subperms))$subperms=array();
			if(!is_array($ggames))$ggames=array();
			$defined=array();
			foreach($ggames as $g => $gg){
				if(trim($gg)) $defined[]=$gg;	
			}

			$smarty->assign("subMode", "editsubaccount");
			$smarty->assign("subUserPassword", $pass);
			$smarty->assign("subUserName", $subUsers['name']);
			$smarty->assign("subUserEmail", $subUsers['email']);
			$smarty->assign("userInfoactive", $subUsers['active']);
			$smarty->assign("ucid", $subUsers['cid']);
			$smarty->assign("definedgames", $defined);
			$smarty->assign("files", $subfiles);
			$smarty->assign("subUserPerms", $subperms);
			$smarty->assign("usergames", $Panel->GetUserGames($subUsers['cid']));
			$smarty->assign("subid", $subid);
		} else {

			if(!$GameCP->UserCanEdit($GameCP->whitelist($_GET['ucid'], 'int'))){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				$Panel->ErrorExit("You do not have permission to view this page.");
			}


			$smarty->assign("usergames", $Panel->GetUserGames($_GET['ucid']));
			$smarty->assign("subUserPassword", '');
			$smarty->assign("subUserName", '');
			$smarty->assign("subUserEmail", '');
			$smarty->assign("subid", '');
			$smarty->assign("files", array());
			$smarty->assign("subUserPerms", array());
			$smarty->assign("ucid", $GameCP->whitelist($_GET['ucid'], 'int'));
		}

		/* End generate data for edit page */

		$smarty->display("manageusers/subuser-add.tpl");
	}
}
/* END MANAGE SUB ACCOUNT */
/* INSERT SUB ACCOUNT */
if($mode == "addsubacct" && DEMO != "yes"){
	if($_SESSION['gamecp']['subaccount'] != "yes"){
		$ucid=$_POST['ucid'];
		if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "4") $ucid=$_SESSION['gamecp']['userinfo']['id'];
		$failed=false;
		if(!$GameCP->UserCanEdit($ucid)){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->ErrorExit("You do not have permission to view this page.");

		}

		if (!$fname) { echo "User name required.<br/>";  $failed=true; } 
		if (!$fpassword){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$fpassword=$Panel->RandomPassword();
		}
		
		$fname=$GameCP->whitelist(str_replace(" ", "", $fname));
		$femail=$GameCP->whitelist($femail, "useredit");
		$fpassword=$GameCP->whitelist($fpassword, "password");

		if(is_array($fperms)){
			foreach($fperms as $f){
				if($f) $perms[$GameCP->whitelist($f, "int")]=$GameCP->whitelist($f, "int");
			}
		}


		if ($fname == "test") { echo "Server User of Test is not allowed.<br/>";  $failed=true; } 
		if ($fname == "root") { echo "Panel User of Root is not allowed.<br/>"; $failed=true; } 
		if ($fname == "admin") { echo "Server User of Admin is not allowed."; $failed=true; } 

		$isUserQ = sql_query($safesql->query("SELECT id, email FROM users WHERE name='%s' OR username='%s'", array($GameCP->whitelist($fname, "username"), $GameCP->whitelist($fname, "username"))))  or die(mysql_error());
		if(mysql_num_rows($isUserQ) >= 1){ echo "User already exists.<br/>"; $failed=true; }

		$isUserQ2 = sql_query($safesql->query("SELECT id FROM usersubaccounts WHERE name='%s'", array($GameCP->whitelist($fname, "username"))))  or die(mysql_error());
		if(mysql_num_rows($isUserQ2) >= 1){ echo "User already exists.<br/>"; $failed=true;}

		if($failed!=true){
			$details=mysql_fetch_array($isUserQ);
			

			sql_query($safesql->query("INSERT INTO usersubaccounts SET cid='%i', name='%s', email='%s', perms='%s',indexsort='%s', games='%s'", 
				array($ucid, strtolower($fname), $femail, serialize($fperms), indexSubUser, serialize($fgames)))) or die(mysql_error());
			$subid=mysql_insert_id();

			$GameCP->loadIncludes("user");
			$User=new User();
			$GameCP->SetPassword($subid, $fpassword, true);

			
			$GameCP->loadIncludes("email");
			$Email=new Email();
			$Email->templatename = "Subuser-create";
			$Email->userdb = "usersubaccounts";
			$Email->userid = $subid;
			$Email->GetTemplateStuff();
			$Email->ReplaceStuff();
			if($details['email']) $Email->bcc = $details['email'];
			$Email->send();

			header("location: $url/system/subusers.php?mode=editsubaccount&subid=$subid&showSaved=true");

		}
	}
}
/* END INSERT SUB ACCOUNT */


if(!$mode || $mode == "viewsubaccount"){ 
	check_permissions();
	if ($_SESSION['gamecp']['userinfo']['ulevel'] == "0" || $_SESSION['gamecp']['userinfo']['ulevel'] == "10") {
		$cid=$_SESSION['gamecp']['userinfo']['id'];
	} else $cid=$_REQUEST['idd'];

	$SubUserList=array();
	
	$rowSubUserDetailsQ = sql_query($safesql->query("SELECT * FROM usersubaccounts WHERE cid='%i'", array($cid))) or die(mysql_error());
	$GameCP->loadIncludes("user");
	$User=new User();
	    while ($rowSubUserDetails = mysql_fetch_array($rowSubUserDetailsQ)){
			$SubUserList[]=array("cid" => $rowSubUserDetails['cid'], "id" => $rowSubUserDetails['id'], "name" => $rowSubUserDetails['name'], "password" => $User->Password($rowSubUserDetails['id'], "usersubaccounts"));
		}
	$smarty->assign("rowSubUserDetails", $SubUserList);
	$smarty->assign("cid", $cid);
	$smarty->display("manageusers/managesubusers-list.tpl");
}


?>