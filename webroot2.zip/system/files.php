<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

$editableExtensions=array(
	".html"
);

require('../includes/core/includes/user/session.inc.php');

if(!$_REQUEST && isset($_SESSION['gamecp']['fmnoheader'])) unset($_SESSION['gamecp']['fmnoheader']);
if(isset($_REQUEST['noheader'])) $_SESSION['gamecp']['fmnoheader']="true";
if(isset($_SESSION['gamecp']['fmnoheader']) && $_SESSION['gamecp']['fmnoheader']== "true") $noheader=true;
if(isset($_REQUEST['view']) && $_REQUEST['view'] == "main"){
	$noheader=false;
	unset($_SESSION['gamecp']['fmnoheader']);
}

require('../includes/config.inc.php');

if(isset($_POST['mode'])){ 
	$mode = $GameCP->whitelist($_POST['mode'], 'clean');
} elseif (isset($_GET['mode'])) { 
	$mode = $GameCP->whitelist($_GET['mode'], 'clean');
} else $mode = "";
if(!isset($mode) || isset($mode) && !$mode) $mode="cd";

$GameCP->CheckPermissions('files');

$smarty->assign('page_title', $LNG_FILEMANAGEMENT);

function FMError($error, $die=true){
	if($die){
		die($error. "</body></html>");
	} else echo '<div class="alert alert-error">'.$error.'</div>';
}

if($_SESSION['gamecp']['userinfo']['filemanager'] == "1") FMError("File manager has been disabled for your account."); 

if(isset($_SESSION['gamecp']['subaccount'])){
	if(!in_array('6', $_SESSION['gamecp']['subuser']['perms'])  && !in_array('5', $_SESSION['gamecp']['subuser']['perms'])){
		FMError("You do not have permission to view this location");
	}
	if(in_array('5', $_SESSION['gamecp']['subuser']['perms'])){
		$maincidQ=sql_query($safesql->query("SELECT files FROM usersubaccounts WHERE id='%s';", array($_SESSION['gamecp']['subuser']['id']))) or die(mysql_error()); 
		$subUserInfo=mysql_fetch_array($maincidQ);
		$allowed_subs = unserialize($subUserInfo['files']);
	}
} else $allowed_subs=false;


if($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "2" || $_SESSION['gamecp']['userinfo']['ulevel'] == "3" || $_SESSION['gamecp']['userinfo']['ulevel'] == "5" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4"){ 
	/* admin access to clients */
	$fname=$_SESSION['gamecp']['fileuser'];
	$fgame=$_SESSION['gamecp']['filegame'];
	$sid=$_SESSION['gamecp']['filesid'];
	$fcid = $_SESSION['gamecp']['filecid'];

	if( $_SESSION['gamecp']['userinfo']['ulevel'] == "4"){ 
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$userInfo=$Panel->GetUser($_SESSION['gamecp']['filecid']);
		if($userInfo['rsid']!=$_SESSION['gamecp']['userinfo']['id']) FMError("You do not have permission to view this location<br> Error: RES1.");
	}
} else { 
	/* client file manager */
	$fname = $_SESSION['gamecp']['userinfo']['username'];
	$fcid = $_SESSION['gamecp']['userinfo']['id'];

	$_SESSION['gamecp']['fileuser']=$fname;
	$_SESSION['gamecp']['filecid']=$fcid;

	if(isset($_POST['sid'])) { 
		$sid= $GameCP->whitelist($_POST['sid']); 
		$_SESSION['gamecp']['filesid']= $sid;
		unset($_SESSION['gamecp']['fmpath'], $_POST['gid'],$_SESSION['gamecp']['filegame']);
	} else if($_SESSION['gamecp']['filesid']){ 
		$sid=$_SESSION['gamecp']['filesid'];
	} else $sid = ""; 
	if(isset($_REQUEST['gid'])) $_SESSION['gamecp']['filegame']=$GameCP->whitelist($_REQUEST['gid']);
}

if($sid){
	$sid=$GameCP->whitelist($sid);
	$osQ = sql_query($safesql->query("SELECT os, winport FROM servers WHERE sid = '%s' LIMIT 1;", array($sid)));
	$osQ = mysql_fetch_array($osQ);
} else {
	$fcid=$GameCP->whitelist($fcid);
	$osQ = sql_query($safesql->query("SELECT S.os, S.winport, S.sid FROM servers S, users U, usergames UG, iptable I WHERE I.ip = UG.ip AND I.sid = S.sid AND UG.cid = U.id AND U.id='%i' LIMIT 1;", array($fcid))) or die(mysql_error());
	$osQ = mysql_fetch_array($osQ);
	$sid=$osQ[2];
	$winport=$osQ[1];
	$_SESSION['gamecp']['filesid']= $sid;
}

$os = $osQ[0];
$winport = $osQ[1];
$GameCP->loadIncludes("user");
$User=new User();
$fpass = $User->Password($fcid);
$_SESSION['filepass']=$fpass;

if($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$userInfo=$Panel->GetUser($fcid);
	$permissions=unserialize($userInfo['permissions']);
} else $permissions=array();

$smarty->assign("permissions", $permissions);

if(isset($_POST['afile'])){ 
	$afile = $_POST['afile'];
} elseif (isset($_GET['afile'])) $afile = $_GET['afile'];	

if (isset($_POST['path'])) {
	$path = $GameCP->whitelist($_POST['path'], 'clean');
} elseif (isset($_GET['path'])) {
	$path = $GameCP->whitelist($_GET['path'], 'clean');
} else $path="/home/$fname";


if($_SESSION['gamecp']['filegame']){
	$GameCP->loadIncludes("game");
	$Game=new Game();
	$gameInfo=$Game->GetService($_SESSION['gamecp']['filegame']); 

	if($gameInfo['subdirectory'] == "yes"){ 
			if(ipsubdir == "true"){
				$ipport=$gameInfo['ip']."-".$gameInfo['port'];
			} else $ipport="service".$_SESSION['gamecp']['filegame'];
   } 
}

if(!$_SESSION['gamecp']['fmpath']){
	if(isset($ipport)){
		$_SESSION['gamecp']['fmpath']="/home/$fname/".$ipport;
	} else $_SESSION['gamecp']['fmpath']="/home/$fname";
}

// prevent users from cd-ing out of the defined games folder!
if(isset($_SESSION['gamecp']['userinfo']['aiManageFiles']) && $_SESSION['gamecp']['userinfo']['aiManageFiles'] == "pergame"){
	$allowed_files=unserialize($gameInfo['files']);
	$allowed_gfiles=unserialize($gameInfo['gamefiles']);

	if (!$_SESSION['gamecp']['filegame']) FMError("You do not have permission to view this location<br> Error: FILE5.");
	
	if($allowed_files || $allowed_gfiles || $allowed_subs){
		if($_SESSION['gamecp']['fmpath']=="/home/$fname" && $ipport) $_SESSION['gamecp']['fmpath']="/home/$fname/".$ipport;
		
		$allow_folders=array();
		$allow_files=array();
		$allow_extensions=array();

		if($ipport){
			$rootpath="/home/$fname/".$ipport;
		} else $rootpath="/home/$fname";
		$allow_folders[]=$rootpath;

		if(is_array($allowed_subs)){
			foreach($allowed_subs as $fs){
				$fs['path']=rtrim($rootpath."/".$fs['path'], "/");
				if($fs['folder'] == "on"){
					$allow_folders[]=$fs['path'];
				} else {
					if(preg_match("/\*/i", $fs['path'])){
						$fd=explode("*", $fs['path']);
						$allow_extensions[]=array("path" => rtrim($fd[0], "/"), "ext" => ltrim($fd[1], "."));
					} else $allow_files[]=$fs['path'];
				}
			}
		}

		if(is_array($allowed_files)){
			foreach($allowed_files as $fs){
				$fs['path']=rtrim($rootpath."/".$fs['path'], "/");
				if(isset($fs['folder']) && $fs['folder'] == "on"){
					$allow_folders[]=$fs['path'];
				} else {
					if(preg_match("/\*/i", $fs['path'])){
						$fd=explode("*", $fs['path']);
						$allow_extensions[]=array("path" => rtrim($fd[0], "/"), "ext" => ltrim($fd[1], "."));
					} else $allow_files[]=$fs['path'];
				}
			}
		}

		if(is_array($allowed_gfiles)){
			foreach($allowed_gfiles as $fs){
				$fs['path']=rtrim($rootpath."/".$fs['path'], "/");
				if($fs['folder'] == "on"){
					$allow_folders[]=$fs['path'];
				} else {
					if(preg_match("/\*/i", $fs['path'])){
						$fd=explode("*", $fs['path']);
						$allow_extensions[]=array("path" => rtrim($fd[0], "/"), "ext" => ltrim($fd[1], "."));
					} else $allow_files[]=$fs['path'];
				}
			}
		}

		if($mode != "cd" && $mode) { 
			$remit=false;
			$checkme=rtrim($afile,"/");

			if($mode == "File Browser") $checkme="";
			if($mode == "rename") $checkme=$newname;
			if($mode == "mkdir" || $mode == "mkfile") $checkme=$newdir;
			
			if($checkme){
				$aext = pathinfo($checkme);
				@$aext = $aext["extension"];
				$remit=true;
			}

			foreach($allow_extensions as $ae){
				if($ae['path'] == $_SESSION['gamecp']['fmpath'] && ($aext == $ae['ext'] || !$ae['ext'])) $remit=false;				
			}

			if($checkme){
				$checkfile=$checkme;
			} else $checkfile=rtrim($_SESSION['gamecp']['fmpath'], "/");
			if(!in_array($checkfile, $allow_files) && $remit == true) FMError("You do not have permission to view this location<br> Error: FILE3A");
		}
	}
}

if (strpos($_SESSION['gamecp']['fmpath'], "/home/$fname") === false) FMError("You do not have permission to view this location<br> Error: FILE3."); 
 
// if its pergame then disable cding outside of /home/user/service## - check if in service folder, dont show ..
// change .. to do full path? 

if(isset($afile)) $afile=$GameCP->whitelist($afile, "clean");
$path=$GameCP->whitelist($path, "clean");
$upldir = tmppath;
$remfile = "0";

/* reset path variable */
$path = $_SESSION['gamecp']['fmpath'];
require('../includes/core/editable/managefiles.inc.php');

if($mode == "cd") { 
	if(isset($_SESSION['gamecp']['fmpath'])){
		$path=$_SESSION['gamecp']['fmpath'];
	} else $_SESSION['gamecp']['fmpath'] = "";
	
	$hidden="";
	$extention="";

	if(isset($afile)){
		if(isset($afile[0])) $hidden=$afile[0];
		$ext = pathinfo($afile);
		if(isset($ext["extension"])) $extention = $ext["extension"];

		if($hidden != "."){
			if($extention && !preg_match("/:/i", $extention) && !preg_match("/-/i", $extention)) $mode = "download"; 
		}
	}

	if(isset($afile) && $afile == "..") { 
		$path = dirname($path);
	} else {
		if(isset($afile) && $afile == "."){
			$afile=$path;
		} elseif(isset($afile) && $afile){
			$path = $afile;
		} else $path=$_SESSION['gamecp']['fmpath'];

	}
	if($path == "/home" || $path == "/")  $path = "/home/". $fname;
	if(isset($_SESSION['gamecp']['userinfo']['aiManageFiles']) && $_SESSION['gamecp']['userinfo']['aiManageFiles'] == "pergame" && $path == "/home/$fname") $path="/home/$fname/".$ipport;

	$_SESSION['gamecp']['fmpath']=rtrim($path, "/");
}

if($mode == "addshortcut" && DEMO != "yes") { 
	$ofile = $afile;
	$final=str_replace("\\", "/", $ofile);

	$addsc=true;
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$userInfo=$Panel->GetUser('',$fname);
	$shortcuts=unserialize($userInfo['shortcuts']);
	if(is_array($shortcuts)){
		foreach($shortcuts as $sc => $si){
			if($si['item'] == $final) $addsc=false;
		}
	} else $shortcuts=array();

	if($addsc==true) $shortcuts[]=array("item" => $final, "game" => $_SESSION['gamecp']['filegame']);

	$shortcuts=serialize($shortcuts);
	sql_query($safesql->query("UPDATE users SET shortcuts='%s' WHERE name='%s'", array($shortcuts, $fname)));
}

if($mode == "removeshortcut" && DEMO != "yes") { 
	$ofile = $afile;
	$final=str_replace("\\", "/", $ofile);

	$addsc=true;
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$userInfo=$Panel->GetUser('',$fname);
	$shortcuts=unserialize($userInfo['shortcuts']);
	if(is_array($shortcuts)){
		foreach($shortcuts as $sc => $si){
			if($si['item'] == $final) {
				unset($shortcuts[$sc]);
			}
		}
	} else $shortcuts=array();

	$shortcuts=serialize($shortcuts);
	sql_query($safesql->query("UPDATE users SET shortcuts='%s' WHERE name='%s'", array($shortcuts, $fname)));
}

if($mode == "viewshortcut" && $shortcut) { 
	$aext = pathinfo($shortcut);
	if(!isset($aext["extension"])|| isset($aext["extension"]) && !$aext["extension"]){
		$mode="cd";
		$_SESSION['gamecp']['fmpath']=rtrim($shortcut, "/");
		$path=rtrim($shortcut, "/");
	} else {
		$mode="edit";
		$afile=$shortcut;
		$path=$aext["dirname"];
		$_SESSION['gamecp']['fmpath']=rtrim($path, "/");
	}
}

if($mode == "edit" && DEMO != "yes") { 
	$GameCP->loadIncludes("backend");
	$Backend=new Backend();

	$local_file = $upldir.$afile;
	$ofile = $afile;

	if($os != "1"){ 
		$afile=str_replace(":_:", "\ ", $afile);
		$afile=str_replace(" ", "\ ", $afile);

		$fileinfo=$Backend->QueryResponse($sid, $winport, "command:_:ls -sXhx1la $ofile", $fname);
		if(strpos($fileinfo, " ->")){
			$backendfile=explode(" ->", $fileinfo);
			if($backendfile[1]){
				$details=explode(' ',$backendfile[0]);
				$backendfile[1]=trim($backendfile[1]);
				
				if($details[3] != $fname || ($backendfile[1][0] == "/" && !preg_match("/\/home\/$fname\//i", $backendfile[1])))
					FMError("You do not have permission to view this location<br> Error: FILE90a."); 
			}
		} else {
			$details=explode(' ',$fileinfo);
			if($details[3] != $fname)
				FMError("You do not have permission to view this location<br> Error: FILE90b."); 
		}

		$content=rtrim($Backend->QueryResponse($sid, $winport, "readfile:_:$ofile", $fname))."\n";

	} else {
		/* windows grab file to view */
		$ogpath=$path;
		$path=str_replace("/", "\\", $path);
		$ofile=str_replace(":_:", " ", $ofile);

		if(!preg_match("/\/home\/$fname\//i", $ofile))
			FMError("You do not have permission to view this location<br> Error: FILE90c."); 

		$content=$Backend->QueryResponse($sid, $winport, "readfile:_:\$MAINDIR$ofile");
		$path=$ogpath;
	}

	$afile=str_replace("\ ", ":_:", $afile);
	$ofile=str_replace(" ", ":_:", $ofile);

	$prettyfile=str_replace(":_:", " ", $afile);
	$prettyfile=str_replace("\ ", " ", $prettyfile);
	$smarty->assign("prettyfile", $prettyfile);

	$smarty->assign("ofile", $ofile);
	$smarty->assign("afile", $afile);
	$smarty->assign("path", $path);
	$smarty->assign("content", htmlspecialchars($content, ENT_NOQUOTES));

	$smarty->display("managefiles/managefiles-edit.tpl");
} else { 
	/* file manager  */
	$GameCP->loadIncludes("backend");
	$Backend=new Backend();
	$sidList=array();
	$finalList=array();
	$fileArray=array();
	$dirArray=array();

	/* server rlist */
	$sidListQ=sql_query($safesql->query("SELECT distinct(I.sid) FROM users U, usergames UG, iptable I WHERE U.id='%i' AND UG.cid=U.id AND UG.ip = I.ip", array($fcid)));
	$sidListRows=mysql_num_rows($sidListQ);
	while ($sidListResult = mysql_fetch_array($sidListQ)) $sidList[]=array('sid' => $sidListResult['sid']);
	/* end server rlist */

	$userInfo=$Panel->GetUser('',$fname);
	$shortcuts=unserialize($userInfo['shortcuts']);
	$sc=array();
	if(is_array($shortcuts)){
		foreach($shortcuts as $s => $c)$sc[]=$c['item'];
	} else $shortcuts=array();

	/* clean paths */
	$ogpath=$path;
	if($os == "1"){
		$path=str_replace(":_:", " ", $path); 
		$path=str_replace("\ ", " ", $path);
		$path=str_replace("/", "\\", $path);
	} else {
		$path=str_replace(":_:", " ", $path); 
		$path=str_replace(" ", "\ ", $path);
	}
	$path=str_replace("//", "/", $path);

	/* sub user game restriction */
		if(isset($_SESSION['gamecp']['subaccount'])){

			$GameCP->loadIncludes("game");
			$Game=new Game();
			$folderpass=false;
			$okfolder=array();
			$okfolder[]="/home/$fname";
			foreach($_SESSION['gamecp']['subuser']['games'] as $ug => $subugid){
				$gameInfo=$Game->GetService($subugid); 
				if($gameInfo['subdirectory'] == "yes"){ 
					if(ipsubdir == "true"){
						$ipport=$gameInfo['ip']."-".$gameInfo['port'];
					} else $ipport="service".$subugid;
					if(preg_match("/$ipport/i", $path)) $folderpass=true;
				} else $folderpass=true;
				$okfolder[]="/home/$fname/$ipport";
			}
			if($_SESSION['gamecp']['userinfo']['aiManageFiles'] == "yes" && rtrim($path, "/") == "/home/$fname") $folderpass=true;

			if(!$folderpass) FMError("You do not have permission to view this location<br> Error: FILE9."); 
			
		}
	/* end sub user game restriction */


	/* fetch dir list */
		if($os == "1"){ 
			$filelist=$Backend->QueryResponse($sid, $winport, "filelist:_:\$MAINDIR$path");
			if($filelist){
				$file=str_replace(":_:", "GC_PC", $filelist);
				$file=explode("::" , $file);
			} else $file="";
		} else { 
			/* linux */
			$sort = "ls -sSx1la --time-style iso $path";
			/* FreeBSD */
			if($os == "2") $sort = "ls -sx1la $path | sort -n +4";
			$file=explode("\n", $Backend->QueryResponse($sid, $winport, "command:_:$sort", $fname));
		}
		$path=$ogpath;
	/* end fetch dir list */

	/* parse list  */
	if(is_array($file)){
		for ($i = 0; $i < count($file); $i++){
			$ext="";

			if($os != "1" && $os !="3"){ 
				$file[$i] = trim($file[$i]);
				$infoArray = preg_split("/\s+/", $file[$i]);
				$shortnamea="";
				if(isset($infoArray[3])) $shortnamea=substr($infoArray[3], 0, 8);
				$shortnameb=substr($fname, 0, 8);
				if(isset($infoArray[0])) $size=$infoArray[0];
				if(isset($infoArray[1])) $dir=$infoArray[1];
				if(isset($infoArray[3])) $owner=$infoArray[3];

				if(!isset($infoArray[8]) || isset($infoArray[8]) && !$infoArray[8]){
					if(isset($infoArray[6])) $date=$fileDate = $infoArray[6];
					if(isset($infoArray[7])){
						$backendfile=$infoArray[7];
						$fileName=$infoArray[7];
					} else $fileName="";
				} else {
					if($os == "0"){
						$date=$fileDate = $infoArray[6]. " @ " . $infoArray[7];
						
						$fileName=$infoArray[8];
						if(isset($infoArray[9])) $fileName.=" ".$infoArray[9];
						if(isset($infoArray[10])) $fileName.=" ".$infoArray[10];
						if(isset($infoArray[11])) $fileName.=" ".$infoArray[11];
						if(isset($infoArray[12])) $fileName.=" ".$infoArray[12];
					} else if($os == "2"){

						$date=$fileDate = $infoArray[6]. " ". $infoArray[7] . " @ " . $infoArray[8];
						
						$fileName=$infoArray[9];
						if(isset($infoArray[10])) $fileName.=" ".$infoArray[10];
						if(isset($infoArray[11])) $fileName.=" ".$infoArray[11];
						if(isset($infoArray[12])) $fileName.=" ".$infoArray[12];

					}

					/* linked */
					if(strpos($fileName, " ->")){
						$backendfile=explode(" ->", $fileName);
						if($backendfile[1]) $linked = true;
						$fileName=$backendfile[0];
						$shortnamea=substr($fileName, 0, 8);
						$shortnameb=substr($fileName, 0, 8);
						$backendfile=str_replace(" ", ":_:", $fileName);
					} else $backendfile=str_replace(" ", ":_:", $fileName);
				}

				if(strpos($fileName, ".txt") ||
					strpos($fileName, ".ban") || 
					strpos($fileName, ".xml") || 
					strpos($fileName, ".asc") || 
					strpos($fileName, ".nfo") || 
					strpos($fileName, ".con") || 
					strpos($fileName, ".doc") || 
					strpos($fileName, ".rtf") || 
					strpos($fileName, ".msg") || 
					strpos($fileName, ".db") || 
					strpos($fileName, ".properties") || 
				
					strpos($fileName, ".ini") || 
					strpos($fileName, ".conf") || 
					strpos($fileName, ".cfg") || 
					strpos($fileName, ".py") || 
					strpos($fileName, ".sh") || 
					strpos($fileName, ".yml")||
					strpos($fileName, ".bat") || 
					strpos($fileName, ".log") ||
					$fileName=="DedicatedPlaylist"
						){
						$editable = "1";
					} else $editable="";

				/* check if the extension is in the list */
				if(count($editableExtensions) > 0){
					foreach($editableExtensions as $edext){
						if(strpos($fileName, $edext)) $editable = "1";
					}				
				}
				$linked=false;
			} else { 	
				if(preg_match("/Unable/s", $file[$i])) $Panel->ErrorExit('Unable to connect to remote server.');

				$filesub = explode("GC_PC", $file[$i]);

				$fileName=@$filesub[0];
				$size=@$filesub[1];
				$dir=@$filesub[3];
				$owner=$fname;

				if($filesub[3] == "d"){
					$date=@$filesub[4];
				} else $date=@$filesub[3];
				$shortnamea=$fname;
				$shortnameb=$fname;
				$linked=false;
				if(strpos($fileName, ".dll")) $ext =".dll";
				if(strpos($fileName, ".mus")) $ext =".dll";
				if(strpos($fileName, ".exe")) $ext =".exe";
				if(strpos($fileName, ".pk3")) $ext =".dll";

				if(strpos($fileName, ".txt") ||

					strpos($fileName, ".xml") || 
					strpos($fileName, ".asc") || 
					strpos($fileName, ".nfo") || 
					strpos($fileName, ".db") || 
					strpos($fileName, ".doc") || 
					strpos($fileName, ".rtf") || 
					strpos($fileName, ".ban") || 
					strpos($fileName, ".msg") || 
					strpos($fileName, ".properties") || 
					strpos($fileName, ".ini") || 
					strpos($fileName, ".conf") || 
					strpos($fileName, ".con") || 
					strpos($fileName, ".cfg") || 
					strpos($fileName, ".sh") || 
					strpos($fileName, ".bat") || 
					strpos($fileName, ".py") || 
					strpos($fileName, ".log")||
					strpos($fileName, ".yml")||
					$fileName=="DedicatedPlaylist"
					){
						$editable = "1";
					} else $editable="";

				/* check if the extension is in the list */
				if(count($editableExtensions) > 0){
					foreach($editableExtensions as $edext){
						if(strpos($fileName, $edext)) $editable = "1";
					}				
				}

				// Windows and its spaces!
				$backendfile=str_replace(" ", ":_:", $fileName);
			}

			// A little hack to not display some things
			$shortFileName=substr($fileName, 0, 7);
			if(isset($infoArray[9]) && strpos($infoArray[9], ".tar.gz")) $ext =".tar.gz";
			if(isset($infoArray[9]) && strpos($infoArray[9], ".x86")) $ext =".x86";

			$dir=substr($dir, 0, 1);

			$GameCP->loadIncludes("panel");
			$Panel=new Panel();

			$invalidNames=$Panel->InvalidFiles();
			
			/* new extension validation */
			$invalidExtensions=$Panel->InvalidExtensions();

			$fileInfo = pathinfo($fileName);

			$disable=false;
			if(!isset($fileInfo['extension'])) $fileInfo['extension']=array();


			if(isset($backendfile) && in_array(rtrim($path,"/")."/".$backendfile, $sc)){
				$shortcut=true;
			} else $shortcut=false;

			if(!in_array($fileInfo['extension'], $invalidExtensions) 
				&& !in_array($fileName, $invalidNames)
				&& !in_array($shortFileName, $invalidNames) 
				&& $shortnamea == $shortnameb
				&& $fileName[0] != "."
			){
				if($dir == "d"){
					$dirArray[]=array('file' => $fileName, 'size' => $size, 'dir' => $dir, 'owner' => $owner, 'date' => $date, 'ext' => '', 'backendfile' => rtrim($path,"/")."/".$backendfile, 'editable' => $editable, 'linked' => $linked, 'disable' => $disable, 'shortcut'=>$shortcut);
				} else $fileArray[]=array('file' => $fileName, 'size' => $GameCP->ConvertBytes($size), 'dir' => $dir, 'owner' => $owner, 'date' => $date, 'ext' => $fileInfo['extension'], 'backendfile' => rtrim($path,"/")."/".$backendfile, 'editable' => $editable, 'linked' => $linked, 'disable' => $disable, 'shortcut'=>$shortcut);
			}

			$finalList=array_merge($dirArray, $fileArray);
		} // end for each file
	} 
 	/* end parse list  */

	$backdir=true;
	/* user game defined files, remove files NOT in their array */ 
	if(isset($_SESSION['gamecp']['userinfo']['aiManageFiles']) && $_SESSION['gamecp']['userinfo']['aiManageFiles'] == "pergame" && ($allowed_files || $allowed_gfiles || $allowed_subs)){
		if(is_array($finalList)){
			foreach($finalList as $fli => $fl){
				$ck=rtrim($path, "/")."/".$fl['file'];
				if($fl['dir'] == "d"){
					if(!in_array($ck, $allow_folders)) unset($finalList[$fli]);
				} else {
					$remit=true;
					foreach($allow_extensions as $ae){
						if($ae['path'] == $path && ($fl['ext'] == $ae['ext'] || !$ae['ext'])) $remit=false;				
					}
					if(!in_array($ck, $allow_files) && $remit == true) unset($finalList[$fli]);
				}
			}
		
			if(!in_array(dirname($path), $allow_folders)) $backdir=false;

			// reset the array count 
			$i=0;
			$tmplist=$finalList;
			$finalList=array();
			foreach($tmplist as $fl){
				$finalList[$i]=$fl;
				$i++;
			}
		}
	}
	

	if(dirname($path) == "/home") $backdir=false;
	if(isset($_SESSION['gamecp']['userinfo']['aiManageFiles']) && $_SESSION['gamecp']['userinfo']['aiManageFiles'] == "pergame" && dirname($path) == "/home/$fname") $backdir=false;
	
	if(isset($_REQUEST['s'])) $s=$_REQUEST['s'];
		
	/* new sort method */
	if(isset($s) && $s == '' && isset($_SESSION['fmSort'])) unset($_SESSION['fmSort']);
	if(isset($_SESSION['fmSort']) || (isset($s) && $s != '')){
		if(isset($s)) $_SESSION['fmSort']=$s;
		$s=$_SESSION['fmSort'];

		function compareElems($elem1, $elem2) {
			global $s;

			switch($s){
				case 's':
					if ($elem1['size'] == $elem2['size']) return 0;
					return ($elem1['size'] < $elem2['size']) ? -1 : 1;
				break;

				case 'f':
				if(is_string($elem2['ext']) && is_string($elem1['ext'])) return strcmp($elem1['ext'], $elem2['ext']);
				break;

				case 'n':
					if(is_string($elem2['file']) && is_string($elem1['file'])) return strcmp($elem1['file'], $elem2['file']);
				break;
			}
		}

		uasort($finalList, "compareElems");

		$cleanList=array();
		$i=0;
		foreach($finalList as $id => $data){
			$cleanList[$i]=$data;
			$i++;
		}
		$finalList=$cleanList;

		$smarty->assign("s", $_SESSION['fmSort']);

	}


	/* display */
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$userInfo=$Panel->GetUser('',$fname);

	$prettypath=str_replace(":_:", " ", $path);
	$prettypath=str_replace("\ ", " ", $prettypath);
	$GameCP->loadIncludes("user");
	$User=new User();

	$fpass = $User->Password($fcid);
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$serverInfo=$Panel->GetServer($sid);
	$smarty->assign("shortcuts", unserialize($userInfo['shortcuts']));
	$smarty->assign("filegame", $_SESSION['gamecp']['filegame']);
	if(isset($uploadok)) $smarty->assign("uploadok", $uploadok);
	if(isset($errormsg)) $smarty->assign("errormsg", $errormsg);
	$smarty->assign("os", $os);
	$smarty->assign("prettypath", $prettypath);
	$smarty->assign("path", $path);
	$smarty->assign("sid", $sid);
	$smarty->assign("alias", $serverInfo['alias']);
	$smarty->assign("ftpport", $serverInfo['ftpport']);
	$smarty->assign("sidListRows", $sidListRows);
	$smarty->assign("sidList", $sidList);
	if(isset($uploadfile)) $smarty->assign("uploadfile", $uploadfile);
	if(isset($tmpfile)) $smarty->assign("tmpfile", $tmpfile);
	$smarty->assign("fileList", $finalList);
	$smarty->assign("fname", $fname);
	$smarty->assign("homedir", "/home/".$fname);
	$smarty->assign("fpass", $fpass);
	if(isset($s)) $smarty->assign("s", $s);
	if(isset($sort)) $smarty->assign("sort", $sort);
	$smarty->assign("time", time());
	$smarty->assign("backdir", dirname($path));
	$smarty->assign("backdirenable", $backdir);
	$smarty->assign("maxsize", ini_get('post_max_size'));

	$smarty->display("managefiles/managefiles.tpl");
}


require_once(path.'/includes/core/editable/footer.inc.php');

?>