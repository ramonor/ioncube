<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

$noheader=true;
require('../includes/core/includes/user/session.inc.php');
require('../includes/config.inc.php');

$GameCP->CheckPermissions('cmdbackend');

if(!isset($ugid)){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("Missing service id"); 
}

$GameCP->UserGameAccess($ugid, "usergames");

if ($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
	$sql=" AND U.id = '". $_SESSION['gamecp']['userinfo']['id']."'";
} else $sql="";

$result = sql_query($safesql->query("SELECT UG.ip, UG.port,
						G.scontrolname, U.name, G.name as 'gname',G.protocol,
						UG.id as 'gid',I.sid, G.gcode,S.os, UG.maxplayers as 'mplayers',
						UG.logfile, G.id as 'rgid', S.winport,
						S.sid, U.id as 'cid',
						UG.subdirectory, G.gcode, G.logfile as 'defaultlog', UG.gametype
						
						FROM users U, usergames UG, game G, iptable I, servers S WHERE U.id = UG.cid AND  UG.gid = G.id AND I.ip = UG.ip AND U.id=UG.cid AND UG.id='%i' AND I.sid=S.sid $sql LIMIT 1;", array($GameCP->whitelist($ugid, "int")))) or die(mysql_error());
$row = mysql_fetch_array($result);

$rgid=$row['rgid'];
$ugid=$row['gid'];
$os=$row['os'];
$winport=$row['winport'];
$ucid=$row['cid'];
$logfile=$row['logfile'];
if(!$logfile && $row['defaultlog'] && $os == "1") $logfile=$row['defaultlog'];

$subdirectory=$row['subdirectory'];
$ip=$row['ip'];
$port=$row['port'];
$gcodea=$row['gcode'];
$fname=$row[3];
$sid=$row['sid'];
$protocol=$row['protocol'];
$gname=$row['gname'];
$mplayers=$row['mplayers'];
$gametype=$row['gametype'];

if(!$logfile){
	$log = "screenlog.$ugid"; 
} else $log=$logfile;

if($mode == "mass" && DEMO != "yes"){ 
	$GameCP->loadIncludes("backend");
	$Backend=new Backend();

		if(!$scimode){
			echo "Select a mode";

			$selp=count($_REQUEST['player']);
		} elseif(is_array($_REQUEST['player']) && count($_REQUEST['player']) > 0){

			foreach($_REQUEST['player'] as $player => $player2) { 
				if($os != "1"){
					if($scimode == "kick") { $cccommand = "kick $player2"; }
					if($scimode == "ban") { $cccommand = "ban $player2"; }
					if($scimode == "slap") { $cccommand = "slap $player2"; }
					$GameCP->loadIncludes("linux");
					$Linux=new Linux();
					$Linux->SubmitScreen("service$ugid", $cccommand, $fname, $sid);

				} else {
					$GameCP->loadIncludes("game");
					$Game=new Game();
					$ugInfo=$Game->GetService($ugid);
					$GameCP->loadIncludes("rcon");
					$Rcon=new Rcon();
					$Rcon->Send($ugInfo['ip'], $ugInfo['port'], $ugInfo['protocol'], $scimode, $player2, $ugInfo['rconpass']);
				}
			}
			echo $scimode ." completed on " . count($_REQUEST['player']) . " player(s)";
		} else echo "Select a player";
}

if($mode == "submitscreen" && DEMO != "yes"){ 
	$GameCP->loadIncludes("backend");
	$Backend=new Backend();

	if(!$ip || !$cccommand) die("Awaiting command."); 

	$screenName="service$ugid";

	if($os != "1"){
		$GameCP->loadIncludes("linux");
		$Linux=new Linux();
		$Linux->SubmitScreen($screenName, $cccommand, $fname, $sid);
	} else {
		$GameCP->loadIncludes("game");
		$Game=new Game();
		$GameCP->loadIncludes("rcon");
		$Rcon=new Rcon();
		$ugInfo=$Game->GetService($ugid);
		echo $Rcon->Send($ugInfo['ip'], $ugInfo['port'], $ugInfo['protocol'], $cccommand, '', $ugInfo['rconpass']);
	}
}

if($mode == "viewstatus"){
	$GameCP->loadIncludes("query");
	$Query=new Query();
	$qstatInfo=$Query->GameQ($ugid);

	$total=$qstatInfo[0];
	$active=$qstatInfo[1];
	$status=$qstatInfo[2];
	$stats=$qstatInfo[4];
	$map=$qstatInfo[6];
	$sidname=$qstatInfo[7];

	$smarty->assign("gname", $gname);
	$smarty->assign("mplayers", $mplayers);
	$smarty->assign("map", $map);
	$smarty->assign("ugid", $ugid);
	$smarty->assign("protocol", $protocol);
	$smarty->assign("port", $port);
	$smarty->assign("ip", $ip);
	$smarty->assign("total", $total);
	$smarty->assign("active", $active);
	$smarty->assign("status", $status);
	$smarty->assign("stats", $stats);
	$smarty->assign("hostname", $sidname);

	$smarty->display("gameconsole/console-statusbox.tpl");
}

if($mode == "viewlog" || $mode == "downloadlog"){ 
	$GameCP->loadIncludes("game");
	$Game=new Game();
	$screenLog= $Game->ConsoleLog($ugid, $mode);

	if($mode == "downloadlog"){
		header('Content-type: application/txt');
		header("Content-Disposition: attachment; filename=\"$log.txt\"");
		echo str_replace("<br />", "\r\n", $screenLog);
	} else echo $screenLog;
}

if($mode == "viewplayers"){ 
	
	$GameCP->loadIncludes("query");
	$Query=new Query();
	$playerArray=$Query->GameQ($ugid, "player");
	if(!is_array($playerArray))$playerArray=array();
	$smarty->assign("playerArray", $playerArray);
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$ugInfo=$Panel->GetUserGame($ugid);
	$serverInfo=$Panel->GetServer('', $ugInfo['ip']);
	$smarty->assign("os", $serverInfo['os']);
	$smarty->display("gameconsole/console-players.tpl");
} 

?>