<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

if(isset($_REQUEST['opt'])){
	if($_REQUEST['opt'] == "editconfigs") header("location: configs.php?mode=editconfigs&ugid=".$_REQUEST['ggid']);
	if($_REQUEST['opt'] == "managemaps") header("location: maps.php?ugid=".$_REQUEST['ggid']);
}

if(isset($_REQUEST['mode']) && ($_REQUEST['mode'] == "deleteSched" || $_REQUEST['mode'] == "saveSched" || $_REQUEST['mode'] == "unsuspend" || $_REQUEST['mode'] == "suspend"))$noheader=true;
if(isset($_REQUEST['mode']) && $_REQUEST['mode'] == "addgame") $_REQUEST['addserver'] = true;

require('../includes/core/includes/user/session.inc.php');
require('../includes/config.inc.php');
 
if(!isset($opt)) $opt ="";
if((!isset($mode) || (isset($mode) && !$mode)) && $opt != "reinstallconfirmed")$mode="edit";

$GameCP->CheckPermissions('services');

$GameCP->SetURLCookie();

$smarty->assign('page_title', $LNG_USERGAMEMANAGEMENT);

if(isset($_REQUEST['idd']))$_REQUEST['idd']=$GameCP->whitelist($_REQUEST['idd'], "int");

// all this because of non-uniform variable assigning, gg 8 years of work!
if(isset($_REQUEST['gid']) || isset($_REQUEST['ggid']) || isset($_REQUEST['gmid'])){
	if(isset($_REQUEST['gid'])){
		$_REQUEST['ugid']=$GameCP->whitelist($_REQUEST['gid'], "int");
		$_REQUEST['gid']=$GameCP->whitelist($_REQUEST['gid'], "int");
		$_REQUEST['ggid']=$_REQUEST['gid'];
	}
	if(isset($_REQUEST['ggid'])){
		$_REQUEST['ugid']=$GameCP->whitelist($_REQUEST['ggid'], "int");
		$_REQUEST['ggid']=$GameCP->whitelist($_REQUEST['ggid'], "int");
		$ggid=$_REQUEST['ggid'];
	}
	if(isset($_REQUEST['gmid'])){
		$_REQUEST['ugid']=$GameCP->whitelist($_REQUEST['gmid'], "int");
		$_REQUEST['gmid']=$GameCP->whitelist($_REQUEST['gmid'], "int");
		$_REQUEST['ggid']=$_REQUEST['gmid'];
	}

	if(isset($_REQUEST['gid'])){
		$gggid=$_REQUEST['gid'];
	}else $gggid=$_REQUEST['ggid'];
}


if(isset($_REQUEST['ggid']))$_REQUEST['ggid']=$GameCP->whitelist($_REQUEST['ggid'], "int");

if(!empty($_GET)) extract($_GET, EXTR_SKIP);
if(!empty($_POST)) extract($_POST, EXTR_SKIP);


if(isset($_REQUEST['ugid']) && $_REQUEST['ugid'] || isset($_SESSION['gamecp']['user']['browseGame']) && $_SESSION['gamecp']['user']['browseGame']){
	if(!isset($_REQUEST['ugid'])) $_REQUEST['ugid']= $_SESSION['gamecp']['user']['browseGame'];
	$GameCP->UserGameAccess($_REQUEST['ugid'], "usergames");
} elseif($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("You do not have permission to view this page. 1B");
}

function showSched(){
	global $smarty, $safesql, $GameCP;

	$gameScheddule=array();
	$gameSched=sql_query($safesql->query("SELECT * FROM `userschedule` WHERE `ugid` = '%i';",  array($GameCP->whitelist($_REQUEST['ugid'], "int"))));
	while($gameSchedData=mysql_fetch_array($gameSched)){
		$gameScheddule[]=$gameSchedData;

	}

	$smarty->assign("cronList", $gameScheddule);
	$smarty->display("manageusergames/schedlist.tpl");
}

if($mode == "fastdl"){
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "0" && !isset($_SESSION['gamecp']['userinfo']['permissions']['services']['fastdl'])) $Panel->ErrorExit('Invalid Access');

	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$ugDetails=$Panel->GetUserGame($_REQUEST['gid']);
	$gameDetails=$Panel->GetGame($ugDetails['gid']);

	if(!$ugDetails['fastdl'] || !$gameDetails['fastdl_enable']) $Panel->ErrorExit('FastDL Not enabled');

	$serverInfo=$Panel->GetServer($ugDetails['fastdl']);

	if(!$serverInfo['webroot']) $Panel->ErrorExit('FastDL Not enabled');

	require_once(path.'/includes/core/classes/games/rsync.inc.php');

	$RSync=new RSync();
	$RSync->ugid=$_REQUEST['gid'];

	// get map dir 
	if($ugDetails['subdirectory'] == "yes"){ 
		if(ipsubdir == "true"){
			$thesubdir=$ugDetails['ip']."-".$ugDetails['port']."/";
		} else $thesubdir="service".$gid."/";
	} else $thesubdir='';

	$RSync->source="/home/".$ugDetails['username']."/".$thesubdir.$gameDetails['usermapdir']."/";
	$RSync->destination=$serverInfo['webroot']."/fastdl/$gid/".$gameDetails['usermapdir'];
	$RSync->remoteid=$ugDetails['fastdl'];
	$RSync->compression=$gameDetails['fastdl_compression'];
	$RSync->includes=$gameDetails['fastdl_include'];
	$RSync->excludes=$gameDetails['fastdl_exclude'];

	$RSync->SetInfo();
	$RSync->Generate();
	$RSync->Sync();
	
	$opt="edit";
	$mode="edit2";
	$ggid=$gid;
	$_REQUEST['opt']="edit";
	$_REQUEST['mode']="edit2";
	$_REQUEST['ggid']=$gid;
}

if($mode == "backup"){
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "0" && !isset($_SESSION['gamecp']['userinfo']['permissions']['services']['backup'])) $Panel->ErrorExit('Invalid Access');
	$GameCP->loadIncludes("game");
	$Game=new Game();

	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$ugDetails=$Panel->GetUserGame($ugid);
	$smarty->assign("gameInfo", $ugDetails);
	$smarty->assign('ugid', $ugid);
	$Game->ArchiveService($ugid);

	unset($_SESSION['gamecp']['backup']);
	$smarty->display('manageusergames/backup.tpl');
}

if($mode == "backupcheck"){
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "0" && !isset($_SESSION['gamecp']['userinfo']['permissions']['services']['backup'])) $Panel->ErrorExit('Invalid Access');
	
	if(!isset($_SESSION['gamecp']['backup'])){
		$GameCP->loadIncludes("game");
		$Game=new Game();
		$ftp=$Game->ArchiveServiceComplete($ugid);
		if($ftp){
			$_SESSION['gamecp']['backup']=$ftp;
			echo '<a href="'.$_SESSION['gamecp']['backup'].'" class="button" target="_new">Download</a>';
		} else echo "Please wait..";
	} else {
		echo '<a href="'.$_SESSION['gamecp']['backup'].'" class="button" target="_new">Download</a>';
	}
}

if($mode == "saveSched"){
	
	require_once(path.'/includes/core/classes/cron/parser.inc.php');
	
	$cron_parser = new cron_parser($GameCP->whitelist($_REQUEST['cron'], "clean"));
	$next_time = $cron_parser->next_runtime();

	sql_query($safesql->query("INSERT INTO `userschedule` SET  
		cron = '%s',
		name = '%s',
		cmd = '%s',
		settings = '%s',
		next_run='%s',
		ugid='%i'",
		
		array($GameCP->whitelist($_REQUEST['cron'], "clean"),
			$GameCP->whitelist($_REQUEST['name'], "clean"),
			$GameCP->whitelist($_REQUEST['action'], "clean"),
			$GameCP->whitelist($_REQUEST['settings'], "clean"),
			$GameCP->whitelist($next_time, "clean"),
			$GameCP->whitelist($_REQUEST['ugid'], "int")
			)))or die(mysql_error());

	showSched();
}

if($mode == "deleteSched"){
	sql_query($safesql->query("DELETE FROM `userschedule` WHERE id = '%i' AND ugid='%i';",  array($GameCP->whitelist($_REQUEST['sched_id'], "int"),$GameCP->whitelist($_REQUEST['ugid'], "int"))));
	showSched();
}

if ($mode == "changeuser") { 
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "1"){
		$GameCP->loadIncludes("game");
		$Game=new Game();
		$Game->ChangeServiceUser($_REQUEST['ugid'], $_REQUEST['cid']);
	}
	header("location: userservices.php?mode=edit2&opt=edit&ggid=".$_REQUEST['ugid']);
}

if ($mode == "unsuspend") { 
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "1"){
		$GameCP->loadIncludes("suspend");
		$Suspend=new Suspend();
		$Suspend->GameRestore($ggid);
	}
	header("location: services.php");
}

if ($mode == "suspend") { 
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "1"){
		$GameCP->loadIncludes("suspend");
		$Suspend=new Suspend();
		$Suspend->Game($ggid);
	}
	header("location: services.php");
}

if ($mode == "restoreconfigs") { 
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$ugDetails=$Panel->GetUserGame($_REQUEST['gid']);
	$username=$ugDetails['username'];
	$smarty->assign("ggid", $gid);
	$smarty->assign("fcid", $ugDetails['cid']);
	$smarty->assign("fname", $ugDetails['username']);

	$smarty->display("manageusergames/restoreconf.tpl");
}

if ($opt == "reinstall") { 
	$_SESSION['gamecp']['user']['browseGame']=$GameCP->whitelist($ggid, "int");
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$ugDetails=$Panel->GetUserGame($_REQUEST['ggid']);
	$gameDetails=$Panel->GetGame($ugDetails['gid']);

	$smarty->assign("gameInfo", $ugDetails);


	$smarty->assign("ggid", $ggid);
	$smarty->assign("username", $ugDetails['username']);
	$smarty->assign("install", $gameDetails['install']);
	$smarty->assign("ip", $ugDetails['ip']);
	$smarty->assign("port", $ugDetails['port']);

	$similarIPPORT=sql_query($safesql->query("SELECT UG.id FROM usergames UG WHERE UG.cid = '%i' AND UG.ip='%s' AND UG.port='%s'", array($ugDetails['cid'], $ugDetails['ip'], $ugDetails['port'])));
	$smarty->assign("userLastIPPORT",  mysql_num_rows($similarIPPORT));

	if($ugDetails['subdirectory'] == "yes"){ 
		if(ipsubdir == "true"){
			$subdir=$ugDetails['ip'].":".$ugDetails['port'];
		} else  $subdir="service".$_REQUEST['ggid'];
		
	} else $subdir='';

	if($gameDetails['install']){
		$install=$subdir."/".$gameDetails['install'];
	} else $install=$subdir;
	$smarty->assign("removeFile",  "/home/".$ugDetails['username']."/".$install."/");

	$smarty->display("manageusergames/reinstall.tpl");
}

if($opt == "remove") { 
	if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "2" && $_SESSION['gamecp']['userinfo']['ulevel'] != "4") die("Admin/Manager level required."); 

	$ggid=$_REQUEST['ggid'];
	$smarty->assign("ggid", $ggid);

	if($_SESSION['gamecp']['userinfo']['ulevel'] == "4"){
		$resQ=" AND U.rsid = ". $_SESSION['gamecp']['userinfo']['id'];
	} else $resQ="";

	$userGameInfoQ=sql_query($safesql->query("SELECT G.install, UG.subdirectory, U.id as 'uid', UG.id, UG.maxplayers, UG.startmap, UG.config, UG.ip,
	UG.port, G.gcode, G.protocol, G.name as 'gamename', U.name as 'fname', UG.active as 'gstats', S.sid, G.id as 'gameid', S.os FROM game G, usergames UG, users U, iptable I, servers S WHERE G.id = UG.gid AND  U.id = UG.cid AND U.userlevel ='0' AND I.ip = UG.ip AND I.sid=S.sid AND UG.id='%i' $resQ", array($ggid)))or die(mysql_error()); 
	$usergameInfo=mysql_fetch_array($userGameInfoQ);

	if(mysql_num_rows($userGameInfoQ) == "0") die("Unable to remove user game.");

	$subdirectory=$usergameInfo['subdirectory'];
	$install=$usergameInfo['install'];
	$fip=$usergameInfo['ip'];
	$fport=$usergameInfo['port'];
	$gameid=$usergameInfo['gameid'];
	$fname=$usergameInfo['fname'];
	$sid=$usergameInfo['sid'];
	$fcid=$usergameInfo['uid'];
	$os=$usergameInfo['os'];

	$smarty->assign("fname", $fname);

	/* "smart remove " */

	/* determin the options for removing */
	$userGameArray=sql_query($safesql->query("SELECT U.id as 'uid', UG.id, UG.maxplayers, UG.startmap, UG.config, UG.ip, UG.port, G.gcode, G.protocol, G.name as 'gamename', U.name, UG.active as 'gstats', S.sid FROM game G, usergames UG, users U, iptable I, servers S WHERE G.id = UG.gid AND UG.cid = '%i' AND U.id = UG.cid AND U.userlevel ='0' AND I.ip = UG.ip AND I.sid=S.sid", array($fcid)));
	$similarIPPORT=sql_query($safesql->query("SELECT UG.id FROM usergames UG WHERE UG.cid = '%i' AND UG.ip='%s' AND UG.port='%s'", array($fcid, $fip, $fport)));
	$userSameGameArray=sql_query($safesql->query("SELECT UG.id  FROM usergames UG WHERE UG.cid = '%i'  AND UG.ip='%s' AND UG.port='%s' AND UG.gid='%i' AND UG.id !='%i'", array($fcid, $fip, $fport, $gameid, $ggid)));
	$isLastGameQ=sql_query($safesql->query("SELECT UG.id FROM iptable I, usergames UG WHERE UG.ip = I.ip AND I.sid='%s' AND UG.cid='%i'", array($sid, $fcid)));

	if($subdirectory == "yes"){ 
		if(ipsubdir == "true"){
			$thesubdir=$fip."-".$fport;
		} else $thesubdir="service".$ggid;
	} else $thesubdir='';
	
	if($install != ""){
		if($thesubdir) $install =$thesubdir."/".$install;
	} else if(isset($thesubdir)) $install=$thesubdir;

	$smarty->assign("subdirectory",  $subdirectory);

	$removeSubGamesQ=sql_query($safesql->query("SELECT id FROM usergames WHERE cid='%i' AND mgid='%i';", array($fcid, $ggid)))or die(mysql_error());
	$smarty->assign("removeSubGames",  mysql_num_rows($removeSubGamesQ));

	$GameCP->loadIncludes("query");
	$Query=new Query();

	$smarty->assign("connectionStatus", $Query->Status($sid));
	$smarty->assign("os", $os);

	$smarty->assign("userLastGame",  mysql_num_rows($userGameArray));
	$smarty->assign("userLastOfSameGame",  mysql_num_rows($userSameGameArray));
	$smarty->assign("isLastGame",  mysql_num_rows($isLastGameQ));
	if($thesubdir) $smarty->assign("userLastIPPORT",  mysql_num_rows($similarIPPORT));
	$smarty->assign("usergameInfo",  $usergameInfo);

	$smarty->assign("removeFile",  "/home/".$fname."/".$install."/");
	$smarty->assign("removeFile2",  "/home/".$fname."/".$thesubdir."/");

	$smarty->display("manageusergames/remove.tpl");
}

if($opt == "cmdupdate") {
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$smarty->assign("ggid", $_REQUEST['ggid']);
	$gameInfo=$Panel->GetUserGame($_REQUEST['ggid']);
	$smarty->assign("gameInfo", $gameInfo);
	$smarty->display("manageusergames/update-confirm.tpl");
}

if($opt == "cmdupdateconf" && DEMO != "yes") { 
	$ggid=$_REQUEST['ggid'];
	$_SESSION['gamecp']['user']['browseGame']=$GameCP->whitelist($ggid, "int");

	$GameCP->loadIncludes("game");
	$Game=new Game();
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Game->UpdateService($ggid);
	$smarty->assign("ggid", $ggid);
	$gameInfo=$Panel->GetUserGame($_REQUEST['ggid']);
	$smarty->assign("gameInfo", $gameInfo);
	$smarty->display("manageusergames/update-complete.tpl");
}

if($opt == "cmdupdatestatus") { 
	$GameCP->loadIncludes("game");
	$Game=new Game();
	$Game->CheckUpdateStatus($ggid, $showlog);
}

if($mode == "interact" && DEMO != "yes"){
	if(!$ugsci) die("Missing scontrol name."); 
	if(!$gid) die("Missing users game id.");
	$sidQ = sql_query($safesql->query("SELECT S.sid, S.os, S.winport FROM servers S, usergames UG, iptable I WHERE UG.ip = I.ip AND I.sid = S.sid AND UG.id='%i' LIMIT 1", array($gid))) or die(mysql_error()); 
	$result=mysql_fetch_row($sidQ);

	$sid=$result[0];
	$os=$result[1];
	$winport=$result[2];
	
	if($os != "1") die("Windows required.");

	$GameCP->loadIncludes("backend");
	$Backend=new Backend();
	echo "Updating service to interact with desktop, requires a restart.<br>";
	$Backend->Query($sid, $winport, "serviceinteract:_:gcp-$fname-$ugsci-$serverip-$fport");
	
	echo "<br><br>To disable interact with desktop please do so via Remote Desktop and the Windows Services Manager.";
	echo "<br><br><a href=\"userservices.php?opt=edit&fname=".$GameCP->whitelist($fname)."&ggid=".$GameCP->whitelist($gid)."&mode=edit2\">Continue</a>";
	
}

if($mode == "restoreconf" && DEMO != "yes"){
	if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "2" && $_SESSION['gamecp']['userinfo']['ulevel'] != "3") {
		$fcid = $_SESSION['gamecp']['userinfo']['id'];
	}else $fcid=$_POST['fcid'];
			

	$sidQ = sql_query($safesql->query("SELECT 
	S.sid, G.installfile, S.os, G.id,
	S.winport,
	UG.ip,
	UG.port, 
	UG.maxplayers, UG.rconpass,
	U.id, I.internal,
	I.useinternal, 
	UG.subdirectory,
	UG.id as 'ugid'

	FROM 
		servers S, game G, usergames UG, iptable I, users U 
	WHERE 
		 U.id = UG.cid AND UG.ip = I.ip AND I.sid = S.sid AND UG.gid = G.id AND UG.id='%i' AND U.id='%i' LIMIT 1", array($gid, $fcid))) or die(mysql_error()); 
	$query=mysql_fetch_array($sidQ);

	$sid=$query[0];
	$installFile=$query[1];
	$os=$query[2];
	$gid=$query[3];
	$winport=$query[4];
	$fip=$query[5];
	$fport=$query[6];
	$fmaxclients=$query[7];
	$RCONPASSWORD=$query[8];
	$ugid=$query['ugid'];
	$cid=$query[9];
	$serverip = $fip;
	$subdirectory=$query['subdirectory'];

	if($sidR['useinternal'] == "1") $fip = $sidR['internal'];
	
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();

	$GameCP->loadIncludes("game");
	$Game=new Game();

	$Game->ConfigCreate($ugid, false, 'clear');

	$hook_vars=$query;
	run_hook("config_restore");

	header("location: $url/system/configs.php?ugid=$ugid&ggid=$ugid&mode=editconfigs&showSaved=true");
}

if($mode == "quickmod" && DEMO != "yes"){
	$GameCP->loadIncludes("game");
	$Game=new Game();
	$Game->QuickMod($gid, $quickmod);
	echo "<body onLoad=\"parent.window.location='index.php'\"></body>";
}

if ($opt == "reinstallconfirmed" && DEMO != "yes") {
	if($doit != $LNG_SHOWYES) die("Must confirm yes to continue.");
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$ugDetails=$Panel->GetUserGame($_REQUEST['ggid']);

	$smarty->assign("gameInfo", $ugDetails);

	$fname=$ugDetails['username'];
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "0") $fname = $_SESSION['gamecp']['userinfo']['username']; 
	$ugid=$ggid;
	$dome="0";
	$smartyResult="";

	$sidQ = sql_query($safesql->query("SELECT 
											S.sid,
											G.installfile,
											S.os,
											G.id as 'gid',
											S.winport,
											UG.ip,
											UG.port,
											UG.maxplayers,
											UG.rconpass,
											U.id as 'cid',
											I.internal,
											I.useinternal,
											G.install,
											UG.subdirectory,
											UG.premode, G.wininstall, G.wininstall, G.altinstall, G.altinstallwin, G.winappdir, G.vars
	
									FROM servers S, game G, usergames UG, iptable I, users U 
									WHERE 
										U.id = UG.cid
										AND UG.ip = I.ip 
										AND I.sid = S.sid
										AND UG.gid = G.id
										AND UG.id='%i' AND U.username ='%s' LIMIT 1;", array($GameCP->whitelist($ggid, "int"), $GameCP->whitelist($fname, "useredit")))) or die(mysql_error());
	
	$query = mysql_fetch_assoc($sidQ);

	$hook_vars=$query;
	run_hook("reinstall_game_pre");

	$sid=$query['sid'];
	$installFile=$query['installfile'];
	$os=$query['os'];
	$gid=$query['gid'];
	$winport=$query['winport'];
	$fip=$query['ip'];
	$fport=$query['port'];
	$fmaxclients=$query['maxplayers'];
	$RCONPASSWORD=$query['rconpass'];
	$cid=$query['cid'];
	$serverip = $fip;
	$install=$query['install'];
	$subdirectory=$query['subdirectory'];
	$premode=$query['premode'];
	$DefaultArchive=$query['wininstall'];
	$DefaultInstall=$query['installfile'];
	$installdir=$query['install'];
	$wininstall=$query['wininstall'];
	$defaultvars=$query['vars'];

	if($os == "1"){
		$altinstall=$query['altinstallwin'];
		$installdir=$query['winappdir'];
	} else $altinstall=$query['altinstall'];

	$GameCP->loadIncludes("control");
	$GameCP->loadIncludes("game");
	$Control=new Control();
	$Game=new Game();

	sql_query($safesql->query("UPDATE usergames SET `status`='6', startserver='yes', addonstatus='%s' WHERE id='%i'", array(serialize(array()), $GameCP->whitelist($ugid, "int")))) or die(mysql_error());

	$GameCP->loadIncludes("control");
	$Control=new Control();
	$Control->Usergame($ugid, "stop");

	if($_REQUEST['removeconfigs'] == "1") sql_query($safesql->query("DELETE FROM userconfigs WHERE ugid='%i'", array($GameCP->whitelist($ugid, "int")))) or die(mysql_error());


	$Control->Build($ugid, "add");
		
	if(isset($_SESSION['gamecp']['install'][$ugid]['start'])) unset($_SESSION['gamecp']['install'][$ugid]['start']);

	$Game->InstallFiles($fname, $ugid, $fip, $fport, $sid, $os, $winport, $DefaultInstall, $subdirectory, $premode,$wininstall,$installdir,$DefaultArchive, '', @$_REQUEST['removegame'], $altinstall);

	$Game->ConfigCreate($ugid, false, "clear");

	$hook_vars=$query;
	run_hook("reinstall_game");

	$smarty->assign("cid", $cid);
	$smarty->assign("ugid", $ugid);

	$smarty->display("manageusergames/reinstall-completed.tpl");

	$Event->EventLogAdd($fname, "User ". $fname. " had game $ugid reinstalled on $sid by ".$_SESSION['gamecp']['userinfo']['name']." ". time());
}

if($mode == "editgame" && DEMO != "yes") { 
	if(isset($_SESSION['gamecp']['subaccount']) && !in_array("1", $_SESSION['gamecp']['subuser']['perms'])){
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$Panel->ErrorExit("Incorrect permission");
	}

	$GameCP->loadIncludes("backend");
	$Backend=new Backend();
	
	if(isset($affinity)){
		if(is_array($affinity)){
			foreach($affinity as $ai) $affy.=$ai.",";
			$affy=rtrim($affy, ",");
		} else $affy=$affinity;
	}else $affy='';

	if(!isset($_REQUEST['cvars'])){
		$customvars=serialize(array());
	} else $customvars=serialize($_REQUEST['cvars']);

	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$userGameInfo=$Panel->GetUserGame($GameCP->whitelist($gid, "int"));
	$gameInfo=$Panel->GetGame($GameCP->whitelist($userGameInfo['gid'], "int"));
	$user=$userGameInfo['username'];
	$install = $gameInfo['install'];
	$clientid=$userGameInfo['cid'];
	
	$hook_vars=$userGameInfo;
	run_hook("edit_game_pre");

	if($userGameInfo['subdirectory'] == "yes"){ 
		if(ipsubdir == "true"){
			$thesubdir=$fip."-".$fport;
		} else $thesubdir="service".$gid;				
		$homepath="/home/$user/$thesubdir/$install";
	} else $homepath="/home/$user/$install";

	$ogdefaults=unserialize($userGameInfo['defaultinfo']);
	if(is_array($defaults)){
		foreach($defaults as $d => $f){
			$ogdefaults[$GameCP->whitelist($d, "useredit")]=$GameCP->whitelist($f, "useredit");

		}
	}
	$defaults=$ogdefaults;

	/* admin update */
	if($_SESSION['gamecp']['userinfo']['ulevel'] != "0"){
		if($factive){
			$active="active='$factive',";
		} else $active='';
		if(!isset($usereditsci)) $usereditsci="0";
		$wasactive = $userGameInfo['active'];
		$fname=$userGameInfo['username'];
		if(!$fclientplayers) $fclientplayers=$userGameInfo['clientplayers'];
		if(!$fmaxplayers) $fmaxplayers=$userGameInfo['maxplayers'];
		$cvars=serialize($_REQUEST['cvar']);

		$serverInfo=$Panel->GetServer('', $fip);
		$sid = $serverInfo['sid'];
		$os = $serverInfo['os'];
		$winport = $serverInfo['winport'];
		$iptablesconfig=$serverInfo['iptablesconf'];

		if(!$GameCP->UserCanEdit($clientid)){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->ErrorExit("You do not have permission to view this page.");
		}

		$Event->EventLogAdd('', "User ". $fname. " had game $gid changed by ".$_SESSION['gamecp']['userinfo']['name']." ". time());

		if($os != "1" && $userGameInfo['status'] == "1" && $fstatus != "1") $Backend->Query($sid, $winport, "deletefile:_:$homepath/debug$gid.sh", $fname);

		if($factive == "2" && $wasactive == "1"){
			$GameCP->loadIncludes("control");
			$Control=new Control();
			$Control->Usergame($gid, "stop");
			$restart="";
		}

		/* firewall */

		$GameCP->loadIncludes("user");
		$User=new User();

		if(isset($_REQUEST['ports'])){
			$save_ports=$_REQUEST['ports'];
		} else $save_ports=array();

		// old ports
		$firewall_ports=unserialize($userGameInfo['firewallports']);
		// new custom ports
		$new_cvars=array();
		$new_ports=array();
		if(is_array($save_ports) && count($save_ports) > 0){
			foreach($save_ports as $p=>$t){
				$new_ports[]=$t['port'];
				$new_cvars[]=$t['cvar'];
			}
		}		

		if($ogqueryport != $fqueryport){
			$User->ExecFirewall($sid, $os, $fip, array($ogqueryport), "close", $iptablesconfig);
			$User->ExecFirewall($sid, $os, $fip, array($fqueryport), "open", $iptablesconfig);
			foreach($firewall_ports as $f=>$p){
				if($p['cvar'] == "QUERYPORT") $firewall_ports[$f]['port']=$fqueryport;
			}
		}

		if($fport != $ogport){
			$GameCP->loadIncludes("ports");
			$Ports=new Ports();
			$default_ports=unserialize($gameInfo['ports']);
			$close_ports=array($ogport);
			$open_ports=array();
			$anew_ports=array($fport);
			// scan default ports, update table with the new ports for the var
			if(is_array($default_ports) && count($default_ports) >0){
				foreach($default_ports as $p=>$t){
					// if the port is a custom var we dont manage it here
					if(!in_array($t['cvar'], $new_cvars)){
						$anew_ports[$t['cvar']]=$Ports->GetPort($t['port'], $fip, $fport, ($fport-$gameInfo['port']));
						$close_ports[$t['cvar']]='';
					}
				}
			}
			if(count($anew_ports) >0){
				$new_fw=array();
				foreach($firewall_ports as $f=>$p){
					if(isset($close_ports[$p['cvar']])) $close_ports[$p['cvar']]=$p['port'];
					if(isset($anew_ports[$p['cvar']]))  $p['port']=$anew_ports[$p['cvar']];
					$new_fw[]=array('cvar'=>$p['cvar'], 'port'=>$p['port']);
				}
				$firewall_ports=$new_fw;

				$queryport=$Ports->GetPort($userGameInfo['queryport'], $fip, $gameInfo['queryport'], $fport-$gameInfo['port']);

				$f_open=array();
				$anew_ports=array_merge($anew_ports, array("PORT" => $fport, "QUERYPORT" => $queryport));
				foreach($anew_ports as $n=>$p) $f_open[]=$p;
				if(count($f_open) >0) $User->ExecFirewall($sid, $os, $fip, $f_open, "open", $iptablesconfig);
			}

			if(count($close_ports) >0){
				$f_close=array();
				$close_ports=array_merge($close_ports, array("PORT" => $ogport, "QUERYPORT" => $userGameInfo['queryport']));
				foreach($close_ports as $c=>$p) $f_close[]=$p;
				if(count($f_close) >0) $User->ExecFirewall($sid, $os, $fip, $f_close, "close", $iptablesconfig);
			}
			foreach($firewall_ports as $f=>$p){
				if($p['cvar'] == "PORT") $firewall_ports[$f]['port']=$fport;
			}

		}

		$old_cvars=array();
		$old_ports=array();
		$portsq=unserialize($userGameInfo['ports']);
		if(is_array($portsq) && count($portsq) > 0){
			foreach($portsq as $p=>$t){
				$old_ports[]=$t['port'];
				$old_cvars[]=$t['cvar'];
			}
		}

		// remove any matching ports
		foreach($old_ports as $o=>$p){
			foreach($new_ports as $n=>$pp){
				if($p == $pp) unset($new_ports[$n], $old_ports[$o]);
			}	
		}

		// close any old custom ports
		if(count($old_ports) >0) $User->ExecFirewall($sid, $os, $fip, $old_ports, "delete", $iptablesconfig);

		// open any new custom port
		if(count($new_ports) >0) $User->ExecFirewall($sid, $os, $fip, $new_ports, "open", $iptablesconfig);
		
		// remove any old or new cvars since we define them below
		if(is_array($firewall_ports) && count($firewall_ports) >0){
			foreach($firewall_ports as $f=>$p){
				if(in_array($p['cvar'], $old_cvars)||in_array($p['cvar'], $new_cvars)) unset($firewall_ports[$f]);
			}
		} else $firewall_ports=array();

		// add new cvars and ports to fireawll array (
		if(is_array($save_ports) && count($save_ports) > 0){
			foreach($save_ports as $s=>$p) $firewall_ports[]=$p;
		}

		// main port changed
		if(is_dir(path."/includes/stats/$ogip-$ogport") && ($ogport && $fport != $ogport || $ogip && $fip != $ogip)) rename(path."/includes/stats/$ogip-$ogport", path."/includes/stats/$fip-$fport");

		// legacy
		if($userGameInfo['subdirectory'] == "yes" && ipsubdir == "true" && ( $ogport && $fport != $ogport || $ogip && $fip != $ogip)){

			$GameCP->loadIncludes("control");
			$Control=new Control();
			$Control->Usergame($gid, "stop");

			/* force stop any similar games on the ip-port */
			$activeSimilar=sql_query($safesql->query("SELECT UG.id FROM usergames UG WHERE UG.ip='%s' AND UG.port='%s' AND UG.cid='%i'", array($fip, $fport, $clientid)));
			$GameCP->loadIncludes("control");
			$Control=new Control();
			while ($similar=mysql_fetch_array($activeSimilar)) $Control->Usergame($similar['id'], "stop");
				
			$Event->EventLogAdd($fname, "User ". $fname. " had game $ugid changed from  $ogip:$ogport to $fip:$fport by ".$_SESSION['gamecp']['userinfo']['name']." ". time());


			/* "smart move" */

			$similiarOldIPPORT=sql_query($safesql->query("SELECT UG.id FROM usergames UG WHERE UG.ip='%s' AND UG.port='%s' AND UG.cid='%i'", array($ogip, $ogport, $clientid)));
			$similar=mysql_num_rows($similiarOldIPPORT);

			$similiarOldIPPORT2=sql_query($safesql->query("SELECT UG.id FROM usergames UG WHERE UG.ip='%s' AND UG.port='%s' AND UG.cid='%i' AND UG.id !='%i'", array($ogip, $ogport, $clientid, $gid)));
			$similarnotthis=mysql_num_rows($similiarOldIPPORT2);

			$userSameGameArray=sql_query($safesql->query("SELECT UG.id FROM usergames UG WHERE UG.ip='%s' AND UG.port='%s' AND UG.gid='%i' AND UG.id !='%i'", array($ogip, $ogport, $gameid, $gid)));
			$similargame=mysql_num_rows($userSameGameArray);

			$similarNewGame=sql_query($safesql->query("SELECT UG.id FROM usergames UG WHERE UG.ip='%s' AND UG.port='%s' AND UG.cid='%i' AND UG.gid = '%i'", array($fip, $fport, $clientid,$userGameInfo['gid'] )));
			$similargamenew=mysql_num_rows($similarNewGame);

			if($os !="1" && $os !="3"){
				$postpremode=str_replace($ogip."-".$ogport, $fip."-".$fport, $postpremode);

				$delscreen="rm -f /home/$fname/screenlog.$ugid /home/$fname/.screenrc.$ugid";

				if($similarnotthis > "0" || $similargame > "0"){
					if($install){
						$Backend->Query($sid, $winport, "command:_:mkdir -p $fip-$fport/$install ; cp -R $ogip-$ogport/$install/* $fip-$fport/$install/", $fname);
						if($similargame == "0") $Backend->Query($sid, $winport, "deldir:_:$ogip-$ogport/$install/", $fname);
						if($similarnotthis == "0") $Backend->Query($sid, $winport, "deldir:_:$ogip-$ogport/", $fname);
					} else {
						$Backend->Query($sid, $winport, "command:_:mkdir $fip-$fport ; cp -R $ogip-$ogport/* $fip-$fport/ ; $delscreen", $fname);
						$Backend->Query($sid, $winport, "command:_:rm -f screenlog.$ugid .screenrc.$ugid", $fname);	
					}

				} else {
					echo "Moving folder.";
					$Backend->Query($sid, $winport, "command:_:mv $ogip-$ogport $fip-$fport", $fname);
					$Backend->Query($sid, $winport, "command:_:rm -f screenlog.$ugid .screenrc.$ugid", $fname);	
				}

			} else {

				if($similarnotthis > "0" || $similargame > "0"){
					if($install){
						if($similargamenew == "0") $Backend->Query($sid, $winport, "mkdir:_:\$MAINDIR\home\\$fname\\$fip-$fport\\$install");
						$Backend->Query($sid, $winport, "copydir:_:\$MAINDIR\home\\$fname\\$ogip-$ogport\\$install\:_:\$MAINDIR\home\\$fname\\$fip-$fport\\$install");
						if($similargame == "0") $Backend->Query($sid, $winport, "deldir:_:\$MAINDIR\home\\$fname\\$ogip-$ogport\\$install\\");
						if($similarnotthis == "0") $Backend->Query($sid, $winport, "deldir:_:\$MAINDIR\home\\$fname\\$ogip-$ogport\\");
					} else {
						$Backend->Query($sid, $winport, "mkdir:_:\$MAINDIR\home\\$fname\\$fip-$fport");
						$Backend->Query($sid, $winport, "copydir:_:\$MAINDIR\home\\$fname\\$ogip-$ogport:_:\$MAINDIR\home\\$fname\\$fip-$fport");
					}
				} else $Backend->Query($sid, $winport, "movedir:_:\$MAINDIR\home\\$fname\\$ogip-$ogport:_:\$MAINDIR\home\\$fname\\$fip-$fport");


			}
			$ipportchange=true;
		} else $ipportchange=false;

		if($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "2" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4"){

			if($_SESSION['gamecp']['userinfo']['ulevel'] == "4" && !$advedit){
				$fmaxplayers=$userGameInfo['maxplayers'];
				$fclientplayers=$userGameInfo['clientplayers'];
				$factive=$userGameInfo['active'];
				$oldstatus=$userGameInfo['status'];
				$fgid=$userGameInfo['gid'];
			}

			if(!isset($_REQUEST['item']))$_REQUEST['item']=array();
			if(!isset($brandingon)) $brandingon='0';
			if(!isset($feac)) $feac='0';
			if(!isset($feactype)) $feactype='';
			if(!isset($notes)) $notes='';

			sql_query($safesql->query("UPDATE usergames SET  
							premode='%s',
							config = '%s',
							port = '%s',
							ip = '%s', 
							startmap = '%s',
							maxplayers = '%s', 
							clientplayers='%s',
							rconpass='%s',
							$active
							queryport='%i',
							pubpriv='%s',
							logfile='%s', 
							start_time='%s',
							end_time='%s',
							use_sched='%s',
							gametype='%s',
							servername='%s',
							scan='%s',
							affinity='%s',
							vars='%s',
							customvars='%s',
							status='%s',
							useredit='%s',
							priority='%i',
							homepage='%i',
							files='%s',
							firewall='%i',
							branding='%s',
							brandingon='%i',
							billingid='%i',
							gid='%i',
							eac='%i',
							eactype='%i',
							stopempty='%i',
							suspend='%s',
							permissions='%s',
							defaultinfo='%s',
							fastdl='%s',
							ports='%s', 
							firewallports='%s',
							notes='%s'
						WHERE id = '%s' LIMIT 1",
							array($GameCP->whitelist($postpremode, "clean"),
							$GameCP->whitelist($fconfig, "useredit"),
							$GameCP->whitelist($fport, "int"),
							$GameCP->whitelist($fip,"clean"),
							$GameCP->whitelist($fstartmap, "useredit"),
							$GameCP->whitelist($fmaxplayers, "int"),
							$GameCP->whitelist($fclientplayers, "int"),
							$GameCP->whitelist($frconpass, "clean"),
							$GameCP->whitelist($fqueryport, "int"),
							$GameCP->whitelist($pubpriv, "clean"),
							$GameCP->whitelist($flogfile, "clean"),
							$GameCP->whitelist(strtotime($start_time), "clean"),
							$GameCP->whitelist(strtotime($end_time), "clean"),
							$GameCP->whitelist($use_sched, "clean"),
							$GameCP->whitelist($fgametype, "clean"),
							$GameCP->whitelist($fservername, "clean"),
							$GameCP->whitelist($fscan, "clean"),
							$GameCP->whitelist($affy, "clean"),
							$cvars,
							$customvars,
							$GameCP->whitelist($fstatus, "clean"),
							$GameCP->whitelist($usereditsci, "clean"),
							$GameCP->whitelist($priority, "int"),
							$GameCP->whitelist($fhomepage, "clean"),
							serialize($_REQUEST['item']),
							$GameCP->whitelist($firewall, "int"),
							$GameCP->whitelist($fbranding, "clean"),
							$GameCP->whitelist($brandingon, "int"),
							$GameCP->whitelist($billingid, "int"),
							$GameCP->whitelist($fgid, "int"),
							$GameCP->whitelist($feac, "int"),
							$GameCP->whitelist($feactype, "int"),
							$GameCP->whitelist($stopempty, "int"),
							$GameCP->whitelist(strtotime($suspend), "clean"),
							$GameCP->whitelist(serialize($permissions), "clean"),
							serialize($defaults),
							$GameCP->whitelist(@$fastdl, "clean"),
							serialize($save_ports),
							serialize($firewall_ports),
							$GameCP->whitelist($notes, "web"),
							$GameCP->whitelist($gid, "int")))) or die(mysql_error());
		/*} elseif($_SESSION['gamecp']['userinfo']['ulevel'] == "4"){
			sql_query($safesql->query("UPDATE usergames SET  
							config = '%s',
							startmap = '%s',
							maxplayers = '%s', 
							clientplayers='%s',
							rconpass='%s',
							servername='%s',
							homepage='%i',
							premode='%s',
							defaultinfo='%s'
						WHERE id = '%s' LIMIT 1",
							array(
							$GameCP->whitelist($fconfig, "useredit"),
							$GameCP->whitelist($fstartmap, "useredit"),
							$GameCP->whitelist($fmaxplayers, "int"),
							$GameCP->whitelist($fclientplayers, "int"),
							$GameCP->whitelist($frconpass, "clean"),
							$GameCP->whitelist($fservername, "clean"),
							$GameCP->whitelist($fhomepage, "clean"),
							$GameCP->whitelist($postpremode, "clean"),
							serialize($defaults),
							$GameCP->whitelist($gid, "int")))) or die(mysql_error());*/

		} else {
			sql_query($safesql->query("UPDATE usergames SET  
							config = '%s',
							startmap = '%s',
							maxplayers = '%s', 
							rconpass='%s',
							servername='%s',
							homepage='%s',
							eac='%i',
							eactype='%i',
							defaultinfo='%s'
						WHERE id = '%s' LIMIT 1",
							array(
							$GameCP->whitelist($fconfig, "useredit"),
							$GameCP->whitelist($fstartmap, "useredit"),
							$GameCP->whitelist($fmaxplayers, "int"),
							$GameCP->whitelist($frconpass, "clean"),
							$GameCP->whitelist($fservername, "clean"),
							$GameCP->whitelist($fhomepage, "clean"),
							$GameCP->whitelist($feac, "int"),
							$GameCP->whitelist($feactype, "int"),
							serialize($defaults),
							$GameCP->whitelist($gid, "int")))) or die(mysql_error());
		}
	} else {

		function CleanVar($value){
			$value=str_replace('`','', $value);
			$value=explode(" +", $value);
			$value=$value[0];
			$value=explode(" -", $value);
			$value=$value[0];
			$value=explode(" ?", $value);
			$value=$value[0];

			return $value;
		}

		/* client update */
		$fname = $_SESSION['gamecp']['userinfo']['username']; 

		/* cvars must merge with the user game cvars  */
		$vars=$_REQUEST['cvar'];
		$varArray=array();
		$varA=array();
		if(is_array($vars)){
			foreach($vars as $var => $val){
				$tcvar =$val['cvar'];
				$varArray[]=$val['cvar'];
				$varA[$tcvar]=CleanVar($val['value']);
			}
		}

		$customvars=$_REQUEST['cvars'];
		$customvarArray=array();
		$customvarA=array();
		if(is_array($customvars)){
			foreach($customvars as $va => $vap){
				$tcpvar =$vap['cvar'];
				$customvarArray[]=$vap['cvar'];
				$customvarA[$tcpvar]=CleanVar($vap['value']);
			}
		}

		$gameInfoQ= sql_query($safesql->query("SELECT G.vars, UG.vars as 'ugvars', UG.customvars, UG.clientplayers, UG.useredit, G.quickmod, G.fsgame, G.id as 'gameid' FROM usergames UG, game G WHERE G.id = UG.gid AND UG.id = '%i' LIMIT 1;", array($GameCP->whitelist($gid, "int")))) or die(mysql_error());
		$gameInfo = mysql_fetch_array($gameInfoQ);
		$gvars=unserialize($gameInfo['vars']);
		$ugvars=unserialize($gameInfo['ugvars']);
		$userCustomVars=unserialize($gameInfo['customvars']);
		$useredit=$gameInfo['useredit'];

		$GameCP->loadIncludes("game");
		$Game=new Game();
		$userGameCvars=$Game->MergeVars($gvars, $ugvars, true);


		if(is_array($userCustomVars)){
			foreach($userCustomVars as $g => $gva){
				$ccvar=$gva['cvar'];
				$ccval=CleanVar($gva['value']);
				$ccuser=$gva['user'];
				if(in_array($ccvar, $customvarArray)) $userCustomVars[$g]['value'] = CleanVar($customvarA[$ccvar]);
			}
		}


		if(is_array($userGameCvars)){
			foreach($userGameCvars as $gv => $gval){
				$cv=$gval['cvar'];
				$cval=$gval['value'];
				if(in_array($cv, $varArray)) $userGameCvars[$gv]['value'] = CleanVar($varA[$cv]);				
			}
		}

		if(!$fmaxplayers) $fmaxplayers=$userGameInfo['maxplayers'];
		$maxplayers=$GameCP->whitelist($fmaxplayers, "int");
		$allowedplayers=$gameInfo['clientplayers'];

		if($maxplayers > $allowedplayers) $maxplayers=$allowedplayers;

		$qm="";
		$sbquickMod=$gameInfo['quickmod'];
		$quickMod=explode("::", $sbquickMod);
		if(is_array($quickMod) && count($quickMod) > "0"){
			$fgametype=$GameCP->whitelist($fgametype);
			if(in_array($fgametype, $quickMod) || $fgametype == $gameInfo['fsgame']) $qm=", gametype='$fgametype'";
		} 

		$permissions=unserialize($userGameInfo['permissions']);
		$tripogdefault=unserialize($userGameInfo['defaultinfo']);
		
		if(!$permissions['eac']){
			$feac=$userGameInfo['eac'];
			$feactype=$userGameInfo['eactype'];
		}

		foreach($defaults as $d => $f) $defaults[$d]=CleanVar($f);

		if(!$permissions['hostname']) $defaults['HOSTNAME']=$userGameInfo['HOSTNAME'];
		if(!$permissions['website']) $defaults['WEBSITE']=$userGameInfo['WEBSITE'];
		if(!$permissions['specpass']) $defaults['SPECPASSWORD']=$userGameInfo['SPECPASSWORD'];
		if(!$permissions['privpass']) $defaults['PRIVPASSWORD']=$tripogdefault['PRIVPASSWORD'];
		if(!$permissions['motd']) $defaults['MOTD']=$tripogdefault['MOTD'];
		if(!$permissions['website']) $defaults['WEBSITE']=$tripogdefault['WEBSITE'];

		if(!$permissions['name']) $fservername=$userGameInfo['servername'];
		if(!$permissions['players']) $maxplayers=$userGameInfo['clientplayers'];
		if(!$permissions['rconpass']) $frconpass=$userGameInfo['rconpass'];
		if(!$permissions['gametype']) $qm=", gametype='".$userGameInfo['gametype']."'";
		if(!$permissions['config']) $fconfig=$userGameInfo['config'];
		if(!$permissions['map']) $fstartmap=$userGameInfo['startmap'];

		sql_query($safesql->query("UPDATE usergames SET  
			config = '%s',
			startmap = '%s',
			maxplayers = '%s',
			rconpass='%s',
			logfile='%s',
			servername='%s',
			vars='%s',
			customvars='%s',
			homepage='%s',
			eac='%i',
			eactype='%i',
			defaultinfo='%s'
			$qm
		WHERE id = '%i' AND cid='%i' LIMIT 1"
			,
		array($GameCP->whitelist(CleanVar($fconfig), "clean"),
			$GameCP->whitelist(CleanVar($fstartmap), "clean"),
			$maxplayers,
			$GameCP->whitelist(CleanVar($frconpass), "useredit"),
			$GameCP->whitelist(CleanVar($flogfile), "clean"),
			$GameCP->whitelist(CleanVar($fservername), "useredit"),
			serialize($userGameCvars),
			serialize($userCustomVars),
			$GameCP->whitelist(CleanVar($fhomepage), "clean"),
			$GameCP->whitelist($feac, "int"),
			$GameCP->whitelist($feactype, "int"),
			serialize($defaults),
			$GameCP->whitelist($gid, "int"),
			$_SESSION['gamecp']['userinfo']['id']))) or die(mysql_error());
			if(isset($_SESSION['gamecp']['userinfo']['permissions']['services']['timeschedule'])){
				sql_query($safesql->query("UPDATE usergames SET
							start_time='%s', 
							end_time='%s',
							use_sched='%s'
							WHERE id = '%s' LIMIT 1",
							array(
								$GameCP->whitelist(strtotime($start_time), "clean"),
								$GameCP->whitelist(strtotime($end_time), "clean"),
								$GameCP->whitelist($use_sched, "clean"),
								$GameCP->whitelist($gid, "int")
				))) or die(mysql_error());
			}

	} 

	/* regular users dont get to modify the start param */
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4" || $useredit == "1") sql_query($safesql->query("UPDATE usergames SET sci='%s' WHERE id = '%i' LIMIT 1;", array($GameCP->whitelist($startparam, "web"), $GameCP->whitelist($gid, "int")))) or die(mysql_error());
	
	$GameCP->loadIncludes("control");
	$Control=new Control();

	if($restart == "yes") $Control->Usergame($gid, "stop");
	
	/* create the start script */
	if($os == "1"){
		/* if game was in debugging delete teh bat */
		if($_REQUEST['fstatus'] != $_REQUEST['oldstatus'] && $_REQUEST['oldstatus'] == "1"){
			if($subdirectory == "yes"){ 
				$homepath="\$MAINDIR/home/$fname/$thesubdir/".$gameInfo['winappdir'];
			} else $homepath="\$MAINDIR/home/$fname/".$gameInfo['winappdir'];
			$Backend->Query($sid, $winport, "deletefile:_:$homepath\debug$gid.bat:_:$batCommand");
		}

		/* update the ftpd */
		$GameCP->loadIncludes("backend");
		$Backend->UpdateFTP($sid);
	}

	$hook_vars=$_REQUEST;
	run_hook("edit_game");

	if($restart == "yes" || $ipportchange==true) $Control->Usergame($gid, "start");
	
	if(eac == "1") {
		require_once(path.'/includes/core/classes/games/eac.inc.php');
		$EAC = new EAC();
		if($EAC->Check($userGameInfo['gid'])) $EAC->Build();
	}

	if(!$doajax){
		if(debugging =="0") { 
			$opt="edit";
			$mode="edit2";
			$ggid=$gid;
		} else echo "User game has been updated.";
	}
} 

if($mode == "addaddon") { 
	if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($gmid, $_SESSION['gamecp']['subuser']['games'])) exit;
	if(isset($_SESSION['gamecp']['subaccount']) && !in_array("1", $_SESSION['gamecp']['subuser']['perms'])){
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$Panel->ErrorExit("Incorrect permission");
	}

	$addonInfoQ = sql_query($safesql->query("SELECT A.notes, A.doupdate, A.doinstall, A.douninstall, A.doenable, A.dodisable, A.name FROM addons A WHERE A.id = '%i' LIMIT 1;", array($GameCP->whitelist($aid, "int")))) or die(mysql_error());
	$addonInfo = mysql_fetch_array($addonInfoQ);

	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$gameInfo=$Panel->GetUserGame($gmid);
	$smarty->assign("fname", $gameInfo['username']);
	$smarty->assign("fip", $gameInfo['ip']);
	$smarty->assign("fport", $gameInfo['port']);

	$GameCP->loadIncludes("game");
	$Game=new Game();
	$addonInfo['notes'] = $Game->ReplaceAllVars($gmid, $addonInfo['notes']);

	$smarty->assign("addonInfo", $addonInfo);
	$smarty->assign("gmid", $gmid);
	$smarty->assign("aid", $aid);
	$smarty->display("manageusergames/addon-confirm.tpl");
}

if($mode == "addaddon2") { 
	if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($_REQUEST['gmid'], $_SESSION['gamecp']['subuser']['games'])) exit;
	if(isset($_SESSION['gamecp']['subaccount']) && !in_array("1", $_SESSION['gamecp']['subuser']['perms'])){
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$Panel->ErrorExit("Incorrect permission");
	}
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$gameInfo=$Panel->GetUserGame($_REQUEST['gmid']);
	$smarty->assign("fname", $gameInfo['username']);
	$smarty->assign("fip", $gameInfo['ip']);
	$smarty->assign("fport", $gameInfo['port']);

	$smarty->assign("gmid", $gmid);
	$smarty->assign("aid", $aid);


	$cid=$_POST['cid'];
	$GameCP->loadIncludes("game");
	if(isset($_SESSION['gamecp']['addon'][$aid])) unset($_SESSION['gamecp']['addon'][$aid]);
	$Game=new Game();
	$Game->Addon($cid, $gmid, $aid, $addonmode);
}

if($mode == "checkaddonstatus"){

	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$gameInfo=$Panel->GetUserGame($ugid);
	$fname=$gameInfo['username'];

	$serverDetails=$Panel->GetServer('', $gameInfo['ip']);
	$sid=$serverDetails['sid'];

	$GameCP->loadIncludes("game");
	$Game=new Game();

	if($serverDetails['os']== "1"){
		$status=array();
		$status[0]="installing";
		if($Game->CheckInstallExists($sid, "\$MAINDIRhome\\$fname\\$ugid-addon.gcp") == true) $status[0]="";
	} else {
		$GameCP->loadIncludes("linux");
		$Linux=new Linux();
		$status=$Linux->Watch($sid, $ugid, $fname, true, true, false);
	}


	if($serverDetails['os']== "1"){
		$scriptlog="\$MAINDIRhome\\$fname\\$ugid-addon.log";
		if($Game->CheckInstallExists($sid, $scriptlog) == true)$log=$Backend->QueryResponse($sid, '', "readfile:_:$scriptlog");
	} else $log=$Backend->QueryResponse($sid, '', "readfile:_:/home/$fname/screenwatch$ugid.log", $fname);

	if($status[0] != ""){

	} else {
		echo "completed:_:";
		if(!isset($_SESSION['gamecp']['addon'][$aid]['ran'])){
			$_SESSION['gamecp']['addon'][$aid]['ran']=true;

			if($_SESSION['gamecp']['addon'][$aid]['start'] == "1"){
				echo "Starting server.";
				$GameCP->loadIncludes("control");
				$Control=new Control();
				$Control->Usergame($ugid, "start");
			}

			if($serverDetails['os']== "1"){
				$script="\$MAINDIRhome\\$fname\\$ugid-addon.bat";
				$script2="\$MAINDIRhome\\$fname\\$ugid-addon-2.bat";
				$lock="\$MAINDIRhome\\$fname\\$ugid-addon.gcp";

				$Backend->Query($sid, '', "deletefile:_:$script");
				$Backend->Query($sid, '', "deletefile:_:$lock");
				$Backend->Query($sid, '', "deletefile:_:$script2");
				$Backend->Query($sid, '', "deletefile:_:$scriptlog");
				
			} else {
				$Backend->Query($sid, '', "deletefile:_:/home/$fname/screenwatch$ugid.log", $fname);
				$Backend->Query($sid, '', "deletefile:_:/home/$fname/.screenrc.watch$ugid", $fname);
			}
		}
		

	}
	if(trim($log)) echo "<div id='statusfinished' class='updatelog'>".nl2br($GameCP->whitelist(trim($log), "striptags"))."</div>";
}

if($mode == "edit") { 
	if(isset($_REQUEST['status'])) $_REQUEST['status']=$GameCP->whitelist($_REQUEST['status'], "text");

	 $_SESSION['gamecp']['backtolist']="userservices.php";

	$sortQ='';
	if(!isset($_REQUEST['idd'])) { 
		if(!isset($_SESSION['gamecp']['usrsrv_cid'])) $sortCid = "0";
	}else $_SESSION['gamecp']['usrsrv_cid']=$GameCP->whitelist($_REQUEST['idd'], "int");
	$sortCid=@$_SESSION['gamecp']['usrsrv_cid'];
	if(!isset($sortCid)) $sortCid = "0";
	if($sortCid && $sortCid !="reset") $sortQ=" AND UG.cid = '$sortCid'";

	/* remember we wanted to see all, right? */
	if(isset($_REQUEST['view']) && $_REQUEST['view'] == "all"){
		$_SESSION['gamecp']['view']['manageserver']="all";
	}elseif(isset($_REQUEST['view']) && $_REQUEST['view'] == "default") $_SESSION['gamecp']['view']['manageserver']="";
	if(isset($_SESSION['gamecp']['view']['manageserver']) && $_SESSION['gamecp']['view']['manageserver'] == "all") $_REQUEST['view']="all";

	$smarty->assign("sortS", $sortQ);
	$smarty->display("modules/server-listusergame.tpl");
}

if($mode == "newgame2" && DEMO != "yes") { 
	if(!$cuser) die("Please select a user.");

	if($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "2" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4") {

		if($_SESSION['gamecp']['userinfo']['ulevel'] == "4"){
			$resQ=" AND rsid = ". $_SESSION['gamecp']['userinfo']['id'];
		} else $resQ="";



		if(isset($_COOKIE["gcp-newuser-field"])){
			$cookie=$_COOKIE["gcp-newuser-field"];
			$cookieArray = explode("-", $cookie);
			$asendinf=$cookieArray[0];
			$adoqueue=$cookieArray[1];
			$astartserver=$cookieArray[2];
			$aloginpath=$cookieArray[3];
			$afmip=$cookieArray[4];
			$afmaxclients=$cookieArray[5];
			$afshared=$cookieArray[6];
			$validQ = sql_query("SELECT ip, name, sid FROM servers WHERE ts2='1' OR vent='1'") or die(mysql_error());
		}



		/* default settings */
		$defaultInfoQ=sql_query($safesql->query("SELECT UG.ip, UG.port, I.sid, S.os FROM iptable I, usergames UG, servers S  WHERE UG.ip = I.ip AND UG.cid='%i' AND I.sid = S.sid LIMIT 1", array($cuser)));
		$defaultInfo = mysql_fetch_array($defaultInfoQ);
				
		$cip = $defaultInfo['ip']; 
		$cport = $defaultInfo['port'];
		$csid = $defaultInfo['sid'];
		$os=$defaultInfo['os'];



		/* user information */
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$userInfo=$Panel->GetUser($cuser);
		$gcid=$cuser;
		$fname=$userInfo['name'];
		$flimit=$userInfo['limit'];

		$gInfo = sql_query($safesql->query("SELECT name, map, queryport, maxplayers, config, port, vars FROM game WHERE id ='%i' LIMIT 1;", array($gmid))) or die(mysql_error());
		$gInfo = mysql_fetch_array($gInfo);


		$defaultport=$gInfo[5];
		if(!$cport) $cport=$defaultport;
		$gvars=unserialize($gInfo['vars']);
		if(is_array($gvars)){
			$vars=array();
			foreach($gvars as $gv => $gval){
				$gval['val']=$gval['value'];
				$vars[]=$gval;
			}

			$smarty->assign("gamevars", $vars);
		}

		$GameCP->loadIncludes("display");
		$Display=new Display();

		$smarty->assign("fname", $fname);
		$smarty->assign("gInfo", $gInfo);
		$smarty->assign("gameInfo", $gInfo);
		$smarty->assign("astartserver", $astartserver);
		$smarty->assign("os", $os);
		$smarty->assign("flimit", $flimit);
		$smarty->assign("csid", $csid);
		$smarty->assign("cip", $cip);
		$smarty->assign("cport", $cport);
		$smarty->assign("cuser", $cuser);
		$smarty->assign("defaultport", $defaultport);
		$smarty->assign("queryport", $gInfo[2]);
		$smarty->assign("afshared", $afshared);
		$smarty->assign("machineIPList", $Display->MachineIPList(true));
		$smarty->assign("gmid", $gmid);
		$smarty->display("manageusergames/addgame-new.tpl");

	} // end userlevel
}

if($opt == "addaddon") {  
	if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($_REQUEST['ggid'], $_SESSION['gamecp']['subuser']['games'])) exit;
	if(isset($_SESSION['gamecp']['subaccount']) && !in_array("1", $_SESSION['gamecp']['subuser']['perms'])){
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$Panel->ErrorExit("Incorrect permission");
	}
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();

	if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "2" && $_SESSION['gamecp']['userinfo']['ulevel'] != "4" && $_SESSION['gamecp']['userinfo']['ulevel'] != "5"){
		$adminQ=" AND A.adminonly = '0'";
	} else $adminQ="";

	$addonList=array();

	$catQ = sql_query("SELECT * FROM addoncategorys ORDER BY `rank` ASC") or die(mysql_error());
	while($cats = mysql_fetch_assoc($catQ)){
		$addonCatList=array();
		$resultClient = sql_query($safesql->query("SELECT A.* FROM  addongames AG, addons A, usergames UG, game G  WHERE  UG.gid = G.id AND UG.id='%i' AND A.id = AG.aid AND AG.gid = G.id AND A.category='".$cats['id']."' $adminQ ORDER BY `name` ASC", array($GameCP->whitelist($ggid, "int")))) or die(mysql_error());
		while($al=mysql_fetch_array($resultClient)) $addonCatList[]=$al;
		$addonList[]=array('category' => $cats, 'addons' => $addonCatList);
	}


	/* default addons with no cats */
	$addonCatList=array();
	$resultClient = sql_query($safesql->query("SELECT A.* FROM  addongames AG, addons A, usergames UG, game G  WHERE  UG.gid = G.id AND UG.id='%i' AND A.id = AG.aid AND AG.gid = G.id AND A.category = '0' $adminQ ORDER BY `name` ASC", array($GameCP->whitelist($ggid, "int")))) or die(mysql_error());
	while($al=mysql_fetch_array($resultClient)) $addonCatList[]=$al;
	
	$addonList[]=array('category' => array('title' => $LNG_DEFAULT), 'addons' => $addonCatList);
	
	$ugDetails=$Panel->GetUserGame($GameCP->whitelist($_REQUEST['ggid']));

	$smarty->assign("fcid", $ugDetails['userid']);
	$smarty->assign("addonFullList", $addonList);
	$smarty->assign("ggid", $GameCP->whitelist($ggid));

	$addonstatus=unserialize($ugDetails['addonstatus']);
	$smarty->assign("addonstatus", $addonstatus);


	$smarty->assign("fname", $ugDetails['username']);
	$smarty->assign("fip", $ugDetails['ip']);
	$smarty->assign("fport", $ugDetails['port']);

	$_SESSION['gamecp']['user']['browseGame']=$GameCP->whitelist($ggid, "int");

	$smarty->display("manageusergames/addon-add.tpl");
}

if($opt == "editfiles") {
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$ugDetails=$Panel->GetUserGame($_REQUEST['ggid']);
	$serverDetails=$Panel->GetServer('', $ugDetails['ip']);

	$_SESSION['gamecp']['fileuser']=$ugDetails['username'];
	$_SESSION['gamecp']['filegame']=$_GET['ggid'];
	$_SESSION['gamecp']['filesid']=$serverDetails['sid'];
	$_SESSION['gamecp']['filecid']=$ugDetails['userid'];
	$_SESSION['gamecp']['fmpath']="";

	$path="/home/".$ugDetails['username'];
	if(isset($noheader)){
		$noheader="?noheader=true&mode=cd";
	} else $noheader="";
	header("location: $url/system/files.php$noheader");
}

if($mode == "edit2") { 
	function showBannedIP($ggid){
		global $safesql, $GameCP, $smarty;
		$banIpQ=sql_query($safesql->query("SELECT * FROM ipban WHERE ugid='%i';",  array($GameCP->whitelist($ggid, "int"))));
		$banIp=array();
		while($banIp2=mysql_fetch_array($banIpQ)){
			$banIp[]=$banIp2;
		}
		$smarty->assign("ggid", $GameCP->whitelist($ggid));
		$smarty->assign("banIp", $banIp);
		$smarty->assign("alt", true);
		$smarty->display("manageusergames/banip-list.tpl");
	}

	if($opt == "banipconf") { 
		$GameCP->loadIncludes("game");
		$GameCP->loadIncludes("panel");
		$Game=new Game();
		$Panel=new Panel();

		$ugDetails=$Panel->GetUserGame($GameCP->whitelist($_REQUEST['ggid'], "int"));
		$gameDetails=$Panel->GetGame($ugDetails['gid']);

		if($ugDetails['firewall'] != "1" || $gameDetails['disablefirewall']=='1') exit;

		$ipfailed = false;
		$ip=gethostbyname($banip); 
		if (($longip = ip2long($ip)) !== false) { 
		  if ($ip == long2ip($longip)){ 
			@$ipfailed = false; 
		  } else { 
			@$ipfailed = true; 
			long2ip($longip); 
		  } 
		} else @$ipfailed = true;

		$banIpQ=sql_query($safesql->query("SELECT * FROM ipban WHERE ugid='%i' AND ip='%s';",  array($GameCP->whitelist($ggid, "int"), $GameCP->whitelist($banip, "useredit"))));

		$badIps=array("localhost", "192.168.1.1", $_SERVER['SERVER_ADDR'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_X_FORWARD_FOR']);

		if($ipfailed != true && mysql_num_rows($banIpQ) == 0 && !in_array($banip, $badIps)){
		
			$Game->BanIP($banip, $ugDetails['ip'], $ugDetails['port'], $_REQUEST['status']);
			sql_query($safesql->query("INSERT INTO ipban SET ugid='%i', `mode`='%s', ip = '%s';",  array($GameCP->whitelist($ggid, "int"), $GameCP->whitelist($status, "useredit"), $GameCP->whitelist($banip, "useredit"))));

		} else {
			echo "<div class='errordiv'>Unable to ban ip, invalid ip.</div>";
		}
		showBannedIP($ggid);
	}

	if($opt == "removebanip") { 
		$GameCP->loadIncludes("game");
		$GameCP->loadIncludes("panel");
		$Game=new Game();
		$Panel=new Panel();
		$ugDetails=$Panel->GetUserGame($_REQUEST['ggid']);
		if($ugDetails['firewall'] != "1") exit;
		$Game->BanIP($banip, $ugDetails['ip'], $ugDetails['port'], "REMOVE");
		sql_query($safesql->query("DELETE FROM ipban WHERE ip='%s';",  array($GameCP->whitelist($banip, "useredit"))));
	
		showBannedIP($ggid);

	}

	if($opt == "move") { 
		if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "2") die("Admin/Manager level required.");

		$_SESSION['gamecp']['user']['browseGame']=$GameCP->whitelist($ggid, "int");

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$ugDetails=$Panel->GetUserGame($ggid);
		
		$smarty->assign("gameInfo", $ugDetails);


		$serverDetails=$Panel->GetServer('', $ugDetails['ip']);
		$fname=$ugDetails['username'];

		$GameCP->loadIncludes("display");
		$Display=new Display();

		if(isset($_SESSION['movegame'])) unset($_SESSION['movegame']);

		$smarty->assign("fname", $fname);
		$smarty->assign("ggid", $ggid);

		if($serverDetails['os'] == '1'){
			$sos="0' AND os != '2";
		} else $sos="1";


		$smarty->assign("machineList", $Display->MachineIPList(true, '', $serverDetails['sid'], $sos));
		$smarty->display("manageusergames/move.tpl");
	}

	if($opt == "move2") { 
		if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "2") die("Admin/Manager level required.");

		// Get & Check vars
		if(!$_POST["fip"] || !$_POST["ggid"]) die('<div class="alert alert-error">IP and usergameid required.</div>');

		$ggid = $_POST["ggid"];
		$fip = $_POST["fip"];

		if(!isset($_REQUEST['port'])){

			$port_result = sql_query($safesql->query("SELECT port FROM usergames WHERE id = '%i'", array($ggid))) or die(mysql_error());
			$port_results = mysql_fetch_array($port_result);

			$fport = $port_results["port"];
		} else $fport=$port;

		$GameCP->loadIncludes("ports");
		$Ports=new Ports();

		$doPort = $Ports->GetPortAuto($fip, $fport);
		
		$ugDetails=$Panel->GetUserGame($ggid);
		$smarty->assign("gameInfo", $ugDetails);

		if($doPort != $fport){

			$smarty->assign("ggid", $ggid);
			$smarty->assign("doPort", $doPort);
			$smarty->assign("fport", $fport);
			$smarty->assign("fip", $fip);
			$smarty->assign("fname", $fname);
			$smarty->assign("notify", $notify);

			$smarty->display("manageusergames/move-portfailed.tpl");

		 } else { $opt = "move3"; }
	}

	if($opt == "move3") { 
		if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "2") die("Admin/Manager level required.");
		$_SESSION['movegame']=$ggid;
		$smarty->assign("ggid", $ggid);
		$smarty->assign("fport", $fport);
		$smarty->assign("fip", $fip);
		$smarty->assign("fname", $fname);
		$smarty->assign("swapip", @$swapip);
		$smarty->assign("swapip2", @$swapip2);
		$smarty->assign("notify", $notify);

		$ugDetails=$Panel->GetUserGame($ggid);
		$smarty->assign("gameInfo", $ugDetails);


		$smarty->display("manageusergames/move-confirm.tpl");
	}

	if($opt == "movecheck"){
		if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "2") die("Admin/Manager level required.");
		if(!isset($_SESSION['movegame'])) die("Missing session variable for moving.");

		$GameCP->loadIncludes("game");
		$Game=new Game();
		$moveStatus=$Game->MoveCheck($_SESSION['movegame']);
	}

	if($opt == "move4") { 
		if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "2") die("Admin/Manager level required.");
		$GameCP->loadIncludes("game");
		$Game=new Game();

		$userIdQ = sql_query($safesql->query("SELECT cid, ip FROM usergames WHERE id ='%i' LIMIT 1;", array($ggid))) or die(mysql_error());
		$idd = mysql_fetch_row($userIdQ);

		$ugDetails=$Panel->GetUserGame($ggid);
		$smarty->assign("gameInfo", $ugDetails);

		$result=$Game->Move($ggid, $fip, $fport);

		if($notify == "yes"){
			$GameCP->loadIncludes("email");

			$Email->templatename = "Service-Moved";
			$Email->GetTemplateStuff();
			$Email->userid = $idd[0];

			$Email->usegamedata = true;
			$Email->usevoicedata = true;
			$Email->usebilldata = true;
			$extravars=array();
			$extravars[]=array("var" => "\$Var1", "value" => $fip.":".$fport);
			$extravars[]=array("var" => "\$Var2", "value" => $ggid);
			$content=$Email->ReplaceStuff($extravars);

			$Email->send();

			sql_query($safesql->query("INSERT INTO ttsystem SET title='%s', subject='%s', date='%s', cid='%i', status='Open', resolved='No', message='%s', updated='%s', reply='', summary='Service Moved'", 
				array($content[0], $content[0], time(), $idd[0], $content[1], time())));
			

		} // end notify

		if($swapip == "yes") sql_query($safesql->query("UPDATE `iptable` SET `assigned`='0' WHERE ip='%s'", array($idd[1])));
		if($swapip2 == "yes") sql_query($safesql->query("UPDATE `iptable` SET `assigned`='1' WHERE ip='%s'", array($fip)));
		


		$smarty->assign("ggid", $ggid);
		$smarty->assign("result", $result);

		$smarty->display("manageusergames/move-complete.tpl");
	}
	
	if($opt == "removeconfirmd") {  
		if(DEMO == "yes") die("Demo restricted.<br>");
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$ugDetails=$Panel->GetUserGame($_REQUEST['ggid']);
		$idd=$ugDetails['userid'];

		if($_POST['doit'] == $LNG_SHOWYES){
			$ggid=$_POST['ggid'];
			$ggid=$GameCP->whitelist($ggid, "int");
			if(isset($_POST['removeUserAccount']) && $_POST['removeUserAccount'] == "1"){
				$rem=true;
			} else $rem=false;

			$GameCP->loadIncludes("user");
			$User=new User();

			$dorm=true;
			$dorm2=false;

			if(isset($_REQUEST['removefiles'] ) && $_REQUEST['removefiles'] != "1") $dorm=false;
			if(isset($_REQUEST['removeipport'] ) && $_REQUEST['removeipport'] == "1")$dorm2=true;
			if(!isset($suspendUser)) $suspendUser=false;
			if(!isset($_POST['removeSubGames'])) $_POST['removeSubGames']=false;
			
			$User->RemoveGame($ggid, $suspendUser, '', $_POST['removeSubGames'], $rem, '', true, '', $dorm, $dorm2);
		}
		if(debugging =="0") header("location: $url/system/".$_SESSION['gamecp']['backtolist']."?idd=$idd");
	} 

	if($opt == "edit") { 
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		if(!$ggid) $Panel->ErrorExit("Missing game id"); 
		if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($ggid, $_SESSION['gamecp']['subuser']['games'])) exit;

		$_SESSION['gamecp']['user']['browseGame']=$GameCP->whitelist($ggid, "int");
		$cid=$_SESSION['gamecp']['userinfo']['id'];
		$userGameInfoArray=array();
		$maxPlayerArray=array();

		if($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "2" && $_SESSION['gamecp']['userinfo']['ulevel'] != "3" && $_SESSION['gamecp']['userinfo']['ulevel'] != "5" && $_SESSION['gamecp']['userinfo']['ulevel'] != "4"){ $cQuery = "AND UG.cid='$cid'"; } else $cQuery="";
		
		$userGameInfoQ=sql_query($safesql->query("SELECT 
			UG.ip,
			UG.port,
			UG.config,
			UG.maxplayers,
			UG.startmap,
			UG.rconpass,
			UG.active,
			UG.queryport,
			UG.pubpriv,
			UG.scan,
			UG.sci,
			UG.logfile,
			UG.clientplayers,
			UG.start_time,
			UG.end_time,
			UG.use_sched,
			UG.scontrol, 
			UG.affinity,
			UG.premode,
			UG.gametype,
			UG.servername,
			UG.vars as 'ugvars',
			G.vars,
			UG.customvars,
			UG.status,
			UG.useredit,
			UG.created,
			UG.cid,
			UG.priority,
			UG.homepage,
			G.name as 'gamename',
			UG.files,
			G.gamemonitor,
			G.quickmod,
			G.fsgame,
			UG.firewall,
			UG.branding,
			UG.brandingon,
			G.gameQcode,
			G.userupdate,
			G.reinstall,
			G.mapimgdir,
			UG.billingid,
			UG.defaultinfo,
			UG.gid, G.id as 'gameid', UG.eac, UG.eactype, UG.stopempty, UG.permissions,  G.disableconsole, G.disableconfigs,
			G.premode as 'gamepremode',
			G.winpremode as 'gamewinpremode',
			G.startmode as 'gamestartmode',
			G.winparams as 'winstartmode', 
			UG.suspend, UG.statscache, UG.statscachetime, UG.fastdl, G.fastdl_compression, G.fastdl_sync, G.fastdl_enable, G.usermapdir, G.disablefirewall, UG.ports, UG.notes, G.protocol

			FROM usergames UG, game G WHERE G.id = UG.gid AND UG.id ='%i' $cQuery LIMIT 1", array($GameCP->whitelist($ggid, "int")))) or die(mysql_error());

		$userGameInfo = mysql_fetch_array($userGameInfoQ); 

		if(mysql_num_rows($userGameInfoQ) == 0){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->ErrorExit("Unable to locate service.");
		}

		$userGameInfo['premode']=$userGameInfo['premode'];
		$userGameInfo['sci']=$userGameInfo['sci'];
		$clientPlayers=$userGameInfo['clientplayers'];
		$maxClients=$userGameInfo['maxplayers'];
		$fsgame=$userGameInfo['fsgame'];
		$mapdir=$userGameInfo['mapimgdir'];
		$ugIP=$userGameInfo['ip'];
		$fcid=$userGameInfo['cid'];
		$vars=unserialize($userGameInfo['vars']);
		$ugvars=unserialize($userGameInfo['ugvars']);
		$customvars=unserialize($userGameInfo['customvars']);
		$defaultinfo=unserialize($userGameInfo['defaultinfo']);
		$userDetails=$Panel->GetUser($userGameInfo['cid']);
		$fname=$userDetails['name'];

		if(!$GameCP->UserCanEdit($fcid)){
			$GameCP->loadIncludes("panel");
			$Panel=new Panel();
			$Panel->ErrorExit("You do not have permission to view this page.");
		}

		if(is_array($customvars)){
			foreach($customvars as $v => $i){
				if(!isset($i['user'])) $i['user']='0';
				if($_SESSION['gamecp']['userinfo']['ulevel'] != "0" || $i['user'] == "1")  $userCustomCvars[]=array("user" => $i['user'], "cvar" => $i['cvar'], "value" => $GameCP->whitelist($i['value'], "clean"));
			}
		}

		$GameCP->loadIncludes("game");
		$Game=new Game();
		$userGameCvars=$Game->MergeVars($vars, $ugvars);

		$affinity=explode(",", $userGameInfo['affinity']);
		if(is_array($affinity)){
			foreach($affinity as $af){
				if($af) $smarty->assign("af".$af, "1");
			}
		}

		$serverInfoQ = sql_query($safesql->query("SELECT S.sid, S.os, S.location, S.position, S.servernotes, S.shownotes, S.alias, S.ftpport FROM iptable I, servers S WHERE I.sid = S.sid AND I.ip = '%s' LIMIT 1;", array($GameCP->whitelist($ugIP, "clean")))) or die(mysql_error());
		$serverInfo = mysql_fetch_array($serverInfoQ); 
		$sid = $serverInfo['sid'];
		$os = $serverInfo['os'];
		$position = $serverInfo['position'];

		if($os == "1"){
			$smarty->assign("gamepremode", $userGameInfo['gamepremode']);
			$smarty->assign("gamestartmode", $userGameInfo['winstartmode']);
		} else {
			$smarty->assign("gamepremode", $userGameInfo['gamepremode']);
			$smarty->assign("gamestartmode", $userGameInfo['gamestartmode']);
		}

		if($_SESSION['gamecp']['userinfo']['ulevel'] != "0"){
			$GameCP->loadIncludes("display");
			$Display=new Display();
			$ipResultArray=$Display->MachineIPList(true, '', '', '', $sid);
			$smarty->assign("ipList", $ipResultArray);
		}

		$i="1";
		while($clientPlayers >= $i) { 
			$maxPlayerArray[]=$i;
			$i++;
		}

		$banIpQ=sql_query($safesql->query("SELECT * FROM ipban WHERE ugid='%i';",  array($GameCP->whitelist($ggid, "int"))));
		$banIp=array();
		while($banIp2=mysql_fetch_array($banIpQ)) $banIp[]=$banIp2;
		$gInfoq = sql_query("SELECT id, name FROM game ORDER BY name ASC") or die(mysql_error());
		$gInfo=array();
		while($gInfoa = mysql_fetch_array($gInfoq)) $gInfo[]=$gInfoa;

		$smarty->assign("shownotes", $serverInfo['shownotes']);
		$smarty->assign("servernotes", $serverInfo['servernotes']);
		$smarty->assign("alias", $serverInfo['alias']);
		$smarty->assign("ftpport", $serverInfo['ftpport']);
		$smarty->assign("sid", $serverInfo['sid']);
		$smarty->assign("gameList", $gInfo);
		$smarty->assign("maxPlayerArray", $maxPlayerArray);
		$smarty->assign("banIp", $banIp);
		$smarty->assign("userGameInfo", $userGameInfo);
		$smarty->assign("userGameCvars", $userGameCvars);
		$smarty->assign("userCustomCvars", @$userCustomCvars);
		$smarty->assign("ggid", $ggid);
		if($userGameInfo['files']) $smarty->assign("files", unserialize($userGameInfo['files']));
		$smarty->assign("priority", $userGameInfo['priority']);
		$smarty->assign("fname", $fname);
		$smarty->assign("fcid", $fcid);
 		$smarty->assign("os", $os);
 		$smarty->assign("position", $position);
 		$smarty->assign("defaultinfo", $defaultinfo);
 		$smarty->assign("location", $serverInfo['location']);

		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		if($os == "1"){
			$cores=$Backend->QueryResponse($sid, '', "getcores:_:");
		} else $cores=$Backend->QueryResponse($sid, '', "command:_:cat /proc/cpuinfo | grep processor -c");
 		$smarty->assign("cores", $cores);

		$n=array();
		$dports=unserialize($userGameInfo['ports']);
		if(is_array($dports) && count($dports) >0){
			foreach($dports as $id => $p) $n[]=$p;
 			$smarty->assign("ports", $n);
		}

		$sbquickMod=$userGameInfo['quickmod'];
		$quickMod=explode("::", $sbquickMod);
		if(is_array($quickMod) && count($quickMod) > 0){
			$qm2=array();
			$qm2[]=$userGameInfo['fsgame'];
			foreach($quickMod as $qm){
				if($qm && $qm != $userGameInfo['gametype']) $qm2[]=$qm;
			}
			$smarty->assign("quickMod", $qm2);
		} else $smarty->assign("quickMod", "");

		if(DIRECTORY_SEPARATOR == '\\'){
			$statsdir="../includes/stats/".$userGameInfo['ip']."-".$userGameInfo['port']."";
			$statsdir2=$userGameInfo['ip']."-".$userGameInfo['port'];
		} else {
			$statsdir="../includes/stats/".$userGameInfo['ip'].":".$userGameInfo['port']."";
			$statsdir2=$userGameInfo['ip'].":".$userGameInfo['port'];
		}

		$smarty->assign("statsdir", $statsdir);
		$smarty->assign("statsdir2", $statsdir2);

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$smarty->assign("Panel", $Panel);

		$smarty->assign("permissions", unserialize($userGameInfo['permissions']));
		$smarty->assign("statscache", unserialize($userGameInfo['statscache']));
		$smarty->assign("statscachetime", $userGameInfo['statscachetime']);

		$smarty->assign("showmap", true);
		if(!isset($livestats)) $livestats=false;
		$smarty->assign("livestats", $livestats);
		if(is_file($statsdir."/graph.rrd")) $smarty->assign("showstats", "true");
		if(is_dir(path."/tracker")){
			$_REQUEST['q']=$ggid;
			$smarty->assign("gcptracker", true); 
		}
		if(eac == "1") {
			require_once(path.'/includes/core/classes/games/eac.inc.php');
			$EAC = new EAC();

			if($EAC->Check($userGameInfo['gameid'])) $smarty->assign("eac0", true); 
		}

		$locallist='';
		$result = sql_query("SELECT webservices, sid FROM servers WHERE webroot !='' ORDER BY 'location'") or die(mysql_error());
		while ($row = mysql_fetch_array($result)){ 
			$s=unserialize($row['webservices']);
			if(isset($s['fastdl'])){
				if($row['sid'] == $userGameInfo['fastdl']){
					$sel="selected=selected";
				} else $sel='';
				$locallist.= "<option value=\"". $row['sid'] ."\" $sel>". $row['sid']."</option>"; 
			}
		}
		$smarty->assign("fastdllist", $locallist);

		if($userGameInfo['fastdl']){
			$dlserverInfo=$Panel->GetServer($userGameInfo['fastdl']);
			$fastdlurl=$dlserverInfo['webrooturl']."/fastdl/$ggid/".$userGameInfo['usermapdir'];
			$smarty->assign("fastdlurl", $fastdlurl);
		}

		/* bukkit plugins

		$GameCP->loadIncludes("bukkit");
		$Bukkit=new Bukkit();
		$pluginList=$Bukkit->GetList();
		$existingPluginList=$Bukkit->GetExistingList($GameCP->whitelist($ggid, "int"));
		print_r($existingPluginList);
		$smarty->assign("pluginList", $pluginList);
		*/
		$usrInfo=$Panel->GetUser($fcid);
		$fpassword=$usrInfo['password'];

		$smarty->assign("fpassword", $fpassword);
		$smarty->assign("userinfo", $userDetails);
		$smarty->display("manageusergames/usergame-edit.tpl");
	} 
} // end if mode == edit2(requires opt)

require_once(path.'/includes/core/editable/footer.inc.php');

?>