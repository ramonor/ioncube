<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

require('../includes/core/includes/user/session.inc.php');
if(@$_REQUEST['consoleDisplay'] == "detached") $noheader=true;
require('../includes/config.inc.php');

$GameCP->CheckPermissions('console');

$smarty->assign('page_title', $LNG_USERGAMEMANAGEMENT);

if(isset($_SESSION['gamecp']['subaccount']) && !in_array('9', $_SESSION['gamecp']['subuser']['perms'])){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("Invalid access");
}

if(!isset($gid)){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("Missing service id"); 
}


$GameCP->UserGameAccess($gid, "usergames");

$result = sql_query($safesql->query("SELECT 
						UG.ip,
						UG.port,
						G.scontrolname,
						U.name,
						G.name as 'gname',
						G.protocol, 
						UG.id as 'gid',
						I.sid,
						G.gcode,
						S.os as 'gcode',
						UG.maxplayers as 'mplayers',
						UG.queryport, 
						UG.logfile, 
						G.id as 'rgid', 
						U.id as 'userid', 
						U.rsid,
						S.sshport, 
						U.bash 
					FROM
						users U, usergames UG, game G, iptable I, servers S 
					
					WHERE 
						U.id = UG.cid
						AND UG.gid = G.id
						AND I.ip = UG.ip
						AND U.id=UG.cid
						AND UG.id='%i'
						AND I.sid=S.sid LIMIT 1;", array($GameCP->whitelist($gid, "int")))) or die(mysql_error());
$row = mysql_fetch_array($result);

$gcodea=$row['gcode'];
$fip=$row[0];
$fport=$row[1];
$fname=$row[3];
$os=$row[9];
$ip=$row['ip'];
$sid=$row['sid'];
$port=$row['port'];
$log=$row['logfile'];
$rgid=$row['rgid'];
$bash=$row['bash'];
$sshport=$row['sshport'];
if(!$log) $log = "screenlog.$gid"; 
$ipport = $ip.":".$port; 



$smarty->assign("sshport", $sshport);
$smarty->assign("row", $row);
$smarty->assign("ip", $ip);
$smarty->assign("sid", $sid);
$smarty->assign("port", $port);
$smarty->assign("gcodea", $gcodea);
$smarty->assign("rgid", $rgid);
$smarty->assign("log", $log);
$smarty->assign("gid", $gid);
$smarty->assign("ipport", $ipport);
$smarty->assign("os", $os);
$smarty->assign("consoleDisplay", $consoleDisplay);
$smarty->assign("ucid", $ucid);
$smarty->assign("fname", $fname);
$smarty->assign("bash", $bash);

$smarty->display("gameconsole/gameconsole.tpl");

if(@$_REQUEST['consoleDisplay'] != "detached") require_once(path.'/includes/core/editable/footer.inc.php');

?>