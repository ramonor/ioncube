<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


require('../includes/core/includes/user/session.inc.php');
require('../includes/config.inc.php');

if(!isset($mode) || isset($mode) && !$mode) $mode = "edit";

$GameCP->CheckPermissions('modules');

$GameCP->SetURLCookie();

$smarty->assign('page_title', $LNG_SERVICES);


if(isset($_REQUEST['mid'])){
	$_REQUEST['mid']=$GameCP->whitelist($_REQUEST['mid'], "int");
	$mid=$_REQUEST['mid'];
}
if($_SESSION['gamecp']['userinfo']['ulevel'] != "1"){
	$uQuery = "AND cid='".$_SESSION['gamecp']['userinfo']['id']."'"; 
} else {
	if(isset($_REQUEST['cid'])){
		$uQuery = $safesql->query("AND cid='%i'", array($_REQUEST['cid'])); 
	} else $uQuery='';
}



if($_SESSION['gamecp']['userinfo']['ulevel'] == "1" ){

	if ($mode == "remove") {
		$GameCP->loadIncludes("modules");
		$Modules=new Modules();
		$Modules->SetRecord($mid);
		$Modules->DeleteModuleRecord();

		header("location: ?mode=edit&showSaved=true");
	}

	if ($mode == "update") { 
		$GameCP->loadIncludes("modules");
		$Modules=new Modules();
		$Modules->SetRecord($mid);
		$Modules->UpdateModule($_REQUEST);

		header("location: ?mode=edit2&mid=$mid&showSaved=true");
	}

	if ($mode == "action") { 
		$GameCP->loadIncludes("modules");
		$Modules=new Modules();

		$Modules->SetRecord($mid);
		$Modules->SetModuleData();

		$params=$Modules->params;
		$module=$params['product']['module'];

		$Modules=new Modules($module);
		$Modules->SetRecord($mid);

		$Modules->SetProduct($params['pid']);

		if(isset($_REQUEST['run'])){
			switch($_REQUEST['run']){
				case 'Accept':
					$_result=$Modules->CreateAccount();
				break;
				case 'Suspend':
					$_result=$Modules->SuspendAccount();
				break;
				case 'UnSuspend':
					$_result=$Modules->UnSuspendAccount();
				break;
				case 'Terminate':
					$_result=$Modules->TerminateAccount();
				break;
				case 'Change':
					$_result=$Modules->ChangePackage();
				break;

				default: 
					$_result=$Modules->ExecButton($_REQUEST['run']);
			}
			
			if($_result != 'true'){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				$Panel->Error($_result);
				$mode="edit2";
			} else header("location: ?mode=edit2&mid=$mid&showSaved=true");
		}

	}
}

if ($mode == 'edit'){
	$GameCP->loadIncludes("modules");
	$Modules=new Modules();

	if(isset($_REQUEST['status']) && ($_REQUEST['status'] == "inactive"||$_REQUEST['status'] == "suspended")){
		$sq=" AND status='".$_REQUEST['status']."'";
	} else $sq='';


	$result = sql_query("SELECT * FROM `module_services` WHERE id !='' $uQuery $sq ORDER BY  `id` DESC") or die(mysql_error());
	$list = array();
	while ($row = mysql_fetch_array($result)){
		$Modules->SetRecord($row['id']);
		$Modules->SetModuleData();
		$list[] = $Modules->params;
	}
	$smarty->assign("categories",$list);
	$smarty->display("services/services-list.tpl");
}

if ($mode == 'edit2'){
	$GameCP->loadIncludes("modules");
	$Modules=new Modules();

	$info = sql_query($safesql->query("SELECT * FROM `module_services` WHERE id = '%i' $uQuery", array($GameCP->whitelist($mid, "int")))) or die(mysql_error());
	$pinfo = mysql_fetch_assoc($info);

	$Modules->SetRecord($mid);
	$Modules->SetModuleData();

	$params=$Modules->params;
	$module=$params['product']['module'];

	$Modules=new Modules($module);
	$Modules->SetRecord($mid);

	$smarty->assign('AdminLink', $Modules->AdminLink());
	$smarty->assign('AdminCustomButtonArray', $Modules->AdminCustomButtonArray());
	$smarty->assign('ClientArea', $Modules->ClientArea());

	$smarty->assign('params', $params);

	$customfields=array();
	$savedaddon=unserialize($pinfo['customfieldsog']);
	if(!is_array($savedaddon))$savedaddon=array();

	
	$infoa = sql_query($safesql->query("SELECT * FROM `paddontype` WHERE prodid = '%i'", array($GameCP->whitelist($pinfo['pid'], "int")))) or die(mysql_error());
	while($b=mysql_fetch_assoc($infoa)){
		if(array_key_exists($b['id'], $savedaddon)) $b['selected']=$savedaddon[$b['id']];
		$info = sql_query($safesql->query("SELECT * FROM `paddon` WHERE pid = '%i'", array($GameCP->whitelist($b['id'], "int")))) or die(mysql_error());
		$i=array();
		while($ainfo = mysql_fetch_assoc($info)) $i[]=$ainfo;
		$b['items']=$i;
		$customfields[]=$b;
	}
	$smarty->assign('paddons', $customfields);

	$smarty->assign("mid",$mid);
	$smarty->assign("pinfo",$pinfo);
	$smarty->display("services/services-edit.tpl");

}

require_once(path.'/includes/core/editable/footer.inc.php');

?>