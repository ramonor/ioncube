<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

$loadIndex=true;
require('../includes/core/includes/user/session.inc.php');
require('../includes/config.inc.php');

$GameCP->CheckPermissions('dashboard');

$GameCP->SetURLCookie();

$smarty->assign('page_title', $LNG_HOME);

if(isset($_REQUEST['mode']) && $_REQUEST['mode']=="switch"){
	if(isset($_SESSION['switch_gamecp'])){
		$_SESSION['gamecp']=$_SESSION['switch_gamecp'];
		unset($_SESSION['switch_gamecp']);
	}
	header("location: index.php");
}

$totalPlus="";
$allowedPlus="";
$cid = $_SESSION['gamecp']['userinfo']['id']; 
$ulevel = $_SESSION['gamecp']['userinfo']['ulevel']; 

$loadIndex= "clientindex"; 

if(isset($_REQUEST['loadItem'])){
	$loaditem=$GameCP->whitelist(str_replace("sort_", "", $_REQUEST['loadItem']));	
	$smarty->display('index/sort/'.$loaditem.'.tpl');
} else $smarty->display('index/'.$loadIndex.'.tpl');

/* clear mini and noheads cause this page loads sub pages and over-rides what we want for footer */
if(isset($noheader)) unset($noheader);
if(isset($_REQUEST['mini'])) unset($_REQUEST['mini']);

require(path.'/includes/core/editable/footer.inc.php');

?>