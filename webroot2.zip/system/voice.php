<?php 
/*
        GameCP - Game Server Control Panel
        Copyright (c) 2004 - 2013 All Rights Reserved.  
`       ----------------------------------------------  
        This document is bound under the GameCP Terms 
        of Use and MUST NOT be removed, distributed in any form, released
        or modified, without written permission from GameCP.
 
        The GameCP Terms of Use are agreed to upon installation
        of this software. If you do not agree to them remove GamecP from 
        your system.
        
        
 
        The source code or encoded versions of the source code
        must ONLY exist on approved GameCP Licensed Servers.
 
        This program is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 
*/

 
if(isset($_REQUEST['mode']) && ($_REQUEST['mode'] == "unsuspend" || $_REQUEST['mode'] == "suspend"))$noheader=true;
require('../includes/core/includes/user/session.inc.php');
require('../includes/config.inc.php');

$GameCP->CheckPermissions('voice');

$GameCP->SetURLCookie();

$smarty->assign('page_title', $LNG_VOICEMANAGEMENT);

$GameCP->generateUserList();
$smarty->assign("userList", $GameCP->userList);

if(!isset($mode)) $mode = '';

function gamecp_voiceowner(){
	global $safesql, $GameCP;

	$configOwnerQ=sql_query($safesql->query("SELECT cid FROM uservoice WHERE id = '%i' LIMIT 1;",
		array($GameCP->whitelist($_REQUEST['vid'], "int")))) or die(mysql_error());
	$configOwner=mysql_fetch_array($configOwnerQ);

	if($_SESSION['gamecp']['userinfo']['ulevel'] == "4"){
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$userInfo=$Panel->GetUser($configOwner['cid']);
		if($userInfo['rsid']==$_SESSION['gamecp']['userinfo']['id']) return $_SESSION['gamecp']['userinfo']['id'];
	}
	
	return $configOwner['cid'];
}

$GameCP->loadIncludes("voice");
$Voice=new Voice();
 
if(isset($_SESSION['gamecp']['subaccount'])){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("Invalid access.");
}

if(isset($_REQUEST['vid'])){
	$_REQUEST['vid']=$GameCP->whitelist($_REQUEST['vid'], "int");
	$vid=$_REQUEST['vid'];
}

if(isset($_REQUEST['mode'])) $mode=$_REQUEST['mode'];

if(!$mode){
	if(isset($_REQUEST['cid'])) $smarty->assign("ucid", $GameCP->whitelist($_REQUEST['cid'], 'int'));
	if(isset($_REQUEST['status'])) $_SESSION['gamecp']['user']['browseVoiceStatus']=$GameCP->whitelist($_REQUEST['status'], "useredit");
	$smarty->display("managevoice/managevoice-list.tpl");
	exit;

}

 if($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
	$ucQuery = " AND uservoice.cid='".$_SESSION['gamecp']['userinfo']['id']."'"; 
} else $ucQuery="";
 
if($mode == "removeban" || $mode =="removeallbans" || $mode == "addban"){
	$ts2Result = sql_query($safesql->query("SELECT id FROM uservoice WHERE tssid='%i' $ucQuery LIMIT 1;", array($tssid))) or die(mysql_error());
	$tsResult = mysql_fetch_array($ts2Result);
	$_REQUEST['vid']=$tsResult['id'];
	$vid=$_REQUEST['vid'];
}

if(($_SESSION['gamecp']['userinfo']['ulevel'] == "0" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4") && isset($_REQUEST['vid'])){
	$configOwnerId=gamecp_voiceowner();
	if($configOwnerId != $_SESSION['gamecp']['userinfo']['id']){
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$Panel->ErrorExit("Invalid access");
	}
}
 
if(isset($vid) && $vid){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();

	$ts2Result = sql_query($safesql->query("SELECT * FROM uservoice WHERE id='%i' $ucQuery LIMIT 1;", array($vid))) or die(mysql_error());
	if(mysql_num_rows($ts2Result) == 0){
		$Panel->ErrorExit("Invalid access 1A");
	}
	$tsResult = mysql_fetch_array($ts2Result);
	$fip = $tsResult['ip'];
	$fport = $tsResult['port'];
	
	if(!isset($tssid) && usedarkstarvent !='yes'){
		$machineInfo=$Panel->GetServer('', $fip);
		$sid = $machineInfo['sid'];
	}

	$maxclients = $tsResult['maxclients'];
	$voicetype = $tsResult['voicetype'];
	$billingid = $tsResult['billingId'];
	$ts3token = $tsResult['ts3token'];
	$vvid = $tsResult['api_id'];
	$vvid2 = $tsResult['api_id2'];
	$ucid = $tsResult['cid'];
	$tssid = $tsResult['tssid'];
	$smarty->assign("ucid", $ucid);
} elseif(isset($_REQUEST['mode'])){

	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("Invalid access");
}

if($mode == "removeban" || $mode == "removeallbans" || $mode == "addban" || $mode == "newtoken"){
	$loadban=true;
	if($tssid != "0" && $tssid){
		if($voicetype == "ts3"){
			switch($mode){
				case "removeban":
					$Voice->ExecTeamspeak3("bandel", $banid, $fip, $fport);
				break;
				case "removeallbans":
					$Voice->ExecTeamspeak3("bandelall", "0", $fip, $fport);
				break;
				case "addban":
					$Voice->ExecTeamspeak3("banadd", $banip, $fip, $fport);
				break;
				case 'newtoken':
					$ts3token=$Voice->Teamspeak3NewToken($fip, $fport);
					header("location: voice.php?mode=edit&vid=$vid");
				break;
			}
		} else {
			switch($mode){
				case "removeban":
					$Voice->ExecTeamspeak2("bandel $banid", $fip, $fport);
				break;
				case "removeallbans":
					$Voice->ExecTeamspeak2("banclear", $fip, $fport);
				break;
				case "addban":
					$Voice->ExecTeamspeak2("banadd $banip", $fip, $fport);
				break;
			}
		}
	}
	$smarty->assign("loadban", $loadban);
	$mode = "edit";
}

if($_SESSION['gamecp']['userinfo']['ulevel'] == "1"){
	if ($mode == "unsuspend") { 
		$GameCP->loadIncludes("suspend");
		$Suspend=new Suspend();
		$Suspend->VoiceRestore($vid);
		header("location: voice.php");
	}

	if ($mode == "suspend") { 
		$GameCP->loadIncludes("suspend");
		$Suspend=new Suspend();
		$Suspend->Voice($vid);
		header("location: voice.php?status=suspended");
	}
}

if($mode == "teamspeak"){
	$vid=$GameCP->whitelist($vid, "int");
	$tssid=$GameCP->whitelist($tssid, "int");
	$tsResult=$Voice->GetTeamspeak2Info($vid);

	switch($option){
		case "sendmsg":
			if($message){
				if($voicetype == "ts3"){
					$Voice->MessageTeamspeak2($GameCP->whitelist($message), $tsResult[0], $tsResult[1]);
				} else $Voice->MessageTeamspeak3($GameCP->whitelist($message), $tsResult[0], $tsResult[1]);
			}
		break;
		case "changepass":
			if($_SESSION['gamecp']['userinfo']['ulevel'] != "0"){
				if($voicetype == "ts3"){
					if($Voice->SetTeamspeak3Password($tsResult[3], $fpassword, $tsResult[0], $tsResult[1])){
						sql_query($safesql->query("UPDATE uservoice SET pass = '%s', maxclients='%s', billingId='%s', ts3token='%s', cid='%s' WHERE `id` = '%i' LIMIT 1 ;", array($_REQUEST['fpassword'], $_REQUEST['fmaxclients'], $_REQUEST['billingid'], $_REQUEST['token'], $_REQUEST['cid'], $vid)));
						$Voice->SetTeamspeak3Players($tsResult[3], $fmaxclients, $tsResult[0], $tsResult[1]);
					} else echo "Password changed failed.";
				} else {
					if($fpassword == $fpassword2){
							if($Voice->SetTeamspeak2Password($tsResult[3], $fpassword, $tsResult[0], $tsResult[1])){
								sql_query($safesql->query("UPDATE uservoice SET pass = '%s', maxclients='%s', billingId='%s', cid='%s' WHERE `id` = '%i' LIMIT 1 ;", array($_REQUEST['fpassword'], $_REQUEST['fmaxclients'], $_REQUEST['billingid'], $_REQUEST['cid'], $vid)));
								$Voice->SetTeamspeak2Players($tsResult[3], $fmaxclients, $tsResult[0], $tsResult[1]);
							} else echo "Password changed failed.";
					} else echo "Passwords do not match.";
				}
			}
		break;
	}
	$mode="edit";
}
 
if($mode == "control" && DEMO != "yes"){
        $status = $cmd;
        $active="1";
 
        if($cmd == "serverstop"){
			$cmd = "stop";
			$active="0";
        } else if ($cmd == "serverstart"){
			$cmd = "start";
        } else if ($cmd == "restart"){
			$cmd = "restart";
        } else $cmd = NULL;
        
        if ($cmd != NULL) {
			$GameCP->loadIncludes("control");
			$Control=new Control();

			if($vid && !$tssid){
				$Control->Ventrilo($fip, $fport, $cmd);
			} else $Control->Teamspeak($fip, $fport, $cmd, $tssid); 
			
			sql_query($safesql->query("UPDATE uservoice SET `active`='%s' WHERE id='%i' LIMIT 1;", array($active, $vid))) or die(mysql_error());
        }

		if (preg_match("/voice.php/i", $_SERVER['HTTP_REFERER'])){
			header("location: $url/system/voice.php");
		} else header("location: $url/system/index.php");
}

if($mode == "managevent" && DEMO != "yes"){
	$smarty->assign("billingid", $tsResult['billingId']); 

	if(usedarkstarvent == "yes"){
		$GameCP->loadIncludes("darkstarllc");
	} else {
		$GameCP->loadIncludes("backend");
		$Backend=new Backend();

		$GameCP->loadIncludes("panel");
		$Panel=new Panel();

		$ventIniContents=$Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.ini", 'vent');
		$ventChanContents=$Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.chn", 'vent');
		$ventBanContents=$Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.ban", 'vent');
		$ventUserContents=$Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.usr", 'vent');
		$ventMotdContents=trim($Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.motd", 'vent'));

		require_once(path.'/includes/core/classes/voice/ini.inc.php');
		$iniClass=new Ini();
	}

	if(isset($chan) || isset($action)){ 
		/* save actions */
		if($action == "saveini"){
				if(usedarkstarvent == "yes"){
					$_REQUEST['inivar']['VoiceCodec'] = $_REQUEST['inivar']['VoiceCodec']."-".$_REQUEST['inivar'][VoiceFormat];
					$result=darkstar_saveFile($vvid, $_REQUEST['inivar']);
				} else {
					$iniClass->connect($ventIniContents);
					$iniClass->write($chan, "Name", $_REQUEST['inivar']['Name']);
					$iniClass->write($chan, "Auth", $_REQUEST['inivar']['Auth']);
					$iniClass->write($chan, "Duplicates", $_REQUEST['inivar']['Duplicates']);
					$iniClass->write($chan, "AdminPassword", $_REQUEST['inivar']['AdminPassword']);
					$iniClass->write($chan, "Password", $_REQUEST['inivar']['Password']);
					$iniClass->write($chan, "AutoKick", $_REQUEST['inivar']['AutoKick']);
					$iniClass->write($chan, "LogonTimeout", $_REQUEST['inivar']['LogonTimeout']);
					$iniClass->write($chan, "ChanWidth", $_REQUEST['inivar']['ChanWidth']);
					$iniClass->write($chan, "ChanDepth", $_REQUEST['inivar']['ChanDepth']);
					$iniClass->write($chan, "ChanClients", $_REQUEST['inivar']['ChanClients']);
					$iniClass->write($chan, "TimeStamp", $_REQUEST['inivar']['TimeStamp']);
					$iniClass->write($chan, "DisableQuit", $_REQUEST['inivar']['DisableQuit']);
					$iniClass->write($chan, "SilentLobby", $_REQUEST['inivar']['SilentLobby']);
					$Backend->QueryResponse($sid,  '', "writefile:_:/home/vent/$fip:$fport/ventrilo_srv.ini:_:".$iniClass->fetch(), "vent");
					$iniClass->close();
					$ventIniContents=$Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.ini", 'vent');
				}
				$action = "ini";
		}

		if($action == "saveuser"){
			if($_REQUEST['ventusername']){
					if(usedarkstarvent == "yes"){
						if(isset($_REQUEST['userId']) && $_REQUEST['userId']){
							$data=array("userId" => $_REQUEST['userId']-1, "name" => $_REQUEST['ventusername'], "password" => $_REQUEST['ventpassword'], "ServerAdmin" => $_REQUEST['ventadmin']);
							$result=darkstar_editAction("usr", $vvid, $data);
						} else {
							$data=array("name" => $_REQUEST['ventusername'], "password" => $_REQUEST['ventpassword'], "ServerAdmin" => $_REQUEST['ventadmin']);
							$result=darkstar_createAction("usr", $vvid, $data);
						}
					} else {
						$iniClass2=new Ini();
						$iniClass2->connect($ventUserContents);
						if($chan && $_REQUEST['ventusername'] != $chan) $iniClass2->drop_section($chan);

						$iniClass2->write($_REQUEST['ventusername'], "ServerAdmin", $_REQUEST['ventadmin']);
						$iniClass2->write($_REQUEST['ventusername'], "UserPassword", $_REQUEST['ventpassword']);
						$Backend->QueryResponse($sid,  '', "writefile:_:/home/vent/$fip:$fport/ventrilo_srv.usr:_:".$iniClass2->fetch(), "vent");
						$iniClass2->close();
						$ventUserContents=$Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.usr", 'vent');
						
					}
			}
			$chan=$ventusername;
			$action = "ini";
			$smarty->assign("showSaved", "true"); 
		}

		if($action == "saveban"){
			if(usedarkstarvent == "yes"){
				$data=array("username" => $_REQUEST['user'], "ip" => $_REQUEST['ip'], "reason" => $_REQUEST['reason'], "from" => $_REQUEST['by']);
				$result=darkstar_createAction("ban", $vvid, $data);
			} else {
				$conf=$ip.",".$user.",".$by.",".$reason."\n";
				$out=$ventBanContents."\n".$conf;
				$Backend->QueryResponse($sid,  '', "writefile:_:/home/vent/$fip:$fport/ventrilo_srv.ban:_:$out", "vent");
				$ventBanContents=$Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.ban", 'vent');
			}
			
			$chan=$ip;
			$action = "ini";
			$smarty->assign("showSaved", "true"); 
		}

		if($action == "savechan"){
				if(usedarkstarvent == "yes"){
					$_REQUEST['inivar']['name']=$_REQUEST['chan'];
					$result=darkstar_createAction("chn", $vvid, $_REQUEST['inivar']);
				} else {
					$iniClass->connect($ventChanContents);
					$iniClass->write($chan, "Phonetic", $_REQUEST['inivar']['Phonetic']);
					$iniClass->write($chan, "EncPassChan", $_REQUEST['inivar']['EncPassChan']);
					$iniClass->write($chan, "EncPassAdmin", $_REQUEST['inivar']['EncPassAdmin']);
					$iniClass->write($chan, "Comment", $_REQUEST['inivar']['Comment']);
					$iniClass->write($chan, "TimeLimit", $_REQUEST['inivar']['TimeLimit']);
					$iniClass->write($chan, "MaxClients", $_REQUEST['inivar']['MaxClients']);
					$iniClass->write($chan, "PhantomMode", $_REQUEST['inivar']['PhantomMode']);
					$iniClass->write($chan, "VoiceMode", $_REQUEST['inivar']['VoiceMode']);
					$iniClass->write($chan, "AllowWaveBinds", $_REQUEST['inivar']['AllowWaveBinds']);
					$iniClass->write($chan, "AllowPaging", $_REQUEST['inivar']['AllowPaging']);
					$iniClass->write($chan, "AllowCrossChannelXmit", $_REQUEST['inivar']['AllowCrossChannelXmit']);
					$iniClass->write($chan, "AllowRecording", $_REQUEST['inivar']['AllowRecording']);
					$iniClass->write($chan, "AllowTtsBinds", $_REQUEST['inivar']['AllowTtsBinds']);
					$iniClass->write($chan, "AllowU2U", $_REQUEST['inivar']['AllowU2U']);
					$iniClass->write($chan, "RestrictToUsr", $_REQUEST['inivar']['RestrictToUsr']);
					$iniClass->write($chan, "DisableSoundEvts", $_REQUEST['inivar']['DisableSoundEvts']);
					$Backend->QueryResponse($sid,  '', "writefile:_:/home/vent/$fip:$fport/ventrilo_srv.chn:_:".$iniClass->fetch(), "vent");
					$iniClass->close();
					$ventChanContents=$Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.chn", 'vent');
				}
				$action = "chan";
			}
				  
							
			if($action == "savemotd"){
					if(usedarkstarvent == "yes"){
						$result=darkstar_updateMotd($vvid, $motd);
					} else {
						$Backend->QueryResponse($sid,  '', "writefile:_:/home/vent/$fip:$fport/ventrilo_srv.motd:_:$motd", "vent");
					}
					$action="ini";
			}
			/* end save actions */
			/* remove actions */
			if($action == "removeuser"){
				if($_REQUEST['ventusername']){
					if(usedarkstarvent == "yes"){
						$result=darkstar_deleteAction("usr", $vvid, $_REQUEST['userId']);
					} else {
						$iniClass1=new Ini();
						$iniClass1->connect($ventUserContents);
						$iniClass1->drop_section($_REQUEST['ventusername']);
						$Backend->QueryResponse($sid,  '', "writefile:_:/home/vent/$fip:$fport/ventrilo_srv.usr:_:".$iniClass1->fetch(), "vent");
						$iniClass1->close();
						$ventUserContents=$Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.usr", 'vent');
					}
				}
				$action = "ini";
			}

			if($action == "removechan"){
				if(usedarkstarvent == "yes"){
					$result=darkstar_deleteAction("chn", $vvid, $_REQUEST['chanId']);
				} else {
					$iniClass->connect($ventChanContents);
					$iniClass->drop_section($_REQUEST['chan']);
					$Backend->QueryResponse($sid,  '', "writefile:_:/home/vent/$fip:$fport/ventrilo_srv.chn:_:".$iniClass->fetch(), "vent");
					$iniClass->close();
					$ventChanContents=$Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.chn", 'vent');
				}
			}

			if($action == "removeban"){
				if(usedarkstarvent == "yes"){
						$result=darkstar_deleteAction("ban", $vvid, $_REQUEST['banId']);
				} else {
					$out="";
					$fc=explode("\n", $ventBanContents);
					foreach($fc as $line){
						$d=explode(",", $line);
						if ($d[0] != $user) $out.=$line."\n"; 
					}
					$Backend->QueryResponse($sid,  '', "writefile:_:/home/vent/$fip:$fport/ventrilo_srv.ban:_:$out", "vent");
					$ventBanContents=$Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.ban", 'vent');
				}
				$action="ini";
			}
			/* end remove actions */
			/* write/update actions  */
			if($action == "writechan"){
				if(usedarkstarvent == "yes"){
						$_REQUEST['inivar']['name']=$_REQUEST['chanName'];
						$result=darkstar_editAction("chn", $vvid, $_REQUEST['inivar']);
						$action = "ini";
						$smarty->assign("showSaved", "true"); 
				} else {
					$iniClass->connect($ventChanContents);
					if($chanName != $chan){
						$iniClass->drop_section($chan);
						$chan=$chanName;
					}
					$iniClass->write($chan, "Phonetic", $_REQUEST['inivar']['Phonetic']);
					$iniClass->write($chan, "EncPassChan", $_REQUEST['inivar']['EncPassChan']);
					$iniClass->write($chan, "EncPassAdmin", $_REQUEST['inivar']['EncPassAdmin']);
					$iniClass->write($chan, "Comment", $_REQUEST['inivar']['Comment']);
					$iniClass->write($chan, "TimeLimit", $_REQUEST['inivar']['TimeLimit']);
					$iniClass->write($chan, "MaxClients", $_REQUEST['inivar']['MaxClients']);
					$iniClass->write($chan, "PhantomMode", $_REQUEST['inivar']['PhantomMode']);
					$iniClass->write($chan, "VoiceMode", $_REQUEST['inivar']['VoiceMode']);
					$iniClass->write($chan, "AllowWaveBinds", $_REQUEST['inivar']['AllowWaveBinds']);
					$iniClass->write($chan, "AllowPaging", $_REQUEST['inivar']['AllowPaging']);
					$iniClass->write($chan, "AllowCrossChannelXmit", $_REQUEST['inivar']['AllowCrossChannelXmit']);
					$iniClass->write($chan, "AllowRecording", $_REQUEST['inivar']['AllowRecording']);
					$iniClass->write($chan, "AllowTtsBinds", $_REQUEST['inivar']['AllowTtsBinds']);
					$iniClass->write($chan, "AllowU2U", $_REQUEST['inivar']['AllowU2U']);
					$iniClass->write($chan, "RestrictToUsr", $_REQUEST['inivar']['RestrictToUsr']);
					$iniClass->write($chan, "DisableSoundEvts", $_REQUEST['inivar']['DisableSoundEvts']);
					
					$Backend->QueryResponse($sid,  '', "writefile:_:/home/vent/$fip:$fport/ventrilo_srv.chn:_:".$iniClass->fetch(), "vent");
					$iniClass->close();
					$ventChanContents=$Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.chn", 'vent');
					$action = "chan";
				}
			}

			if($action == "writeban"){
				if(usedarkstarvent == "yes"){   
					$result=darkstar_deleteAction("ban", $vvid, $_REQUEST['banId']);
					$data=array("username" => $_REQUEST['user'], "ip" => $_REQUEST['ip'], "reason" => $_REQUEST['reason'], "from" => $_REQUEST['by']);
					$result=darkstar_createAction("ban", $vvid, $data);
					$action="ini";
					$smarty->assign("showSaved", "true"); 
				} else {
					$out="";
					$fc=explode("\n", $ventBanContents);
					foreach($fc as $line){
						if (strstr($line,$olduser)){
								$out.= $ip .",". $user .",". $by .",". $reason ."\n";
						} else $out.= $line."\n"; 
					}
					$Backend->QueryResponse($sid,  '', "writefile:_:/home/vent/$fip:$fport/ventrilo_srv.ban:_:$out", "vent");
					$ventBanContents=$Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.ban", 'vent');
					$action="ban";
				}
			}
		/* end write/update actions */
		/* read actions */
		if($action == "chan"){
			if(usedarkstarvent == "yes"){
				$darkstarIni=darkstar_retrieveFile("chn", $vvid);
				$chanInfoQ=unserialize(urldecode($darkstarIni['result']));
				$i=0;
				foreach($chanInfoQ as $chanel){
						if($chanel['name'] == $_REQUEST['chan']){
								$vent=$chanel;
								$vent['Name']=$chanel['name'];
								$vent['chanId']=$i;
						}
						$i++;
				}
			} else {
				$iniClass->connect($ventChanContents);
				foreach($iniClass->get_keys($chan) as $a => $key) $vent[$key]=$iniClass->read($chan,  $key);
				$iniClass->close();

			}
			$smarty->assign("vent", $vent); 
		}

		if($action == "ban"){
			if(usedarkstarvent == "yes"){
				$darkstarIni=darkstar_retrieveFile("ban", $vvid);
				$banInfo=unserialize(urldecode($darkstarIni['result']));
				$cnts=array();
				$i=1;
				foreach($banInfo as $ban){
						if($ban['ip'] == $chan){
								if($ban['to'] && $ban['ip']) $cnts[]=array($ban['ip'], $ban['to'],$ban['from'],$ban['reason'], $i);
						}
						$i++;
				}
			} else {
				$contents = $ventBanContents;
				$contents = explode("\n", $contents);
				$cnts=array();

				foreach ($contents as $cont) {
						$cont = explode(",", $cont);
				   if($cont[0] && $cont[1] && $cont[0] == $chan)$cnts[]=$cont;
				}
			}
			$smarty->assign("cont", $cnts); 
		}
			
		if($action == "user"){  
			if(usedarkstarvent == "yes"){
				$darkstarIni=darkstar_retrieveFile("usr", $vvid);
				$userinfoQ=unserialize(urldecode($darkstarIni['result']));
				$i=1;
				foreach($userinfoQ as $usr){
						if($usr['name'] == $chan){
							$vent['Name']=$usr['name'];
							$smarty->assign("ventpass", $usr['EncPass']); 
							$smarty->assign("serveradmin", $usr['ServerAdmin']); 
							$smarty->assign("userId", $i); 
						}
						$i++;
				}
			} else {
				$iniClass->connect($ventUserContents);
				$ventpass=$iniClass->read($chan, "UserPassword");
				$serveradmin=$iniClass->read($chan, "ServerAdmin");
				$iniClass->close();

				$smarty->assign("ventpass", $ventpass); 
				$smarty->assign("serveradmin", $serveradmin); 
			}
		} 
		/* end read actions */
	}

	if(!isset($action)|| (isset($action) && $action=="ini")){
		if(usedarkstarvent == "yes"){
			$darkstarIni=darkstar_retrieveFile("ini", $vvid);
			$vent=unserialize(urldecode($darkstarIni['result']));
			$smarty->assign("vent", $vent['Server']); 
			$smarty->assign("usedarkstarvent", "yes"); 

			$banlist="";
			$userlist="";
			$chanlist="";

			$motdQQ=darkstar_retrieveFile("motd", $vvid);
			$banlistQQ=darkstar_retrieveFile("ban", $vvid);
			$userlistQQ=darkstar_retrieveFile("usr", $vvid);
			$channelsQQ=darkstar_retrieveFile("chn", $vvid);
			if(preg_match("/Error/i", $channelsQQ['result']) ||
					preg_match("/Error/i", $banlistQQ['result']) ||
					preg_match("/Error/i", $userlistQQ['result']) ||
					preg_match("/Error/i", $motdQQ['result'])
					
			){
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				$Panel->ErrorExit("There was an error communicating with this service: <div class='cmdreply'>"
					. "<ul style='text-align: left; font-weight: normal'><li>motd ". urldecode($motdQQ['result'])."</li>"
					. "<li>ban list ". urldecode($banlistQQ['result'])."</li>"
					. "<li>userlist ". urldecode($userlistQQ['result'])."</li>"
					. "<li>channels  ". urldecode($channelsQQ['result'])."</li></ul></div>");
			}

			$motd=unserialize(urldecode($motdQQ['result']));
			$banlistQ=unserialize(urldecode($banlistQQ['result']));
			$userlistQ=unserialize(urldecode($userlistQQ['result']));
			$channelsQ=unserialize(urldecode($channelsQQ['result']));
					
			if(is_array($banlistQ)){
					foreach($banlistQ as $ban){
						$val=$ban['to'];
						$valip=$ban['ip'];
						if($val) $banlist.= "<option value=\"$valip\">$val  &nbsp;&nbsp;&nbsp;- &nbsp;&nbsp;$valip</option>";
					}
			}
			if(is_array($userlistQ)){
					foreach($userlistQ as $usr){
						$val=$usr['name'];
						if($val) $userlist.= "<option value=\"$val\">$val</option>";
					}
			}
			if(is_array($channelsQ)){
					foreach($channelsQ as $chan){
						$val=$chan['name'];
						if($val) $chanlist.= "<option value=\"$val\">$val</option>";
					}
			}

			$smarty->assign("codecs", $codecs); 
			$smarty->assign("channellist", $chanlist); 
			$smarty->assign("banlist", $banlist); 
			$smarty->assign("userlist", $userlist); 
			$smarty->assign("motdini", $motd); 

		} else {

			if(trim($ventIniContents)){
				$vent=parse_ini_string($ventIniContents);
				$smarty->assign("vent", $vent); 
			} else $Panel->ErrorExit("Missing service config");

			if(trim($ventChanContents)){
				$channels="";
				$iniClass->connect($ventChanContents);
				foreach ($iniClass->get_sections() as $key => $val)$channels.= "<option value=\"$val\">$val</option>";
				$iniClass->close();
				$smarty->assign("channellist", $channels); 
			}

			if(trim($ventBanContents)){
				$banlist="";
				$contents = $ventBanContents;
				$contents=str_replace("\r\n", "\n",$contents);
				$contents = explode("\n", $contents);
				foreach ($contents as $cont) {
					$cont = explode(",", $cont);
					if($cont[0] && $cont[1]) $banlist.= "<option value=\"$cont[0]\">$cont[1]  &nbsp;&nbsp;&nbsp;- &nbsp;&nbsp;$cont[0]</option>";
				}
				$smarty->assign("banlist", $banlist); 
			}

			if(trim($ventUserContents)){
				$userlist="";
				$iniClass->connect($ventUserContents);
				foreach ($iniClass->get_sections() as $key => $val) $userlist.= "<option value=\"$val\">$val</option>";
				$iniClass->close();
				$smarty->assign("userlist", $userlist); 
			} 

			if(trim($ventMotdContents)){
				$smarty->assign("motdini", $GameCP->whitelist($ventMotdContents, "useredit")); 
			} 
		}
	}

	$smarty->assign("chan", $chan); 
	$smarty->assign("ip", $ip); 
	$smarty->assign("user", $user); 
	$smarty->assign("action", $action); 
	$smarty->assign("vid", $vid); 
	$smarty->display("managevoice/editvent.tpl");
}

if($mode == "edit"){
	$smarty->assign("billingid", $tsResult['billingId']); 
	$smarty->assign("vid", $vid);
	$smarty->assign("ip", $fip);
	$smarty->assign("billingid", $billingid);
	$smarty->assign("port", $fport);
	if(isset($idd)) $smarty->assign("idd", $idd);
	$smarty->assign("maxclients", $maxclients);
	
	if ($_SESSION['gamecp']['userinfo']['ulevel'] != "1")$_REQUEST['cid']=$ucid;

	if(isset($tssid) && $tssid != "0" && $tssid){
		$smarty->assign("tssid", $tssid);
		$smarty->assign("serverInfo", $tsResult);

		if($voicetype == "ts3"){
			$banList=$Voice->ExecTeamspeak3("banlist", "", $fip, $fport);
			$smarty->assign("banList", $banList);
		} else $smarty->assign("banList", $Voice->ExecTeamspeak2Array("banlist", $fip, $fport));
		$smarty->assign("voicetype", $voicetype);
		$smarty->display("managevoice/teamspeak-edit.tpl");
	} else {
		if(usedarkstarvent == "yes"){
			$GameCP->loadIncludes("darkstarllc");
			$darkstarIni=darkstar_retrieveFile("ini", $vvid);
			$content=array2ini(unserialize(urldecode($darkstarIni['result'])));
			$smarty->assign("usedarkstarvent", "yes");
		} else {
			$GameCP->loadIncludes("backend");
			$Backend=new Backend();
			$content=trim($Backend->QueryResponse($sid, '', "readfile:_:/home/vent/$fip:$fport/ventrilo_srv.ini", 'vent'));
		}
		$smarty->assign("cid", $ucid);

		$smarty->assign("content", $content);
		$smarty->display("managevoice/ventrilo-edit.tpl");
	}
}
 
if ($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "2" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4") { 
	if($mode == "savevent" && DEMO != "yes"){
		if(usedarkstarvent == "yes"){
			/*
				$GameCP->loadIncludes("darkstarllc");
				$darkstarIni=darkstar_saveFile($vvid);
			*/
		} else {
			$GameCP->loadIncludes("backend");
			$Backend=new Backend();
			$Backend->QueryResponse($sid,  '', "writefile:_:/home/vent/$fip:$fport/ventrilo_srv.ini:_:$content", "vent");
		}
		if ($_SESSION['gamecp']['userinfo']['ulevel'] != "1")$_REQUEST['cid']=$ucid;

		sql_query($safesql->query("UPDATE uservoice SET maxclients = '%s', billingId='%s', cid='%s' WHERE `id` = '%i' LIMIT 1;", array(
			$GameCP->whitelist($_REQUEST['vmaxclients'], "int"),
			$GameCP->whitelist($_REQUEST['billingid'], "int"),
			$GameCP->whitelist($_REQUEST['cid'], "int"),
			$GameCP->whitelist($vid, "int"))));
		
	}

	if ($mode == "remove" && DEMO != "yes") { 
		if($Voice->Remove($vid)){
			if (preg_match("/voice.php/i", $_SERVER['HTTP_REFERER'])){
				header("location: $url/system/voice.php?status=".$_SESSION['gamecp']['user']['browseVoiceStatus']);
			} else header("location: $url/system/index.php?status=".$_SESSION['gamecp']['user']['browseVoiceStatus']);
		}
	}
}


 require_once(path.'/includes/core/editable/footer.inc.php');

 ?>