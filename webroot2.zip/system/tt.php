<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

$okExtensions=array();
$okExtensions[]="bmp";
$okExtensions[]="jpg";
$okExtensions[]="gif";
$okExtensions[]="png";
$okExtensions[]="txt";
$okExtensions[]="ini";
$okExtensions[]="log";
$okExtensions[]="rtf";
$okExtensions[]="doc";
$okExtensions[]="cfg";

if(isset($_REQUEST['mode']) && $_REQUEST['mode'] == "download") $noheader=true;
require('../includes/core/includes/user/session.inc.php');
require('../includes/config.inc.php');

$GameCP->CheckPermissions('support');

$GameCP->SetURLCookie();

$smarty->assign('page_title', $LNG_SUPPORT);

if(isset($_SESSION['gamecp']['basic']) && $_SESSION['gamecp']['basic'] == "1"){ 
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("This feature is not enabled with the current license. (tt)");
}

if(usetickets != "1"){ 
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("This feature is not enabled. (tt)");
}

if ($_SESSION['gamecp']['userinfo']['ulevel'] == "0") $cQuery=" AND U.id='".$GameCP->whitelist($_SESSION['gamecp']['userinfo']['id'], "int")."'"; 

if(isset($_REQUEST['tid'])){
	$_REQUEST['tid']=$GameCP->whitelist($_REQUEST['tid'], "int");
	$tid=$_REQUEST['tid'];
}
if(isset($_REQUEST['cid'])){
	$_REQUEST['cid']=$GameCP->whitelist($_REQUEST['cid'], "int");
	$cid=$_REQUEST['cid'];
}
if(isset($_SESSION['gamecp']['subaccount']) && !in_array('7', $_SESSION['gamecp']['subuser']['perms'])){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->Error("Invalid access");
}

if($_SESSION['gamecp']['userinfo']['signature'] && isset($showsig) && $showsig == "1"){
	$sig=$_SESSION['gamecp']['userinfo']['signature'];
} else $sig ="";


if($mode == "saverefresh"){
	@setcookie("ttrefresh", $GameCP->whitelist($ttrefresh, 'int'), time()+900000, '', '', '', true); 
	$mode=$view;
	$_REQUEST['mode']=$mode;
}

/* MASS MODE */
if ($_SESSION['gamecp']['userinfo']['ulevel'] != "0") {
	if($mode == "massupdate" && DEMO != "yes"){	
		$scimode = $_POST['scimode'];
		$scimode2 = $_POST['scimode2'];
		if($scimode2 && !$scimode) $scimode=$scimode2;
		if($scimode){
			if(!$_POST['users']) die("Select a ticket.");
			
			foreach($_POST['users'] as $gid => $tid) { 
				$Event->EventLogAdd('', "Ticked id #$tid $scimode<br><hr> ".serialize($_SESSION)." <hr><br><br> - ". date('l jS \of F Y h:i:s A'));
	
				if($scimode == "closed"){ sql_query($safesql->query("UPDATE ttsystem SET status='Closed' WHERE id = '%i'", array($GameCP->whitelist($tid, "int")))) or die(mysql_error()); }
				if($scimode == "open"){ sql_query($safesql->query("UPDATE ttsystem SET status='Open' WHERE id = '%i'", array($GameCP->whitelist($tid, "int")))) or die(mysql_error()); }
				if($scimode == "resolved"){ sql_query($safesql->query("UPDATE ttsystem SET resolved='Yes' WHERE id = '%i'", array($GameCP->whitelist($tid, "int")))) or die(mysql_error()); }
				if($scimode == "unresolved"){ sql_query($safesql->query("UPDATE ttsystem SET resolved='No' WHERE id = '%i'", array($GameCP->whitelist($tid, "int")))) or die(mysql_error()); }
				if($scimode == "cres"){ sql_query($safesql->query("UPDATE ttsystem SET status='Closed', resolved='Yes' WHERE id = '%i'", array($GameCP->whitelist($tid, "int")))) or die(mysql_error()); }
				if($scimode == "openunres"){ sql_query($safesql->query("UPDATE ttsystem SET status='Open', resolved='No' WHERE id = '%i'", array($GameCP->whitelist($tid, "int")))) or die(mysql_error()); }
				
				if($scimode == "delete"){
					$GameCP->loadIncludes("support");
					$Support = new Support();
					$Support->Remove($tid);
				}
	
			}  // End for loop
			
			echo "<script type=\"text/javascript\" language=\"javascript\">window.parent.location='tt.php?mode=".$GameCP->whitelist($_SESSION['ticket']['mode'])."';</script>";

		} // end sci mode
	} // end mass update
} 

if ($mode == "update" && DEMO != "yes") {
	if(!isset($ticketReply) && $_SESSION['gamecp']['userinfo']['ulevel'] != "1") die("Reply required.<br><br><a href=\"javascript:history.go(-1)\">Go Back</a>");
	if(!isset($title)) $title='';

	$GameCP->loadIncludes("support");
	$Support = new Support();
	$Support->Reply($cid, $tid, $status, $resolved, $ticketReply, $summary, '', $title, $assignedto);

	$smarty->assign("showSaved", true);
	if(debugging == "0"){
		header("location: tt.php?mode=edit&tid=$tid&showSaved=true");
	} else echo "Saved";
}

if ($mode == "add" && DEMO != "yes") {
	$cid=$_SESSION['gamecp']['userinfo']['id'];
	if($_SESSION['gamecp']['userinfo']['ulevel'] == "1" && $uid) $cid=$uid;

	if(!isset($title)) $title='';
	$GameCP->loadIncludes("support");
	$Support = new Support();
	$tid=$Support->Create($cid, $title, '', $summary, $message, '', $files);
	
	if(debugging == "0"){
		header("location: tt.php?mode=edit&tid=$tid&showSaved=true");
	} else echo "Saved";
}

if($mode == "edit" && DEMO != "yes") { 

	/* DEFINE ALL TICKET CATEGORYS SMARTY QUERYS */
		$ticketCatQ = sql_query("SELECT title FROM ttcategorys") or die(mysql_error());
		while ($r = mysql_fetch_array($ticketCatQ)){
			$smarty->append("ticketCategorys", $r[0]); 
		}
	/* END ALL TICKET CATEGORYS SMARTY QUERYS */

	/* DEFINE TICKET ITEMS */
	$cid=$_SESSION['gamecp']['userinfo']['id'];
	
	if ($_SESSION['gamecp']['userinfo']['ulevel'] == "0"){
		$cQuery=" AND U.id='".$GameCP->whitelist($cid, "int")."'"; 
	} elseif($_SESSION['gamecp']['userinfo']['ulevel'] == "4"){
			$cQuery="AND (U.rsid='".$_SESSION['gamecp']['userinfo']['id']."' OR U.id='".$GameCP->whitelist($cid, "int")."')";
	} else $cQuery='';



	$ticketResult = sql_query($safesql->query("SELECT 
									U.username as user, T.*, T.id as 'tid', U.id  as 'uid', U.email, U.firstname, U.lastname FROM ttsystem T, users U WHERE
									T.id='%i' and U.id = T.cid $cQuery
									LIMIT 1", array($GameCP->whitelist($tid, "int")))) or die(mysql_error());

	$ticketResult = mysql_fetch_array($ticketResult);
	$ticketMessage=stripslashes($ticketResult['message']);
	/* END TICKET ITEMS */
	
	$files=explode(",", $ticketResult['files']);

	$tmessage=$GameCP->whitelist(stripslashes($ticketMessage), "wysiwyg");

	$GameCP->loadIncludes("panel");
	$Panel=new Panel();

	$tff=explode(",", $ticketResult['files']);
	$tf=array();
	foreach($tff as $t => $f){
		if(trim($f)) $tf[]=$f;
	}
	$smarty->assign("ticketFirst", $ticketResult['firstname']);
	$smarty->assign("ticketLast", $ticketResult['lastname']);
	$smarty->assign("ticketEmail", $ticketResult['email']);
	$smarty->assign("ticketUser", $ticketResult['user']);
	$smarty->assign("ticketUserId", $ticketResult['uid']);
	$smarty->assign("ticketID", $GameCP->whitelist($tid, "int"));
	$smarty->assign("ticketDate", date (dateformat.', g:i a', $ticketResult['date']));
	$smarty->assign("ticketUpdated", date (dateformat.', g:i a', $ticketResult['updated']));
	$smarty->assign("ticketCategory", $GameCP->whitelist($ticketResult['title'], "useredit"));
	$smarty->assign("ticketSummary", $GameCP->whitelist(stripslashes($ticketResult['summary']), "useredit"));
	$smarty->assign("ticketStatus", $GameCP->whitelist($ticketResult['status'], "useredit"));
	$smarty->assign("ticketResolved", $GameCP->whitelist($ticketResult['resolved'], "useredit"));
	$smarty->assign("ticketAssigned", $GameCP->whitelist($ticketResult['assigned'], "useredit"));
	$smarty->assign("ticketServers", unserialize($ticketResult['games']));
	$smarty->assign("ticketFiles", $tf);
	$smarty->assign("mail_address", $ticketResult['mail_address']);
	$smarty->assign("ticketMessage", $tmessage);
	$smarty->assign("ticketCID", $_SESSION['gamecp']['userinfo']['id']);
	$smarty->assign("ticketAge", $Panel->TimeDistance($ticketResult['date'], time(), ''));


	if ($_SESSION['gamecp']['userinfo']['ulevel'] != "0"){
		$userListA=array();
		$ulist = sql_query("SELECT * FROM users WHERE userlevel !='0'") or die(mysql_error());
		while($row=mysql_fetch_array($ulist)) $userListA[$row['id']]=$row['name'];
		$smarty->assign("userListA", $userListA);
	}

	$lastupdated=$ticketResult['updated'];
	$ticketadded=$ticketResult['date'];
	$updatedDate=$today2 = date ('F j, Y, g:i a', $lastupdated);
	$addedDate=$today2 = date ('F j, Y, g:i a', $ticketadded);
	$ticketAge=$Panel->TimeDistance($ticketadded,time(), '');

	$smarty->display('troubletickets/ticket-view.tpl');
} 

if($mode == "new") {
	/* DEFINE ALL TICKET CATEGORYS SMARTY QUERYS */
		$ticketCatQ = sql_query("SELECT title FROM ttcategorys") or die(mysql_error());
		while ($r = mysql_fetch_array($ticketCatQ)){
			$smarty->append("ticketCategorys", $r[0]); 
		}
	/* END ALL TICKET CATEGORYS SMARTY QUERYS */


	$result = sql_query($safesql->query("SELECT UG.ip, UG.port, G.scontrolname, U.name, G.name as 'gname', G.protocol, UG.id as 'gid', I.sid, G.gcode, UG.maxplayers, UG.cid, UG.queryport, UG.pubpriv FROM users U, usergames UG, game G, iptable I WHERE U.active='1'  AND U.id = UG.cid AND  UG.gid = G.id AND  I.ip = UG.ip AND U.id='%i'", array($GameCP->whitelist($_SESSION['gamecp']['userinfo']['id'], "int")))) or die(mysql_error());
	while ($r = mysql_fetch_array($result)){ 
		$smarty->append("ipport", "Service #".$r['gid']. " " .$r['gname']." @ " .$r['ip'].":".$r['port']); 
	}

	$result = sql_query($safesql->query("SELECT user, maxclients, ip, port, tssid, servername, vid, id, pass, voicetype FROM uservoice WHERE cid='%i';", array($GameCP->whitelist($_SESSION['gamecp']['userinfo']['id'], "int")))) or die(mysql_error());
	while ($r = mysql_fetch_array($result)){ 

		if($r['voicetype'] == "ts2"){
			$type= "Teamspeak 2";
		}elseif($r['voicetype'] == "ts3"){ 
			$type= "Teamspeak 3";
		} else $type="Ventrilo";

		$smarty->append("ipport", "Voice #" .$r['id']." " .$type." @ " .$r['ip'].":".$r['port']); 

	}

	$smarty->assign("uploadExtensions", $okExtensions);

	$smarty->display('troubletickets/ticket-create.tpl');
}

if($mode =="view" || $mode =="viewc" || $mode =="assigned" || $mode =="viewhold" || $mode =="viewprogress"|| $mode =="viewreply" || $mode =="viewactive" || @$view == "all"){
	$_SESSION['ticket']['mode']=$mode;
	if(!isset($_REQUEST['noheader']) && !isset($_REQUEST['mini'])){
	/* DEFINE ALL TICKET CATEGORYS SMARTY QUERYS */
		$ticketCatQ = sql_query("SELECT title FROM ttcategorys") or die(mysql_error());
		while ($r = mysql_fetch_array($ticketCatQ)){
			$smarty->append("ticketCategorys", $r[0]); 
		}
	/* END ALL TICKET CATEGORYS SMARTY QUERYS */
	}
	$smarty->display("troubletickets/tickets.tpl");
}

if($mode == "deletetmpfiles"){
	if(ALLOWTICKETUPLOADS == "yes" && TICKETUPLOADPATH){
		if(isset($_REQUEST['files']) && is_array($_REQUEST['files'])){
			foreach($_REQUEST['files'] as $delfile){
				$checkme=explode("_", $delfile);
				if(strtolower($checkme[0]) == strtolower($_SESSION['gamecp']['userinfo']['name'])){
					$file=TICKETUPLOADPATH."/".$GameCP->whitelist($delfile);
					if(is_file($file) && isset($delfile)) unlink($file);
				}
			}
		}
	}
}

if($mode == "download"){
	if(ALLOWTICKETUPLOADS == "yes" && TICKETUPLOADPATH){
		$allowdl=true;

		if ($_SESSION['gamecp']['userinfo']['ulevel'] != "1" && $_SESSION['gamecp']['userinfo']['ulevel'] != "2" && $_SESSION['gamecp']['userinfo']['ulevel'] != "3"  && $_SESSION['gamecp']['userinfo']['ulevel'] != "4" && $_SESSION['gamecp']['userinfo']['ulevel'] != "5") {
			$ticketResultQ = sql_query($safesql->query("SELECT T.files FROM ttsystem T, users U WHERE U.id = T.cid $cQuery", array())) or die(mysql_error());
			$allFiles=array();
			while($ticketResult = mysql_fetch_array($ticketResultQ)){
				$fileList=explode(",", $ticketResult['files']);
				$allFiles=array_merge($fileList, $allFiles);
			}
			if(!in_array($_REQUEST['file'], $allFiles)) $allowdl=false;
		}

		if($allowdl==true){
			$target_path = TICKETUPLOADPATH;
			$file=$target_path."/".$_REQUEST['file'];
			if (file_exists($file)) {
				header('Content-Description: File Transfer');
				header('Content-Type: application/octet-stream');
				header('Content-Disposition: attachment; filename='.basename($file));
				header('Content-Transfer-Encoding: binary');
				header('Expires: 0');
				header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
				header('Pragma: public');
				header('Content-Length: ' . filesize($file));
				ob_clean();
				flush();
				readfile($file);
				exit;
			} else header("location: $url/system/tt.php");
		} else header("location: $url/system/tt.php");
	}
}

if($mode == "uploadfile"){
	if(ALLOWTICKETUPLOADS == "yes" && TICKETUPLOADPATH){
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$badExtensions=$Panel->invalidUploads();
		$target_path = TICKETUPLOADPATH;
		$uploadedfile = $_FILES['filefieldname']['name'];
		$ext = pathinfo($uploadedfile);
		$extention =  strtolower($ext["extension"]);

		if(in_array($extention, $badExtensions) || !in_array($extention, $okExtensions)){
			$tmp_file=$target_path.DIRECTORY_SEPARATOR.$file;
			if(is_file($tmp_file) && isset($file)) unlink($tmp_file);
			
			$file_name = "File extension is invalid: ".basename( $_FILES['filefieldname']['name']);
			$uvalid="false";

		} else { 
			$file_name = $_SESSION['gamecp']['userinfo']['name']."_".date("mdis")."_".basename( $_FILES['filefieldname']['name']);
			$target_path = $target_path .DIRECTORY_SEPARATOR.$file_name; 

			if(move_uploaded_file($_FILES['filefieldname']['tmp_name'], $target_path)) {
				$uvalid="true";
			} else $uvalid="false";
		}

		$smarty->assign('fileid', date("mdis"));
		$smarty->assign('filename', $file_name);
		$smarty->assign('uploadvalid', $uvalid);
		$smarty->display('troubletickets/upload-results.tpl');
	}
}

require_once(path.'/includes/core/editable/footer.inc.php');

?>