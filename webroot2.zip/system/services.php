<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

if(isset($_REQUEST['mode']) && $_REQUEST['mode'] == "mass") $noheader=true;
require('../includes/core/includes/user/session.inc.php');
require('../includes/config.inc.php');

$GameCP->CheckPermissions('services');

$GameCP->SetURLCookie();

$smarty->assign('page_title', $LNG_USERGAMEMANAGEMENT);

if(isset($_REQUEST['gid'])){
	$_REQUEST['gid']=$GameCP->whitelist($_REQUEST['gid'], "int");
	$gid=$_REQUEST['gid'];
}

if(!isset($mode)) $mode='';	

if($_SESSION['gamecp']['userinfo']['ulevel'] == "4") $rsQuery = "AND U.rsid='".$_SESSION['gamecp']['userinfo']['id']."'"; 

if($mode == "mass"){
	if(!$_POST['users']) die("Select a server."); 
	$GameCP->loadIncludes("control");
	$Control=new Control();

	if(!$scimode && isset($scimode2)) $scimode=$scimode2;
	
	if($scimode == "rebuild" && $_SESSION['gamecp']['userinfo']['ulevel'] == "1" ){
		$GameCP->loadIncludes("control");
		$Control=new Control();

		foreach($_POST['users'] as $gid => $sci) { 
			$gameInfoQ = sql_query($safesql->query("SELECT UG.ip, UG.port, UG.config, UG.startmap, UG.maxplayers, G.install, G.gcode, G.premode, G.fsgame, G.game, G.scontrolname, S.sid, S.os, U.name, S.winport, S.winadminpass, G.winparams, G.winexec, S.winuser, UG.cid, G.winstopconsole FROM game G, usergames UG, users U, iptable I, servers S WHERE G.id = UG.gid AND UG.id = '%i' AND UG.cid = U.id AND UG.ip = I.ip AND I.sid = S.sid LIMIT 1;", array($GameCP->whitelist($gid, "int")))) or die(mysql_error());
			$gameInfo = mysql_fetch_array($gameInfoQ);
				$fip = $gameInfo[0];
				$fport = $gameInfo[1];
				$fconfig = $gameInfo[2];
				$fstartmap = $gameInfo[3];
				$fmaxplayers = $gameInfo[4];
				$install = $gameInfo[5];
				$gcode = $gameInfo[6];
				$premode = $gameInfo[7];
				$fsgame = $gameInfo[8];
				$game = $gameInfo[9];
				$scontrolName = $gameInfo[10];
				$sid=$gameInfo[11];
				$os=$gameInfo[12];
				$fname = $gameInfo[13];
				$winport = $gameInfo[14];
				$winadminpass = $gameInfo[15];
				$winparams = $gameInfo[16];
				$winexec = $gameInfo[17];
				$cid = $gameInfo['cid'];
				$winuser = $gameInfo['winuser'];
				$winstopconsole = $gameInfo['winstopconsole'];

				$suser=$fname;
				$sci=$scontrolName;

			$Control->Usergame($gid, "stop");


			$GameCP->loadIncludes("backend");
			$Backend=new Backend();

			if($os != "1" && $os != "3"){

				$serveruserA = "a".trim($Backend->QueryResponse($sid, $winport, "checkuser:_:$fname"))."b";
				if ($serveruserA != "aexistsb") { 
					$GameCP->loadIncludes("panel");
					$Panel=new Panel();
					$usrInfo=$Panel->GetUser($cid);
					$fpassword=$usrInfo['password'];
					$loginpath=$usrInfo['bash'];
					$demo=$usrInfo['demo'];


					$GameCP->loadIncludes("user");
					$User=new User();
					$ubash = $User->GetShell($loginpath, $demo);

					$Backend->QueryResponse($sid, $winport, "adduser:_:$ubash:_:$fname:_:$fpassword");
				}

				 $Backend->Query($sid, $winport, "addserver:_:$gid", $fname);
				 $Backend->Query($sid, $winport, "command:_:chown -R $fname /home/$fname ; chmod 644 /etc/logrotate.d/$fname");

			} else { 
				$Backend->QueryResponse($sid, $winport, "removeserver:_:gcp-$fname-$gid");
				$Control->Build($gid, "add");
			}
			$Control->Usergame($gid, "start");
		} // end for each
		?>
		<body onLoad="parent.window.location='<?php echo $url; ?>/system/services.php'"></body> 

		<?php
		

	exit;
	} // END REBUILD


	if(($scimode == "unsuspend"||$scimode == "suspend") && $_SESSION['gamecp']['userinfo']['ulevel'] == "1" ){
		$GameCP->loadIncludes("control");
		$Control=new Control();

		foreach($_POST['users'] as $gid => $sci) { 

			$GameCP->loadIncludes("suspend");
			$Suspend=new Suspend();
			if($scimode == "unsuspend"){
				$Suspend->GameRestore($gid);
			} else $Suspend->Game($gid);

		} 
		?><body onLoad="parent.window.location='<?php echo $url; ?>/system/services.php?status=suspended'"></body><?php
	exit;
	} // END REBUILD





	if($scimode && DEMO != "yes"){
		$GameCP->loadIncludes("control");
		$Control=new Control();
		$GameCP->loadIncludes("game");
		$Game=new Game();

		foreach($_POST['users'] as $gid => $sci) { 

			$ugid=$gid;
			$gameInfo = $Game->GetService($ugid);

			$fname=$gameInfo['username'];
			$fip=$gameInfo['ip'];
			$fport=$gameInfo['port'];
			$cid=$gameInfo['cid'];
			$flimit=$gameInfo['flimit'];
			$ugsci=$gameInfo['scontrol'];
			$os = $gameInfo['os'];
			$sid = $gameInfo['sid']; 



			$limitreached="false";

			if($scimode == "start") { $status = "1"; }
			if($scimode == "stop") { $status = "0"; }

			$Control->Usergame($ugid, $scimode);


		} // end for each

		if($limitreached == "true"){
			$smarty->assign("serverLimit", $flimit);
			$smarty->assign("ugid", $ugid);
			$smarty->display("manageusergames/server-limit.tpl");
			exit;
		} 

		// mass form submission
		if($iframecontrol == "3") { ?> 
			<body onLoad="parent.window.location='<?php echo $url; ?>/system/userservices.php?mode=edit&idd=<?php echo $GameCP->whitelist($idd); ?>'"></body><?php 
		} else {
			if ($_SESSION['gamecp']['userinfo']['ulevel'] == "1" || $_SESSION['gamecp']['userinfo']['ulevel'] == "2" || $_SESSION['gamecp']['userinfo']['ulevel'] == "3" || $_SESSION['gamecp']['userinfo']['ulevel'] == "4" || $_SESSION['gamecp']['userinfo']['ulevel'] == "5") { 
				if($iframecontrol == "1") { ?> 
					<body onLoad="parent.window.location='<?php echo $url; ?>/system/services.php?status=<?php $GameCP->whitelist($pagestatus); ?>&sci=<?php $GameCP->whitelist($_REQUEST['pagesci']); ?>&time=<?php echo time(); ?>'"></body><?php 
				} else if($iframecontrol == "2") { ?> 
					<body onLoad="parent.window.location='<?php echo $url; ?>/system/index.php'"></body>
					<script type="text/javascript">window.parent.location='<?php echo $url; ?>/system/index.php';</script><?php 
				} else echo "<meta http-equiv=\"Refresh\" content=\"1;url=" . $url . "/system/services.php?sci=".$GameCP->whitelist($pagesci)."&status=". $GameCP->whitelist($pagestatus)."&time=". time()."\">"; 
			} else {  ?>
				<body onLoad="parent.window.location='<?php echo $url; ?>/system/index.php'"></body> <?php 
			}
		}

	} // end sci mode?
}

if($mode != "mass"){
	$_SESSION['gamecp']['backtolist']="services.php";

	$userArray=array();
	$gameArray=array();
	$serverArray=array();

	if($_SESSION['gamecp']['userinfo']['ulevel'] != "0" && !isset($_REQUEST['mini'])){
		$serverNameQ = sql_query("SELECT sid, name, id FROM servers ORDER BY quota - used  DESC") or die(mysql_error());
		while ($serverName = mysql_fetch_assoc($serverNameQ)){
			$serverArray[]=array("sid" => $serverName['sid'], "name" => $serverName['name'], "id" => $serverName['id']);
		}
		$gameNameQ = sql_query("SELECT id, name FROM game") or die(mysql_error());
		while ($gameName = mysql_fetch_assoc($gameNameQ)){
			$gameArray[]=array("id" => $gameName['id'], "name" => $gameName['name']);
		}
		$gameNameQ = sql_query("SELECT id, name FROM users WHERE userlevel='0' ORDER BY name") or die(mysql_error());
		while ($gameName = mysql_fetch_assoc($gameNameQ)){
			$userArray[]=array("id" => $gameName['id'], "name" => $gameName['name']);
		}
	}

	$sortQ="";
	/* remember wtf they did */
	if(!isset($_REQUEST['sortS'])) { 
		if(!isset($_SESSION['gamecp']['srv_sortS'])) $_SESSION['gamecp']['srv_sortS'] = "0";
	}else $_SESSION['gamecp']['srv_sortS']=$GameCP->whitelist($_REQUEST['sortS']);
	$sortS=$_SESSION['gamecp']['srv_sortS'];

	if(!isset($_REQUEST['sortG'])) { 
		if(!isset($_SESSION['gamecp']['srv_sortG'])) $_SESSION['gamecp']['srv_sortG'] = "0";
	}else $_SESSION['gamecp']['srv_sortG']=$GameCP->whitelist($_REQUEST['sortG']);
	$sortG=$_SESSION['gamecp']['srv_sortG'];

	if($_SESSION['gamecp']['userinfo']['ulevel'] == "1"){
		if(!isset($_REQUEST['cid'])) { 
			if(!isset($_SESSION['gamecp']['srv_cid'])) $_SESSION['gamecp']['srv_cid'] = "0";
		}else $_SESSION['gamecp']['srv_cid']=$GameCP->whitelist($_REQUEST['cid'], "int");
		$sortCid=$_SESSION['gamecp']['srv_cid'];
		if($sortCid && $sortCid !="reset") $sortQ.=" AND UG.cid = '$sortCid'";
	}

	if($sortS && $sortS !="reset") $sortQ.=" AND (SELECT sid FROM iptable I WHERE I.ip=UG.ip) = '$sortS'";
	if($sortG && $sortG !="reset") $sortQ.=" AND G.id = '$sortG'";

	if(isset($_REQUEST['reset'])){
		$sortQ="";
		unset($_SESSION['gamecp']['srv_cid'], $_SESSION['gamecp']['srv_sortG'], $_SESSION['gamecp']['srv_sortS']);
	}
	
	if(isset($_REQUEST['homepage']) && $_REQUEST['homepage'] == "true"){
		$_REQUEST['view']="all";
		$smarty->assign("indexQ", " AND homepage='1'");
	}

	/* remember we wanted to see all, right? */
	if(isset($_REQUEST['view']) && $_REQUEST['view'] == "all"){
		$_SESSION['gamecp']['view']['manageserver']="all";
	}elseif(isset($_REQUEST['view']) && $_REQUEST['view'] == "default") $_SESSION['gamecp']['view']['manageserver']="";
	if(isset($_SESSION['gamecp']['view']['manageserver']) && $_SESSION['gamecp']['view']['manageserver'] == "all") $_REQUEST['view']="all";

	if(isset($_REQUEST['status']) && $_REQUEST['status']){
		$_SESSION['gamecp']['view']['manageserverstatus']=$_REQUEST['status'];
	}elseif(isset($_REQUEST['view']) && $_REQUEST['view'] == "default") $_SESSION['gamecp']['view']['manageserverstatus']="";

	if(isset($_SESSION['gamecp']['view']['manageserverstatus'])) $_REQUEST['status']=$_SESSION['gamecp']['view']['manageserverstatus'];

	$smarty->assign("sortS", $sortQ);

	$smarty->assign("serverName",$serverArray );
	$smarty->assign("gameName",$gameArray);
	$smarty->assign("users",$userArray);

	$smarty->display("modules/server-listadmin.tpl");
}

require_once(path.'/includes/core/editable/footer.inc.php');

?>