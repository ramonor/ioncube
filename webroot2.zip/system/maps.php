<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

require('../includes/core/includes/user/session.inc.php');
require('../includes/config.inc.php');

$GameCP->CheckPermissions('maps');

$GameCP->SetURLCookie();

$smarty->assign('page_title', $LNG_USERGAMEMANAGEMENT);

if(!isset($mode) || isset($mode) && !$mode) $mode="";

if(isset($_REQUEST['ugid']) && $_REQUEST['ugid'] || isset($_SESSION['gamecp']['user']['browseGame']) && $_SESSION['gamecp']['user']['browseGame']){
	if(isset($_REQUEST['ugid']) && $_REQUEST['ugid']) $_SESSION['gamecp']['user']['browseGame'] = $_REQUEST['ugid'];
	if(!isset($_REQUEST['ugid'])) $_REQUEST['ugid']= $_SESSION['gamecp']['user']['browseGame'];
	if(!isset($_SESSION['gamecp']['user']['browseGame'])) $_SESSION['gamecp']['user']['browseGame'] = $_REQUEST['ugid'];
	$GameCP->UserGameAccess($_REQUEST['ugid'], "maps");
} else {
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("You do not have permission to view this page. 1B");
}

if(isset($_SESSION['gamecp']['subaccount']) && $_SESSION['gamecp']['subaccount'] == "yes" && !in_array($_SESSION['gamecp']['user']['browseGame'], $_SESSION['gamecp']['subuser']['games'])){
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$Panel->ErrorExit("You do not have permission to view this page. 1D");
}

$supportedGamesQ = sql_query($safesql->query("SELECT 
	distinct G.mapdir, 
	U.username,
	G.usermapdir, 
	S.sid, 
	S.os,
	S.winport,
	G.winusermapdir, 
	G.winmapdir,
	G.name as 'gamename',
	G.mapextension,
	UG.subdirectory,
	UG.ip,
	UG.port,
	UG.id as 'gid',
	U.id as 'uid',
	G.mapimgdir
	
	FROM usergames UG, game G, users U, iptable I, servers S 
		WHERE U.id = UG.cid
		AND  UG.gid = G.id 
		AND G.mapdir != '' 
		AND UG.ip=I.ip 
		AND I.sid = S.sid
		AND UG.id='%i'
		 
	LIMIT 1;", array($GameCP->whitelist($_SESSION['gamecp']['user']['browseGame'], "int")))) or die(mysql_error());
	$supportedGame=mysql_fetch_assoc($supportedGamesQ);
	$usr=$supportedGame['username']; 
	$os=$supportedGame['os'];
	$sid=$supportedGame['sid'];
	$winusermapdir=$supportedGame['winusermapdir'];
	$winmapdir=$supportedGame['winmapdir'];
	$winport=$supportedGame['winport'];
	$sharedmapdir=$supportedGame['mapdir'];
	$usermapdir=$supportedGame['usermapdir'];
	$gamename=$supportedGame['gamename'];
	$mapextension=ltrim($supportedGame['mapextension'], ".");
	$mapextension=$GameCP->whitelist($mapextension, "useredit");
	$userid=$supportedGame['uid'];
	$fport=$supportedGame['port'];
	$fip=$supportedGame['ip'];
	$ggid=$supportedGame['gid'];
	$subdirectory=$supportedGame['subdirectory'];
	$mapimgdir=$supportedGame['mapimgdir'];

if($subdirectory == "yes"){ 
	if(ipsubdir == "true"){
		$thesubdir=$fip."-".$fport;
	} else $thesubdir="service".$ggid;
} else $thesubdir = '';

if($os == "1"){
	$sharedmapdir=$winmapdir; 
	$usermapdir=$winusermapdir; 
}

if($thesubdir){
	$homemapdir="/home/$usr/$thesubdir/$usermapdir";
	$usermapdir="$thesubdir/$usermapdir";
} else $homemapdir="/home/$usr/$usermapdir";
$mapdir=$sharedmapdir;

if($mode =="install" && DEMO != "yes") { 
	$GameCP->loadIncludes("game");
	$Game=new Game();
	$GameCP->loadIncludes("backend");
	$Backend=new Backend();

	if(isset($_POST['newmap']) && $mapdir){
		$checkScheme=parse_url($mapdir);
		if($checkScheme['scheme'] == "ftp" || $checkScheme['scheme'] == "ftps"){
			$downloadurl=$mapdir;
		} else $downloadurl="";

		foreach($_POST['newmap'] as $newmap) { 	
			if($newmap){
				$pathinfo = pathinfo($newmap);
				$ext=$pathinfo['extension'];
				$extractMode=$Game->Extract($ext, $os);
				$extract=$extractMode[0];

				$newmap=$GameCP->whitelist($newmap, "useredit");

				if($os != "1" && $os !="3"){
					if(substr($mapdir, -1) != "/")	$mapdir=$mapdir."/";
					$maplocation=$mapdir.$newmap;
					$usrmap="/home/$usr/$usermapdir";
					if(substr($usrmap, -1) != "/")	$usrmap=$usrmap."/";

					if($downloadurl) {
						$Backend->QueryResponse($sid, $winport, "command:_:cd $usrmap; wget $downloadurl/$newmap ; chown $usr:$usr $usrmap/$newmap ; chmod 644 $usrmap/$newmap;", $usr);
					} else $Backend->Query($sid, $winport, "copyfile:_:$maplocation:_:$usrmap", $usr);
					if($extract) $Backend->Query($sid, $winport, "command:_:cd $usrmap; $extract $maplocation", $usr);
				} else { 
					
					$afile="$mapdir\\$newmap";
					$bfile="\$MAINDIRhome\\$usr\\$usermapdir\\$newmap";

					if($downloadurl) {
						$Backend->Query($sid, $winport, "downloadfile:_:$downloadurl/$newmap:_:$bfile");
					} else $Backend->Query($sid, $winport, "copyfile:_:$afile:_:$bfile");
					if($extract) $Backend->Query($sid, $winport, "bin\gcpextract:_:$bfile");
				}

				$hook_vars=array("map"=>$newmap, "ugid"=>$ugid, "details"=>$supportedGame, "homemapdir" => $homemapdir, "usermapdir"=>$usermapdir);
				run_hook("map_install");
			}
		}
	} else echo "File not added.<br>"; 
	
	$mode = "";
}

if($mode =="uninstall" && DEMO != "yes") { 
	$mapList=array();
	$mapListAlt="";
	if(is_array($_POST['mapfile'])){
		foreach($_POST['mapfile'] as $mapfileb) { 
			if($mapfileb){
				$mapList[]=$GameCP->whitelist($mapfileb, 'useredit');
				$mapListAlt.=":-:".$GameCP->whitelist($mapfileb, 'useredit');
			}
		}
	}

	$smarty->assign("mapList", $mapList);
	$smarty->assign("mapListAlt", $mapListAlt);
	$smarty->assign("rsid", $_POST['rsid']);
	$smarty->assign("usermapdir", $_POST['usermapdir']);
	$smarty->assign("mapdir", $_POST['mapdir']);

	$smarty->display("managemaps/managemaps-remove.tpl");
}

if($mode =="DOuninstall") { 
	if($doValid == $LNG_SHOWYES){ 
		$mapfile=$_POST['mapfile'];
		if($mapfile && $usermapdir){
			$maplist=explode(":-:", $mapfile);
			$arrayLength = count($maplist);
				for ($i = 0; $i < $arrayLength; $i++){
					$invalidname="/home/$usr/$mapdir/";
				if($maplist[$i] != $invalidname && $maplist[$i] && isset($maplist[$i])){ 
					$GameCP->loadIncludes("backend");
					$Backend=new Backend();
					if($os == "1"){
						$Backend->Query($sid, $winport, "deletefile:_:\$MAINDIRhome\\$usr\\$usermapdir\\".$maplist[$i]);
					} else $Backend->Query($sid, $winport, "deletefile:_:/home/$usr/$usermapdir/".$maplist[$i], $usr);
					
					$hook_vars=array("map"=>$newmap, "ugid"=>$ugid, "details"=>$supportedGame, "homemapdir" => $homemapdir, "usermapdir"=>$usermapdir);
					run_hook("map_uninstall");
				}
			}
		} else echo "File not removed.<br>";
	} 
	$mode = "";
}

if(!isset($mode) || isset($mode) && !$mode){
	$GameCP->loadIncludes("backend");
	$Backend=new Backend();

	$userMapArray=array();
	$sharedMapArray=array();
	$resultArray=array();

	// If both directorys exist build the array
	if($sharedmapdir && $usermapdir){
		// Grab the list of maps
		if($os == "1"){ 
			$homemapdir=str_replace("/", "\\", $homemapdir);

			$homemapdir="\$MAINDIR".$homemapdir;
			$usermaplist=$Backend->QueryResponse($sid, $winport, "filelist2:_:$homemapdir");

			$usermaplist = explode("::", $usermaplist);
			foreach($usermaplist as $r => $v){
				if($mapextension != ""){
					if(preg_match("/.$mapextension/i",$v)) $usermaplistA[]=$v;
				} else $usermaplistA[]=$v;
			}

			$GameCP->loadIncludes("ftp");
			$FTP=new FTP();

			$sharedmaplistA=$FTP->ListURL($sharedmapdir);

			/* ftp sharedmapdir says no result, check socket based */
			if(!$sharedmaplistA){
				if(!preg_match("/:/i", $sharedmapdir)){
					$sharedmapdir="/games/".$sharedmapdir;
					$sharedmapdir=str_replace("/", "\\", $sharedmapdir);
					$sharedmapdir="\$MAINDIR".$sharedmapdir;
				}
				$sharedmaplist=$Backend->QueryResponse($sid, $winport, "filelist2:_:$sharedmapdir");
				$sharedmaplist = explode("::", $sharedmaplist);

				foreach($sharedmaplist as $r => $v){
					if($mapextension != ""){
						if(preg_match("/.$mapextension/i",$v)
							|| preg_match("/.tar.gz/i",$v)
							|| preg_match("/.rar/i",$v)
							|| preg_match("/.zip/i",$v)
							|| preg_match("/.tar/i",$v)
							|| preg_match("/.bz2/i",$v)						
						) $sharedmaplistA[]=$v;
					} else $sharedmaplistA[]=$v;
				}
			}
			
			$sharedmaplistA =array_diff($sharedmaplistA, $usermaplistA);
		} else {
			$usermaplist=$Backend->QueryResponse($sid, $winport, "filelist:_:$homemapdir");
			$usermaplistA=explode("\n", $usermaplist);
			if($mapextension != ""){
				$uml=$usermaplistA;
				$usermaplistA="";
				foreach($uml as $r => $v){
					if(preg_match("/.$mapextension/s",$v)) $usermaplistA[]=$v;
				}
			}

			$GameCP->loadIncludes("ftp");
			$FTP=new FTP();
			$sharedmaplistA=$FTP->ListURL($sharedmapdir);

			if(!$sharedmaplistA){
				if(substr($sharedmapdir, 0, 1) != "/") $sharedmapdir = "/usr/local/games/". $sharedmapdir;
				$sharedmaplist=$Backend->QueryResponse($sid, $winport, "filelist:_:$sharedmapdir");
				$sharedmaplist=explode("\n", $sharedmaplist);
				$sharedmaplistA=array();
				foreach($sharedmaplist as $r => $v){
					if($mapextension != ""){
						if(preg_match("/.$mapextension/i",$v)
							|| preg_match("/.tar.gz/i",$v)
							|| preg_match("/.rar/i",$v)
							|| preg_match("/.zip/i",$v)
							|| preg_match("/.tar/i",$v)
							|| preg_match("/.bz2/i",$v)						
						) $sharedmaplistA[]=$v;
					} else $sharedmaplistA[]=$v;
				}
			}
			$sharedmaplistA =array_diff($sharedmaplistA, $usermaplistA);
		}

		// Only build if there are results
		if(count($usermaplistA) > 0){
			if(isset($searchuser) && $searchuser){
				$usermaplist=array();
				// Split the arrays to do searches
				for($i = 0; $i < count($usermaplistA); $i++){
					if (eregi($searchuser, $usermaplistA[$i])) $usermaplist[]=$usermaplistA[$i];
				}
			} else $usermaplist = $usermaplistA; 

			if(isset($searchshared) && $searchshared){
				$sharedmaplist=array();
				// Split the arrays to do searches
				for($i = 0; $i < count($sharedmaplistA); $i++){
					if (eregi($searchshared, $sharedmaplistA[$i])) $sharedmaplist[]=$sharedmaplistA[$i];
				}
			} else $sharedmaplist = $sharedmaplistA; 

			// Assign the maplist to the user array
			$userMapArray[]=$usermaplist;
			$sharedMapArray[]=$sharedmaplist;
		}
	} // end if both dirs exit

	if(isset($usermaplist) && is_array($usermaplist)){
		foreach($usermaplist as $i => $s){
			if(trim($s) == "") unset($usermaplist[$i]);
		}
	} else $usermaplist='';

	if(isset($sharedmaplist) && is_array($sharedmaplist)){
		foreach($sharedmaplist as $i => $s){
			if(trim($s) == "") unset($sharedmaplist[$i]);
		}
	} else $sharedmaplist='';

	 $resultArray[]=array('gamename' => $gamename, 'sid' => $sid, 'usermapdir' => $usermapdir, 'sharedmapdir' => $sharedmapdir, 'sharedmaplist' => $sharedmaplist, 'usermaplist' => $usermaplist, 'mapimgdir' =>$mapimgdir);

	// Smarty
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$gameInfo=$Panel->GetUserGame($_REQUEST['ugid']);
	$smarty->assign("fname", $gameInfo['username']);
	$smarty->assign("fip", $gameInfo['ip']);
	$smarty->assign("fport", $gameInfo['port']);


	$smarty->assign("mapList", $resultArray);
	if(isset($searchuser)) $smarty->assign("searchuser", $GameCP->whitelist($searchuser, 'useredit'));
	if(isset($searchshared)) $smarty->assign("searchshared", $GameCP->whitelist($searchshared, 'useredit'));
	$smarty->assign("uid", $userid);

	$smarty->display("managemaps/managemaps-list.tpl");
}


require(path.'/includes/core/editable/footer.inc.php');

?>