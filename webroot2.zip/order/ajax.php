<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

$noheader=true;
define("_GAMECP_", "gamecp");


/* CHANGE THIS TO INCLUDE IN A NEW FOLDER */
$PATH="";
if(isset($PATH) && $PATH != ""){
	$gameCPPath=$PATH;
} else $gameCPPath="..";

require_once($gameCPPath."/includes/mysql.inc.php");
require_once($gameCPPath.'/includes/core/includes/gamecp/settings.inc.php'); 

$GameCP->loadIncludes("order");
$Order=new Order();

if(!isset($mode)) $mode ='';

session_start();

	if(isset($_SESSION['gamecp']['exchange'])){
		$smarty->assign('currencyName', $_SESSION['gamecp']['exchange']['code']);
		$smarty->assign('currencyChar', $_SESSION['gamecp']['exchange']['prefix']);
		$smarty->assign('currencyChar2', $_SESSION['gamecp']['exchange']['suffix']);
	}


if($mode == "pricelist"){
	$prodInfo=$Order->GetPrices($_REQUEST['gmida'], $packagePubPriv, '', $_REQUEST['gmid']);
//print_r($prodInfo);
	$smarty->assign("productList", $prodInfo[0]);
	$smarty->assign("selectedproduct", $prodInfo[7]);
	$smarty->assign("Order", $Order);

	SmartyPaginate::setNextText($LNG_MORE, "order");
	SmartyPaginate::setPrevText($LNG_LESS, "order");

	$smarty->display('order/price-list.tpl');
}

if(isset($_REQUEST['checkPromo'])){

	$hook_vars='';
	run_hook("order_checkpromo");

	$promo=$Order->GetPromotions();

	if($promo['active'] == "1"){
		$local=false; $prod=false; $uses=false; $expires=false; $existinguser=true; $newuser=true; $oneperuser=true;

		if($promo['totaluses'] != "0"){
			if($Order->GetPromotionUse($promo['id']) <= $promo['totaluses']) $uses=true;
		} else $uses=true;

		$products=unserialize($promo['products']);
		if(in_array($_SESSION['gamecp']['orderDetails']['gmida'], $products) || count($products) == 0) $prod=true;
		
		$locations=unserialize($promo['location']);
		if(is_array($locations) && count($locations) > 0){
			if(in_array(trim($_SESSION['gamecp']['orderDetails']['serverLocation']), $locations)) $local=true;
		} else $local=true;

		if($promo['expire']){
			if(strtotime($promo['expire']) >= time()) $expires=true;
		} else $expires=true;

		if(isset($_SESSION['gamecp']['orderDetails']['existingcustomer'])){
			if($promo['newuser'] == "1") $newuser=false;
			if($promo['oneperuser'] == "1") if($Order->GetPromotionByUser($promo['id'], $_SESSION['gamecp']['orderDetails']['userid']) != '0') $oneperuser=false;
		} else if($promo['existinguser'] == "1") $existinguser=false;


		if($promo['type'] == "percent"){
			if($promo['value'] >= "100"){
				$discounttotal=$_SESSION['gamecp']['orderDetails']['originalGross'];
			} else {

				if($promo['value'] < 1){
					$div=10;
				}else $div=100;

				$dis=$promo['value']/$div;
				$discounttotal=$_SESSION['gamecp']['orderDetails']['originalGross'] * $dis;
			}

		} else if($promo['type'] == "fixed") $discounttotal=$Order->FormatNumber($promo['value']);

		if($local == false || $prod == false || $uses == false  || $expires == false  || $existinguser == false  || $newuser == false  || $oneperuser == false){

			$promok=false;
		} else $promok=true;
	} else $promok=false;

	if(!isset($_SESSION['gamecp']['orderDetails']['promoUsed'][$promo['name']])){
		if($promok == true){
			if(!$discounttotal) $discounttotal="0.00";

			$newprice=$_SESSION['gamecp']['orderDetails']['originalGross']-$discounttotal;
			if($newprice < "0") $newprice="0.00";
			$_SESSION['gamecp']['orderDetails']['packageGross']=$Order->FormatNumber($newprice);
			$_SESSION['gamecp']['orderDetails']['promoUsed'][$promo['name']]=array("id" => $promo['id'], "total" => $Order->RemFormatNumber($discounttotal));
			if($promo['recurring'] == "0"){
				$recurring=$_SESSION['gamecp']['orderDetails']['originalGross'];
			} else $recurring=$newprice;
			$_SESSION['gamecp']['orderDetails']['recurringPrice']=$Order->FormatNumber($recurring);
			echo $Order->FormatNumber($newprice).":_:".$Order->FormatNumber($discounttotal).":_:".$Order->FormatNumber($recurring);
		} else {
			echo "failed:_:".$Order->FormatNumber($_SESSION['gamecp']['orderDetails']['originalGross']);
			$_SESSION['gamecp']['orderDetails']['packageGross']=$Order->FormatNumber($_SESSION['gamecp']['orderDetails']['originalGross']);
		}
	} else echo "failed2:_:";
}

if($mode == "checkuser") {
	$hook_vars='';
	run_hook("order_checkuser");

	$userInfo=$Order->GetUser($user);
	if($_REQUEST['pass'] == $userInfo['password']){
		if($userInfo['userlevel'] == "0"){
			$_SESSION['gamecp']['orderDetails']['firstname'] = $userInfo['firstname'];
			$_SESSION['gamecp']['orderDetails']['lastname'] = $userInfo['lastname'];
			$_SESSION['gamecp']['orderDetails']['address'] = $userInfo['address'];
			$_SESSION['gamecp']['orderDetails']['address2'] = $userInfo['address2'];
			$_SESSION['gamecp']['orderDetails']['phone'] = $userInfo['phone'];
			$_SESSION['gamecp']['orderDetails']['zip'] = $userInfo['zip'];
			$_SESSION['gamecp']['orderDetails']['state'] = $userInfo['state'];
			$_SESSION['gamecp']['orderDetails']['country'] = $userInfo['country'];
			$_SESSION['gamecp']['orderDetails']['city'] = $userInfo['city'];
			$_SESSION['gamecp']['orderDetails']['clienturl'] = $userInfo['website'];
			$_SESSION['gamecp']['orderDetails']['freseller'] = $userInfo['rsid'];
			$_SESSION['gamecp']['orderDetails']['fnote'] = "Order system add to user - ". $userInfo['name'];
			$_SESSION['gamecp']['orderDetails']['username']=$userInfo['name'];
			$_SESSION['gamecp']['orderDetails']['password']=$userInfo['password'];
			$_SESSION['gamecp']['orderDetails']['email'] = $userInfo['email'];
			$_SESSION['gamecp']['orderDetails']['userid'] = $userInfo['id'];
			$_SESSION['gamecp']['orderDetails']['taxeduser'] = $userInfo['taxed'];
			$_SESSION['gamecp']['orderDetails']['existingcustomercredit'] = $userInfo['credit'];
			$_SESSION['gamecp']['orderDetails']['existingcustomer'] = true;
			echo "true";
		} else echo "false";
	} else echo "false";
}

if(isset($_REQUEST['checkUserName'])){	

	$hook_vars='';
	run_hook("order_checkusername");

	$response = array();
	$invalidnames=$Order->InvalidNames();
	if(in_array($username, $invalidnames)){
		$total="1";
	} else {
		$uname = sql_query($safesql->query("SELECT name FROM users where name='%s' LIMIT 1;", array($GameCP->whitelist($username, "username")))) or die(mysql_error());
		$total= mysql_num_rows($uname);
	}

	if($total >= "1"){
		echo " Used";
	}elseif($total == "0") echo " Available";

}

if(isset($_REQUEST['checkEmail'])){	
	$hook_vars='';
	run_hook("order_checkemail");

	$response = array();
	$GameCP->loadIncludes("panel");
	$Panel=new Panel();
	$invalidnames=$Panel->InvalidNames();
	if(in_array($email, $invalidnames)){
		$total="1";
	} else {
		$uname = sql_query($safesql->query("SELECT id FROM users where email='%s' LIMIT 1;", array($GameCP->whitelist($email, "clean")))) or die(mysql_error());
		$total= mysql_num_rows($uname);
	}

	if($total >= "1"){
		echo "Used";
	}elseif($total == "0") echo "Available";
}


?>