<?php
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

session_start();

$noheader=true;
$billingPage=true;
require('../includes/config.inc.php');

$disabled=false;
if(usebilling != "1"){ echo "This feature is disabled."; $disabled = true; }


if(isset($_REQUEST['id'])){
	$_SESSION['gamecp']['donateid']=$_REQUEST['id'];
	$id=$_REQUEST['id'];
} elseif(isset($_SESSION['gamecp']['donateid'])){
	$id=$_SESSION['gamecp']['donateid'];
} 

if(!$disabled){
	$GameCP->loadIncludes("billing");
	$Billing=new Billing(); 

	$GameCP->loadIncludes("panel");
	$Panel=new Panel();

if(!$id) $Panel->ErrorExit('Required variaibles are missing.');	

// get usr 
$userInfoQ = sql_query($safesql->query("SELECT * FROM users WHERE id = '%i'", array($GameCP->whitelist($id, "int")))) or die(mysql_error());
if(mysql_num_rows($userInfoQ) == 0) $Panel->ErrorExit('Unable to accept donations for this id.');	
$userInfo = mysql_fetch_array($userInfoQ);

$perms=unserialize($userInfo['permissions']);
if(!isset($perms['donations'])) $Panel->ErrorExit('Donations are not enabled');
$_REQUEST['noheader']=true;
if(isset($return)){
	// need form resubkit chek
	$paidPrice="";
	$paidFee="";
	$transactionid="";
	$subid="";
	$responseMessage="";

	if(isset($_SESSION['gamecp']['donation_complete'])){
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$Panel->ErrorExit("Donation already completed.");
	}
	$_SESSION['gamecp']['donation_complete']=true;

	if(!$paymentCode || isset($_REQUEST['orderStatus']) || isset($_REQUEST['responseMessage'])){
		$GameCP->loadIncludes("panel");
		$Panel=new Panel();
		$Panel->ErrorExit("Request has failed, unable to load gateway");
	} 

	$Billing->LoadGateway($paymentCode, true);

	switch($orderStatus){
		case "Failed":
			$responseMessage = "Payment failed";
		break;

		case "Completed":
			// log and credit
			if($paidPrice > 0) $Billing->UserCreditInsert($id, $paidPrice);
			$responseMessage = "Payment Completed";
		break;
		
		case "Pending":
			// log
			$responseMessage = "Payment Pending";
		break;

		case "IPN":
			$responseMessage = "Your payment has been received and will be processed shortly.";
		break;
	}

	if($orderStatus !='IPN') $Billing->AddDonation($id, $paymentCode, $_SESSION['gamecp']['orderDetails']['gross'], $paidFee, $paidPrice, $transactionid, $orderStatus, $_SERVER['REMOTE_ADDR'], $_SESSION['gamecp']['donate_email']);
	

	$smarty->assign("responseMessage", $responseMessage);
	$smarty->assign("completed", true);
	$smarty->display("billing/clanpay.tpl");

}elseif(!isset($_REQUEST['mode'])){
		unset($_SESSION['gamecp']['donation_complete'],$_SESSION['gamecp']['orderDetails'], $_SESSION['gamecp']['payment'],$_SESSION['gamecp']['donate_email']);
		$paymentMethods = sql_query("SELECT id, name, fullname FROM gateways WHERE status = '1'") or die(mysql_error());
		$gateways=array();
		$gi=0;
		while ($row = mysql_fetch_array($paymentMethods)){
			$gateways[$gi]=$row;
			$gi++;
		}
		$smarty->assign("gateways", $gateways);
		$smarty->assign("id", $id);
		$smarty->display("billing/clanpay.tpl");
} elseif(isset($_REQUEST['mode'])){
	if($_REQUEST['mode'] == '' || $_REQUEST['email'] == $LNG_EMAIL || $_REQUEST['gross'] == "0"){
		$smarty->assign("error", true);
		$smarty->display("billing/clanpay.tpl");
	} else {
		$info['username']=$userInfo['name'];
		$info['lastname']=$userInfo['lastname'];
		$info['firstname']=$userInfo['firstname'];
		$info['email']=$userInfo['email'];
		$info['steet_address']=$userInfo['address'];
		$info['steet_address2']=$userInfo['address2'];
		$info['city']=$userInfo['city'];
		$info['state']=$userInfo['state'];
		$info['country']=$userInfo['country'];
		$info['zip']=$userInfo['zip'];
		$info['phone']=$userInfo['phone'];
		$info['gross']=$_REQUEST['gross'];
		$info['plaingross']=$_REQUEST['gross'];
		$info['credit']='';
		$info['qid']='';
		$info['gmid']='';
		$_SESSION['gamecp']['payment']['bid']='';
		$_SESSION['gamecp']['payment']['donateid']=$id;

		$_SESSION['gamecp']['orderDetails']=$info;

		$_SESSION['gamecp']['donate_email']=$email;
		$smarty->assign("donationform",'true');
		$smarty->assign("id", $id);

		$smarty->assign("info",array($info));
		$smarty->assign('urlstring', "&gross=".$info['gross']);
		$smarty->assign('return', "/order/donate.php?return=true");
		$smarty->assign('MAILINGADDRESS', nl2br(MAILINGADDRESS));
		$smarty->assign("today", time());
		$smarty->assign("paypalSubscriptions", "false");

		$Billing->InvoiceDescription('donation', $id);

		$gateway=$Billing->LoadGateway($_REQUEST['mode']);

		$smarty->assign('gatewayTesting', $gateway['testing']);
		$smarty->assign('privkey', urlencode(md5($gateway['value1'].$id)));
		$smarty->assign('value1', $gateway['value1']);
		$smarty->assign('value2', $gateway['value2']);
		$smarty->assign('value3', $gateway['value3']);
		$smarty->assign('gateway', $gateway);

		$smarty->display("billing/clanpay.tpl");
		$smarty->display("gateways/".$_REQUEST['mode']."/form.tpl");
	}
	
}



}

?>
</td></tr></table>
<?php
 

$smarty->display("order/footer.tpl");
$smarty->display("footers/external.tpl");



 ?>