<?php 
/*
	GameCP - Game Server Control Panel
	Copyright (c) 2004 - 2013 All Rights Reserved.	
	----------------------------------------------	
	This document is bound under the GameCP Terms 
	of Use and MUST NOT be removed, distributed in any form, released
	or modified, without written permission from GameCP.

	The GameCP Terms of Use are agreed to upon installation
	of this software. If you do not agree to them remove GamecP from 
	your 
	The source code or encoded versions of the source code
	must ONLY exist on approved GameCP Licensed Servers.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/


session_start();
$_SESSION['gamecp']['orderapi']=true;
define("_GAMECP_", "gamecp");

if(isset($_REQUEST['mode']) && $_REQUEST['mode'] == "start" || !isset($_REQUEST['mode']) && !isset($_REQUEST['paymentCode'])) unset($_SESSION['gamecp']['orderDetails']);
if(isset($_SESSION['gamecp']['orderDetails'])) $orderDetails=$_SESSION['gamecp']['orderDetails'];


if(@$_GET['mode']){ 
	$mode=@$_GET['mode'];
} else $mode=@$_POST['mode'];


/* CHANGE PATH TO PANEL ROOT */
if(isset($PATH) && $PATH != ""){
	$gameCPPath=$PATH;
} else $gameCPPath="..";

$noheader=true;
if(is_file($gameCPPath."/includes/mysql.inc.php") && !defined('noloadout')) require_once($gameCPPath."/includes/mysql.inc.php");

if(function_exists("mysql_set_charset")){
	mysql_set_charset('utf8');
} else mysql_query("SET NAMES utf8");

if(is_file($gameCPPath.'/includes/core/includes/gamecp/settings.inc.php') && !defined('noloadout')) require_once($gameCPPath.'/includes/core/includes/gamecp/settings.inc.php'); 

$GameCP->loadIncludes("order");
$Order=new Order();
$smarty->assign("Order", $Order);



if(isset($_REQUEST['rsid'])) setcookie("gcporderrsid", $Order->whitelist($_REQUEST['rsid']), time()+900000, '', '', '', true);

if(isset($_REQUEST['changeLanguage']) && isset($_POST["lang"])){
	@setcookie("gcplang", $Order->whitelist($_POST['lang']), time()+900000, '', '', '', true); 
	$_SESSION['gamecp']['lang'] = $Order->whitelist($_POST['lang']);
}


/* currency exchange support */
$currencies=array();
$result = sql_query("SELECT * FROM currencies") or die(mysql_error());
while ($row = mysql_fetch_array($result)) $currencies[]=$row;
$smarty->assign("currencyList",$currencies);

$smarty->assign('defaultCurrencyName', currencyName);


if(isset($_REQUEST['currency'])) $_SESSION['gamecp']['currency']=$Order->whitelist($_REQUEST['currency']);

if(isset($_SESSION['gamecp']['currency'])){
	$GameCP->loadIncludes("billing");
	$Billing=new Billing(); 
	$exchange=$Billing->ExchangeRate($_SESSION['gamecp']['currency']);
	if(isset($exchange['code'])){
		$_SESSION['gamecp']['orderDetails']['currency']=$_SESSION['gamecp']['currency'];
		$_SESSION['gamecp']['exchange']=$exchange;
		$smarty->assign('currencyName', $exchange['code']);
		$smarty->assign('currencyChar', $exchange['prefix']);
		$smarty->assign('currencyChar2', $exchange['suffix']);
	}else unset($_SESSION['gamecp']['exchange'], $_SESSION['gamecp']['orderDetails']['currency']);
} 



/* settings */
	$settings = parse_ini_file("settings.ini");
	$showLocal = $settings['showLocal'];
	$showGameProfile = $settings['showGameProfile'];
	$autoLocal = $settings['autoLocal'];
	$overLoad = $settings['overLoad'];
	$requireUserDetails = $settings['requireUserDetails'];
	$doQueue = $settings['doQueue'];
	$doVoice = $settings['doVoice'];
	$displayReseller = $settings['displayReseller'];
	$countryDisplay = $settings['countryDisplay'];
	$ipnReplyMessage = $settings['ipnReplyMessage'];
	$tosAgreeMessage = $settings['tosAgreeMessage'];
/* end settings */

if(usebilling != "1" || (isset($_SESSION['gamecp']['basic']) && $_SESSION['gamecp']['basic'] == "1")) $Order->Error($LNG_FEATUREDISABLED); 

if(isset($_REQUEST['changeLanguage']) && isset($_POST["lang"])){
	$smarty->assign('gcplang', $Order->whitelist($_POST['lang']));
} else if(isset($_COOKIE['gcplang'])){
	$smarty->assign('gcplang', $Order->whitelist($_COOKIE['gcplang']));
} else $smarty->assign('gcplang', defaultlang);


if(isset($_REQUEST['noheader'])){
	$_SESSION['gamecp']['noheader']="true";
}else if($mode == "start" || !$mode)unset($_SESSION['gamecp']['noheader']);
if(isset($_SESSION['gamecp']['noheader']))$_REQUEST['noheader']=true;

if(!isset($nohead)){
	$smarty->display("headers/external.tpl");
	$smarty->display("order/header.tpl");
}
if(!empty($_GET)) extract($_GET, EXTR_SKIP);
if(!empty($_POST)) extract($_POST, EXTR_SKIP);

if(isset($_REQUEST['paymentcode'])) $_REQUEST['paymentCode'] = $_REQUEST['paymentcode'];
if(isset($_REQUEST['paymentCode'])){
	if($_REQUEST['paymentCode'] && !isset($_REQUEST['s'])) $mode = "processPayment";
	if($_REQUEST['paymentCode'] && isset($_REQUEST['s'])) $mode = "paymentCompleted";
}
if(!isset($_REQUEST['gmid'])){
	$_REQUEST['gmid']='';
} else $_REQUEST['gmid']=$Order->whitelist($_REQUEST['gmid'], 'int');

if($mode == "paymentCompleted"){
	if($_REQUEST['s'] == "C"){
		$smarty->display("order/cancelorder.tpl");
	} else {
		$smarty->assign("responseMessage", $ipnReplyMessage);
		$smarty->display("order/ipn.tpl");
	}
}

if((isset($_REQUEST['finishSetup']) && $_REQUEST['finishSetup']) || (isset($_REQUEST['orderStatus']) && $_REQUEST['orderStatus'])) $Order->Error($LNG_INVALIDACCESS);
$finishSetup="";
$orderStatus="";

if($mode == "processPayment"){
	if(isset($_SESSION['gamecp']['orderDetails']['freeorder']) && $_SESSION['gamecp']['orderDetails']['freeorder'] == true){
		$finishSetup = "finishsetup";
		$orderStatus = "Completed";
		$paidPrice= "0.00";
		$paidFee= "0.00";
		$subscr_idALT="";
	} else {
		$paymentCode=$Order->whitelist($_REQUEST['paymentCode'], "useredit");
		$gatewayFile=$PATH."/includes/gateways/".$paymentCode."/return.php";
		if(is_file($gatewayFile)){ require_once($gatewayFile);
			if($orderStatus == "IPN"){
				$smarty->assign("responseMessage", $responseMessage);
				$smarty->display("order/ipn.tpl");
				exit; 
			}elseif($orderStatus == "Failed"){
				if(!isset($responseMessage)) $responseMessage='';
				$smarty->assign("errorCode", $errorCode);
				$smarty->assign("responseMessage", $responseMessage);
				$smarty->display("order/error.tpl");
				exit; 
			}elseif($orderStatus == "Completed"){
				$finishSetup="finishsetup";
			}elseif($orderStatus == "Pending" || !$orderStatus){
				$doQueue="1";
				$queueLevel="3";
				$finishSetup="finishsetup";
			}
		} else $Order->Error($LNG_MISSINGGATEWAY);
	}
}


if($mode == "start" || !$mode) { 
	$smarty->assign("packArray", $Order->GetCategories());
	$smarty->display("order/start.tpl");
	$_SESSION['gamecp']['orderDetails']['last_mode']="start";
} 

if($mode == "step1"){
	$packageList="";
	$pl=$Order->GetPackages($doVoice, $_REQUEST['gmid'], @$_REQUEST['cat']);
	$smarty->assign("packArray", $pl);
	$smarty->assign("packageListTotal", count($pl));

	$hook_vars=$pl;
	run_hook("order_start");

	if(orderstyle == "x"){
		$smarty->display("order/index.tpl");
	} else $smarty->display("order/index-row.tpl");
	
	$_SESSION['gamecp']['orderDetails']['last_mode']=$_SERVER['QUERY_STRING'];
}


// This mode will let the user pick the term they want, it will update with the terms price.
if($mode == "step2") { 
	/* settings */
		$privselect=false;
		$publicselect=false;
		$hasprivate=false;
		$haspublic=false;
		$hasprivateplushour=false;
		$haspublicplushour=false;
		$voiceList="";
		$location="";
		$localRows='';

	/* reset settings */
		if(isset($_SESSION['gamecp']['orderDetails']['recurringPrice']))	unset($_SESSION['gamecp']['orderDetails']['recurringPrice']);
		if(isset($_SESSION['gamecp']['orderDetails']['packageGross']))		unset($_SESSION['gamecp']['orderDetails']['packageGross']);
		if(isset($_SESSION['gamecp']['orderDetails']['packageGrossA']))		unset($_SESSION['gamecp']['orderDetails']['packageGrossA']);
		if(isset($_SESSION['gamecp']['orderDetails']['originalGross']))		unset($_SESSION['gamecp']['orderDetails']['originalGross']);
		if(isset($_SESSION['gamecp']['orderDetails']['originalCost']))		unset($_SESSION['gamecp']['orderDetails']['originalCost']);
		if(isset($_SESSION['gamecp']['orderDetails']['originalFee']))		unset($_SESSION['gamecp']['orderDetails']['originalFee']);
		if(isset($_SESSION['gamecp']['orderDetails']['voiceCost']))			unset($_SESSION['gamecp']['orderDetails']['voiceCost']);
		if(isset($_SESSION['gamecp']['orderDetails']['voiceFee']))			unset($_SESSION['gamecp']['orderDetails']['voiceFee']);
		if(isset($_SESSION['gamecp']['orderDetails']['voiceName']))			unset($_SESSION['gamecp']['orderDetails']['voiceName']);
		if(isset($_SESSION['gamecp']['orderDetails']['voicePackage']))		unset($_SESSION['gamecp']['orderDetails']['voicePackage']);
		if(isset($_SESSION['gamecp']['orderDetails']['voicePackageID']))	unset($_SESSION['gamecp']['orderDetails']['voicePackageID']);
		if(isset($_SESSION['gamecp']['orderDetails']['voiceInstall']))		unset($_SESSION['gamecp']['orderDetails']['voiceInstall']);
		if(isset($_SESSION['gamecp']['orderDetails']['voiceMaxClients']))	unset($_SESSION['gamecp']['orderDetails']['voiceMaxClients']);
		if(isset($_SESSION['gamecp']['orderDetails']['voiceType']))			unset($_SESSION['gamecp']['orderDetails']['voiceType']);
		if(isset($_SESSION['gamecp']['orderDetails']['atotal']))			unset($_SESSION['gamecp']['orderDetails']['atotal']);
		if(isset($_SESSION['gamecp']['orderDetails']['paddons']))			unset($_SESSION['gamecp']['orderDetails']['paddons']);
		if(isset($_SESSION['gamecp']['orderDetails']['promoUsed']))			unset($_SESSION['gamecp']['orderDetails']['promoUsed']);
		if(isset($_SESSION['gamecp']['orderDetails']['serverLocation']))	unset($_SESSION['gamecp']['orderDetails']['serverLocation']);
		if(isset($_REQUEST['hourly']) && ($_REQUEST['hourly']=="true"||$_REQUEST['hourly']=="checked")) $_REQUEST['packageTerm']="hourly";
	
	/* next 2 requests allow jumping directly here */
		if(isset($_REQUEST['gmida']) && $_REQUEST['gmida']){
			$_SESSION['gamecp']['orderDetails']['gmida']=$Order->whitelist($_REQUEST['gmida'], "int");
			$gmida=$Order->whitelist($gmida, "int");
		} else $gmida=$_SESSION['gamecp']['orderDetails']['gmida'];
		
		if(isset($_REQUEST['packagePubPriv']) && $_REQUEST['packagePubPriv']){
			$_SESSION['gamecp']['orderDetails']['packagePubPriv']=$Order->whitelist($packagePubPriv, "clean");
		} elseif(isset($_SESSION['gamecp']['orderDetails']['packagePubPriv'])){
			$packagePubPriv = $_SESSION['gamecp']['orderDetails']['packagePubPriv'];
		} else $packagePubPriv = "Public";
		if(!isset($_SESSION['gamecp']['orderDetails']['packagePubPriv'])) $_SESSION['gamecp']['orderDetails']['packagePubPriv']="Public";

	$privInfo=$Order->GetPrices($_REQUEST['gmida'], "Private", '', $_REQUEST['gmid']);
	$prodInfo=$Order->GetPrices($_REQUEST['gmida'], "Public", '', $_REQUEST['gmid']);

	if(is_array($prodInfo)){
		$haspublic=true;
		foreach($prodInfo as $p => $l){
			if(isset($l[0])){
				$l=$l[0];
				if(isset($l['pid']) && $l['pid'] == $gmida){
					$publicselect=true;
					if($l['rate']) $haspublicplushour=true;
				}
			}
		}
	}

	if(is_array($privInfo)){
		$hasprivate=true;
		foreach($privInfo as $p => $l){
			if(isset($l[0])){
				$l=$l[0];
				if(isset($l['pid']) && $l['pid'] == $gmida){
					$privselect=true;
					if($l['rate']) $hasprivateplushour=true;
				}
			}
		}
	}

	if(!$haspublic && !$hasprivate) $Order->Error($LNG_NOPRODUCTS);

	/* we're want public but have none (or we are private) so switch to private */
	if(($haspublic == false  && $packagePubPriv == "Public" && $hasprivate == true) || $packagePubPriv == "Private"){
		$prodInfo=$privInfo;
		$_SESSION['gamecp']['orderDetails']['packagePubPriv']="Private";
		$packagePubPriv="Private";
	}

	$productList=$prodInfo[0];
	
	/* came here w/o a price, so we want to pull the products default price */	
	if(!$_REQUEST['gmid'] || (isset($_REQUEST['changet']) && $changet == "package")){
		$_REQUEST['gmid']=$productList[0]['id'];
		$smarty->assign("selectedproduct", $prodInfo[0][0]);
	} else $smarty->assign("selectedproduct", $prodInfo[7]);
	
	$packageInfo=$Order->GetPackageInfo($gmida);
	$package=$Order->GetPriceInfo($Order->whitelist($_REQUEST['gmid'], "int"));
	$paddons=$Order->ProductAddons($gmida, $_SESSION['gamecp']['orderDetails']['packagePubPriv']);
	$gName=$Order->GetPackageGame($packageInfo['gid']);

	$packageName = $packageInfo['name'];
	$packageGid = $packageInfo['gid'];
	$packageSubName = $package['name'];
	$packageSlots = $package['slots'];
	$packageFee = $package['fee'];
	$packageGame = $gName['name'];

	if(!isset($_REQUEST['packageTerm'])){
		if($package['monthly']){
			$packageTerm="monthly";
		} elseif($package['quarterly']){
			$packageTerm="quarterly";
		} elseif($package['semiannualy']){
			$packageTerm="semiannualy";
		} elseif($package['annauly']){
			$packageTerm="annauly";
		} elseif($package['hourly']){
			$packageTerm="hourly";
		} elseif($package['2years']) $packageTerm="2years";
	} else $packageTerm=$_REQUEST['packageTerm'];


	if($packageGid != "0"){
		if($doVoice != "0" && $packageGid > "0" && $packageGid != "1000" && $packageGid != "1001" && $packageGid != "1002" && $packageGid != "1003" && $packageGid != "1004"){
			$voiceIds=$Order->GetVoicePackageID();
			if($voiceIds['ts2id'])	$voiceList .= $Order->GetVoiceListHTML("TeamSpeak 2", $voiceIds['ts2id'], $Order->whitelist($packageTerm));
			if($voiceIds['ts3id'])	$voiceList .= $Order->GetVoiceListHTML("TeamSpeak 3", $voiceIds['ts3id'], $Order->whitelist($packageTerm));
			if($voiceIds['vent'])	$voiceList .= $Order->GetVoiceListHTML("Ventrilo", $voiceIds['vent'], $Order->whitelist($packageTerm));
			if($voiceIds['mohawk']) $voiceList .= $Order->GetVoiceListHTML("Mohawk", $voiceIds['mohawk'], $Order->whitelist($packageTerm));
			if($voiceIds['mumble']) $voiceList .= $Order->GetVoiceListHTML("Mumble", $voiceIds['mumble'], $Order->whitelist($packageTerm));
		 } 

		if($showLocal == "1"){ 
			if($packageGid != "1001" && $packageGid != "1002" && $packageGid != "1003" && $packageGid != "1004"){
				$locations=$Order->GetLocations($packageGid, $packageSlots);
			} else $locations=$Order->GetVoiceLocations($packageGid, $packageSlots);

			$uniquebox=array();
			$lc=0;
			if(is_array($locations)){
				if($packageGid == "1001" && usedarkstarvent == "yes"){
					foreach($locations as $rowid => $rowdata){
						$location.= "<option value=\"". $rowid ."\">". $rowdata . " - Ventrilo"; 
						$lc++;
					}
				} else {
					foreach($locations as $row) {
						$type=$row[1];
						if($type == "0" || $type == "")  $type="Linux"; 
						if($type == "2")				 $type="BSD"; 
						if($type == "1" || $type == "3") $type="Windows";
						if($row[0]){
							if(!in_array($row[0] . " - " .$type, $uniquebox)){
								$location.= "<option value=\"". $row[0] ."\">". $row[0] . " - " .$type; 
								$uniquebox[]=$row[0] . " - " .$type;
								$lc++;
							}
						}
					}
				}
			}
			$localRows=$lc;

			if($overLoad == '0' && count($locations) == "0") $Order->Error($LNG_SOLDOUT);
			$smarty->assign("locations", $locations);
		}
	}


	/* if hourly only package show that option */
	if((isset($hourly) && $hourly=="true") || ($package['hourly'] && !$package['monthly']  && !$package['quarterly']  && !$package['semiannualy']  && !$package['annauly']  && !$package['2years'])){
		$_REQUEST['packageTerm']="hourly";
		$packageTerm="hourly";
	} 

	$allowedterms=array("monthly", "quarterly", "semiannualy", "annauly", "2years", "hourly");
	if(!in_array($packageTerm, $allowedterms))  $Order->Error($LNG_INVALIDPACKAGE);
	if(!$package[$packageTerm])  $Order->Error($LNG_INVALIDPACKAGE2);

	/* remember all fields */
		$_SESSION['gamecp']['orderDetails']['packageFee']=		$Order->whitelist($packageFee, "clean");
		$_SESSION['gamecp']['orderDetails']['gmid']=			$Order->whitelist($_REQUEST['gmid'], "int");
		$_SESSION['gamecp']['orderDetails']['gmida']=			$Order->whitelist($gmida, "int");
		$_SESSION['gamecp']['orderDetails']['taxproduct']=		$Order->whitelist($prodInfo[5], "int");
		$_SESSION['gamecp']['orderDetails']['taxaddons']=		$Order->whitelist($prodInfo[6], "int");
		$_SESSION['gamecp']['orderDetails']['packagePubPriv']=	$Order->whitelist($packagePubPriv, "clean");
		$_SESSION['gamecp']['orderDetails']['packageName']=		$Order->whitelist($packageName, "clean");
		$_SESSION['gamecp']['orderDetails']['packageSubName']=	$Order->whitelist($packageSubName, "clean");
		$_SESSION['gamecp']['orderDetails']['packageCost']=		$package[$Order->whitelist($packageTerm, "clean")];
		$_SESSION['gamecp']['orderDetails']['packageRate']=		$package['hourly'];
		$_SESSION['gamecp']['orderDetails']['packageGid']=		$Order->whitelist($packageGid, "clean");
		$_SESSION['gamecp']['orderDetails']['packageGame']=		$Order->whitelist($packageGame, "clean");
		$_SESSION['gamecp']['orderDetails']['packageSlots']=	$Order->whitelist($packageSlots, "clean");
		$_SESSION['gamecp']['orderDetails']['packageTerm']=		$Order->whitelist($packageTerm, "clean");

	/* goto smarty */
		$smarty->assign("privselect",			$privselect);
		$smarty->assign("publicselect",			$publicselect);
		$smarty->assign("packagePubPriv",		$Order->whitelist($packagePubPriv, "clean"));
		$smarty->assign("packageName",			$Order->whitelist($packageName, "clean"));
		$smarty->assign("productDescription",	$productList[0]['description']);
		$smarty->assign("mode",					$mode);
		$smarty->assign("gmid",					$_REQUEST['gmid']);
		$smarty->assign("gmida",				$gmida);
		$smarty->assign("productDescription",	$packageInfo['description']);
		$smarty->assign("paddons",				$paddons);
		$smarty->assign("package",				$package);
		$smarty->assign("voiceList",			$voiceList);
		$smarty->assign("location",				$location);
		$smarty->assign("autoLocal",			$Order->whitelist($autoLocal, "clean"));
		$smarty->assign("localRows",			$Order->whitelist($localRows, "clean"));
		$smarty->assign("showLocal",			$Order->whitelist($showLocal, "clean"));
		$smarty->assign("packageName",			$Order->whitelist($packageName, "clean"));
		$smarty->assign("packagePubPriv",		$Order->whitelist($packagePubPriv, "clean"));
		$smarty->assign("packageSubName",		$Order->whitelist($packageSubName, "clean"));
		$smarty->assign("packageGid",			$Order->whitelist($packageGid, "clean"));
		$smarty->assign("today", time());
		$smarty->assign("tomorrow", strtotime('+1 day 15minutes'));
		$smarty->assign("soon", strtotime('+15 minutes'));

	$hook_vars=$packageTerm;
	run_hook("order_pickpackageterm");

	$smarty->display("order/productterm.tpl");
	
	$_SESSION['gamecp']['orderDetails']['last_mode']=$_SERVER['QUERY_STRING'];

}


// This mode asks for the user information, the system and user profile.
if($mode == "uprofile") {   
	if(!isset($_SESSION['gamecp']['orderDetails']['gmida'])) die("<meta http-equiv=\"Refresh\" content=\"".$pgrefresh.";url=". $url . "/order/\">");


	$gmida =			$_SESSION['gamecp']['orderDetails']['gmida'];
	$gmid =				$_SESSION['gamecp']['orderDetails']['gmid'];
	$packageName =		$_SESSION['gamecp']['orderDetails']['packageName'];
	$packageSubName =	$_SESSION['gamecp']['orderDetails']['packageSubName'];
	$packagePubPriv =	$_SESSION['gamecp']['orderDetails']['packagePubPriv'];
	$packageCost =		$_SESSION['gamecp']['orderDetails']['packageCost'];
	$packageRate =		$_SESSION['gamecp']['orderDetails']['packageRate'];
	$packageGid =		$_SESSION['gamecp']['orderDetails']['packageGid'];
	$packageGame =		$_SESSION['gamecp']['orderDetails']['packageGame'];
	$packageSlots =		$_SESSION['gamecp']['orderDetails']['packageSlots'];

	if(!isset($_POST['retry'])){

		if(isset($_SESSION['gamecp']['orderDetails']['packageTerm'])){
			$packageTerm=$_SESSION['gamecp']['orderDetails']['packageTerm'];
		} else $packageTerm=$Order->whitelist($_REQUEST['packageTerm']);

		$package = $Order->GetPriceInfo($gmid);
		$packageGross=$package[$packageTerm];
		$packageFee=$package['fee'];

		if(!isset($_SESSION['gamecp']['orderDetails']['packageGross'])) $_SESSION['gamecp']['orderDetails']['packageGross']=$packageGross;
		if(!isset($_SESSION['gamecp']['orderDetails']['packageGrossA'])) $_SESSION['gamecp']['orderDetails']['packageGrossA']=$packageGross;
		if(!isset($_SESSION['gamecp']['orderDetails']['packageTerm'])) $_SESSION['gamecp']['orderDetails']['packageTerm']=$packageTerm;
		if(!isset($_SESSION['gamecp']['orderDetails']['originalGross'])) $_SESSION['gamecp']['orderDetails']['originalGross']=$packageGross;
		if(!isset($_SESSION['gamecp']['orderDetails']['originalCost'])) $_SESSION['gamecp']['orderDetails']['originalCost']=$packageGross;
		if(!isset($_SESSION['gamecp']['orderDetails']['originalFee'])) $_SESSION['gamecp']['orderDetails']['originalFee']=$packageFee;
		$t='';

		if($packageTerm == "hourly") {

			$start_stamp=strtotime($Order->whitelist($_REQUEST['start_time'], "clean"));
			$end_stamp=strtotime($Order->whitelist($_REQUEST['end_time'], "clean"));

			$diff=$end_stamp - $start_stamp;
			$t=round($diff/3600,0);

			$packageGrossOG=$packageGross;
			$packageGross=$packageRate * $t;

			if($t == "0" || $t < 0) $Order->Error($LNG_INVALIDTIMESELECT);
			if(time() > $start_stamp || time() > $end_stamp) $Order->Error($LNG_INVALIDTIMESELECT2);

			$_SESSION['gamecp']['orderDetails']['packageGross']=$packageGross;
			$_SESSION['gamecp']['orderDetails']['packageGrossA']=$packageGross;
			$_SESSION['gamecp']['orderDetails']['originalCost']=$packageGross;
			$_SESSION['gamecp']['orderDetails']['originalGross']=$packageGross;
			$_SESSION['gamecp']['orderDetails']['hours']=$t;
			$_SESSION['gamecp']['orderDetails']['start_time'] = $start_stamp;
			$_SESSION['gamecp']['orderDetails']['end_time'] = $end_stamp;
	
			$smarty->assign("hoursordered", $t);
		}

		$gatewayList="";
		$gateways=$Order->GetGateways();
		foreach ($gateways as $row) $gatewayList.="document.getElementById('". $row['name'] ."').style.display='none';";
		
		$packageGrossA = $packageGross;

		if($doVoice != "0" && $packageGid != "1000" && $packageGid > "0" && $packageGid != "1001" && $packageGid != "1002" && $packageGid != "1003" && $packageGid != "1004"){
			if(isset($voice) && $voice){
				$voiceQ=explode(":", $voice);
				$voiceType=$voiceQ[0];
				$voicePack=$voiceQ[1];

				$voicePrice = $Order->GetPriceInfo($voicePack);
				$voiceCost = $voicePrice[$packageTerm];
				$voiceFee = $voicePrice['fee'];
				$voiceName = $voicePrice['name'];
				$voiceSlots = $voicePrice['slots'];

				$voicePackage = $Order->GetPackageInfo($voiceType);

				if(!isset($_SESSION['gamecp']['orderDetails']['voiceserver']))		$_SESSION['gamecp']['orderDetails']['voiceserver']=true;
				if(!isset($_SESSION['gamecp']['orderDetails']['taxvoice']))			$_SESSION['gamecp']['orderDetails']['taxvoice']=$voicePackage['tax'];
				if(!isset($_SESSION['gamecp']['orderDetails']['voiceCost']))			$_SESSION['gamecp']['orderDetails']['voiceCost']=$voiceCost;
				if(!isset($_SESSION['gamecp']['orderDetails']['voiceFee']))			$_SESSION['gamecp']['orderDetails']['voiceFee']=$voiceFee;
				if(!isset($_SESSION['gamecp']['orderDetails']['voiceName']))			$_SESSION['gamecp']['orderDetails']['voiceName']=$voiceName;
				if(!isset($_SESSION['gamecp']['orderDetails']['voicePackage']))		$_SESSION['gamecp']['orderDetails']['voicePackage']=trim($voicePackage['name']);
				if(!isset($_SESSION['gamecp']['orderDetails']['voicePackageID']))		$_SESSION['gamecp']['orderDetails']['voicePackageID']=$voicePack;
				if(!isset($_SESSION['gamecp']['orderDetails']['voiceInstall']))		$_SESSION['gamecp']['orderDetails']['voiceInstall'] = "yes";
				if(!isset($_SESSION['gamecp']['orderDetails']['voiceMaxClients']))	$_SESSION['gamecp']['orderDetails']['voiceMaxClients']=$voiceSlots;
				if(!isset($_SESSION['gamecp']['orderDetails']['voiceType']))			$_SESSION['gamecp']['orderDetails']['voiceType']=$voicePackage['gid'];

				$smarty->assign("doVoice", $doVoice);
				$smarty->assign("voiceCost", $voiceCost);
				$smarty->assign("voiceName", $voiceName);
				$smarty->assign("voicePackage", $voicePackage);

				if($voiceCost){
					$packageGross=$packageGross+$voiceCost;
					$_SESSION['gamecp']['orderDetails']['packageGross']=$packageGross;
					$_SESSION['gamecp']['orderDetails']['originalGross']=$packageGross;
				}
			}
			
		}

		if(isset($paddon) && is_array($paddon) && count($paddon) > 0){
			$ProcessAddonCost=$Order->ProcessAddonCost($paddon, $packageTerm, $t);

			$are=$ProcessAddonCost[0];
			$paddons=$ProcessAddonCost[1];
			$atotal=$ProcessAddonCost[2];

			$smarty->assign("paddons", $paddons);
			$_SESSION['gamecp']['orderDetails']['atotal']=$atotal;

			$packageGross=$packageGross+$atotal;
			$_SESSION['gamecp']['orderDetails']['packageGross']=$packageGross;
			$_SESSION['gamecp']['orderDetails']['originalGross']=$packageGross;

			$_SESSION['gamecp']['orderDetails']['paddonsOriginal']=$paddon;
			$_SESSION['gamecp']['orderDetails']['paddons']=$paddons;
		}

		if($packageTerm == "monthly") { $daystill="31"; } else
		if($packageTerm == "quarterly") { $daystill="91"; } else
		if($packageTerm == "semiannualy") { $daystill="182"; } else
		if($packageTerm == "annauly") { $daystill="365"; } else
		if($packageTerm == "2years") { $daystill="730"; } else $daystill="31"; 

		$_SESSION['gamecp']['orderDetails']['daystill'] = $daystill;

		$duedate = date('n/j/Y', strtotime("+$daystill days"));

		$_SESSION['gamecp']['orderDetails']['duedate']=$Order->whitelist($duedate, "clean");

		$resellerList="";
		if($displayReseller == "1"){  
			$resellers=$Order->GetResellerList();
			foreach($resellers as $row){
				if($row['name']) $resellerList.="<option value=\"".$row['id']."\">".$row['name']."</option>";
			}
		}

		if(!isset($serverLocation)) $serverLocation='';
		if(!isset($voiceType)) $voiceType='';
		if(!isset($voicePack)) $voicePack='';

		if(!isset($_SESSION['gamecp']['orderDetails']['recurringPrice'])) $_SESSION['gamecp']['orderDetails']['recurringPrice']=$packageGross;
		if(!isset($_SESSION['gamecp']['orderDetails']['serverLocation'])) $_SESSION['gamecp']['orderDetails']['serverLocation'] = $serverLocation;
		if(!isset($_SESSION['gamecp']['orderDetails']['voiceType']))		$_SESSION['gamecp']['orderDetails']['voiceType'] = $voiceType;
		if(!isset($_SESSION['gamecp']['orderDetails']['voicePack']))		$_SESSION['gamecp']['orderDetails']['voicePack'] = $voicePack;

		$hook_vars=array();
		run_hook("order_uprofile");


	}

	$gateWaySelect="";
	$gateways=$Order->GetGateways();
	foreach ($gateways as $row) $gateWaySelect.="<option value=\"". $row['name']. "\">". $row['fullname']."</option>";

	$smarty->assign("gatewayList", $gatewayList);
	$smarty->assign("requireUserDetails", $requireUserDetails);
	$smarty->assign("resellerList", $resellerList);
	$smarty->assign("displayReseller", $displayReseller);
	
	if($packageGid > 0)$smarty->assign("showGameProfile", $showGameProfile);
	
	$smarty->assign("countryDisplay", $countryDisplay);
	$smarty->assign("gateWaySelect", $gateWaySelect);

	if(maxEnable == "yes")$smarty->assign("maxEnable", "true");
	if(maxPhoneAuth == "yes"){
		$smarty->assign("maxPhoneAuth", "true");
		$smarty->assign("callCode", rand());
	}

	if(captcha == "yes"){
		require_once($PATH.'/includes/core/classes/captcha/recaptchalib.php');
		$smarty->assign("captcha", captcha);
		$smarty->assign("captchacode", recaptcha_get_html(captchapub, captchapriv, true));
	}

	if(isset($_SESSION['gamecp']['orderDetails']['taxtotal'])) unset($_SESSION['gamecp']['orderDetails']['taxtotal']);

	if(taxEnable == "yes") $smarty->assign("proReq", "true");

	$smarty->display("order/profile.tpl");

	$_SESSION['gamecp']['orderDetails']['last_mode']=$_SERVER['QUERY_STRING'];

} // end profie


// This mode will check to see if the user already exists on the control panel or the server, if it does it asks for a new name.
if($mode == "checkuser" || $mode == "checkmaxmind") { 
	if(captcha == "yes" && !isset($_SESSION['gamecp']['orderDetails']['existingcustomer'])){
		require_once($PATH.'/includes/core/classes/captcha/recaptchalib.php');
        $resp = recaptcha_check_answer (captchapriv,
                                        $_SERVER["REMOTE_ADDR"],
                                        $_POST["recaptcha_challenge_field"],
                                        $_POST["recaptcha_response_field"]);

        if (!$resp->is_valid) $Order->Error($LNG_CAPTCHAINCORRECT);
	}

	if(!isset($_SESSION['gamecp']['orderDetails']['gmida'])) $Order->Error($LNG_MISSINGSETTING);
	if(!isset($_REQUEST['paymentMethod']) && !$_SESSION['gamecp']['orderDetails']['paymentMethod']) $Order->Error($LNG_SELECTPAYMENT);

	$hook_vars='';
	run_hook("order_checkuser");

	if(isset($_REQUEST['firstcheck']) && $_REQUEST['firstcheck'] == "1"){
		/* store the new information in the array now */
		if(!isset($_SESSION['gamecp']['orderDetails']['existingcustomer']) || $_SESSION['gamecp']['orderDetails']['existingcustomer'] == false){
			$_SESSION['gamecp']['orderDetails']['existingcustomer'] = false;
			$_SESSION['gamecp']['orderDetails']['firstname'] =		@$_REQUEST['firstname'];
			$_SESSION['gamecp']['orderDetails']['lastname'] =		@$_REQUEST['lastname'];
			$_SESSION['gamecp']['orderDetails']['address'] =		@$_REQUEST['address'];
			$_SESSION['gamecp']['orderDetails']['address2'] =		@$_REQUEST['address2'];
			$_SESSION['gamecp']['orderDetails']['phone'] =			@$_REQUEST['phone'];
			$_SESSION['gamecp']['orderDetails']['zip'] =			@$_REQUEST['zip'];
			$_SESSION['gamecp']['orderDetails']['state'] =			@$_REQUEST['state'];
			$_SESSION['gamecp']['orderDetails']['country'] =		@$_REQUEST['country'];
			$_SESSION['gamecp']['orderDetails']['city'] =			@$_REQUEST['city'];
			$_SESSION['gamecp']['orderDetails']['clan'] =			@$_REQUEST['clan'];
			$_SESSION['gamecp']['orderDetails']['freseller'] =		@$_REQUEST['freseller'];
			$_SESSION['gamecp']['orderDetails']['fnote'] =			@$_REQUEST['fnote'];
		} else $_SESSION['gamecp']['orderDetails']['existingcustomer'] = true;

		$_SESSION['gamecp']['orderDetails']['paymentMethod'] =		$_REQUEST['paymentMethod'];
		$_SESSION['gamecp']['orderDetails']['rconpass'] =			@$_REQUEST['rconpass'];
		$_SESSION['gamecp']['orderDetails']['specpass'] =			@$_REQUEST['specpass'];
		$_SESSION['gamecp']['orderDetails']['privpass'] =			@$_REQUEST['privpass'];
		$_SESSION['gamecp']['orderDetails']['motd'] =				@$_REQUEST['motd'];
		$_SESSION['gamecp']['orderDetails']['hostname'] =			@$_REQUEST['hostname'];
		$_SESSION['gamecp']['orderDetails']['website'] =			@$_REQUEST['website'];
		$_SESSION['gamecp']['orderDetails']['password']=			$Order->whitelist($_REQUEST['password'], "clean");
	}

	if($_SESSION['gamecp']['orderDetails']['existingcustomer'] == false){

		if(isset($_REQUEST['email']))		$_SESSION['gamecp']['orderDetails']['email'] =		$Order->whitelist($_REQUEST['email'], "useredit");

		$email=$Order->whitelist($_SESSION['gamecp']['orderDetails']['email'], "useredit");

		$badname = false;
		$badmail = false;
		$checkoverride=false;

		// - 1.4 is email based, users auto gen: if($Order->CheckName($username) > 0) $badname = true;
		if($Order->CheckEmail($email) > 0)	 $badmail = true;
	} else $checkoverride=true;
//|| $username == $password
	if ($checkoverride == false && ($badmail == true || $badname == true )) { 
		/* User is bad or taken, retry username */
		//$smarty->assign("badname", $badname);
		$smarty->assign("badmail", $badmail);
		$smarty->assign("email", $Order->whitelist($email, "useredit"));
		//$smarty->assign("username", $Order->whitelist($username, "clean"));
		$smarty->assign("password", $Order->whitelist($password, "clean"));

		$smarty->display("order/retry.tpl");

	} else { 
		/* all regular data passed - check if maxmind support */
		if($mode == "checkmaxmind" && (!isset($_SESSION['gamecp']['orderDetails']['existingcustomer']) || $_SESSION['gamecp']['orderDetails']['existingcustomer'] == false)){
			if(maxEnable != "no" || maxPhoneAuth != "no"){
				require_once($PATH."/includes/core/classes/maxmind/maxmind.php");
				$fraudFailed=maxmind();

				if($fraudFailed == true){
					$smarty->assign("othererror", $fraudError);
					$smarty->assign("fraudFailed", "true");
					$smarty->display("order/retry.tpl");
					$Order->AddToQueue();
				} else {
					if(maxPhoneAuth == "yes"){
						/* validate phone call */
						$smarty->display("order/maxmindtelephone.tpl");
					} else $mode = "doPayment"; 
				}
			}
			if(subuno == "yes"){
				require_once($PATH."/includes/core/classes/subuno/class.inc.php");
				$Subunuo=new Subunuo();
				if($error=$Subunuo->validate($_SESSION['gamecp']['orderDetails'])){
					$smarty->assign("othererror", "Failed to pass anti-fraud verification, $error");
					$smarty->assign("fraudFailed", "true");
					$smarty->display("order/retry.tpl");
					$Order->AddToQueue();
				} else $mode = "doPayment"; 
			}
		} else $mode = "doPayment"; 
	} // ends the else
} // end checkuser	
	
/* phone auth validates the code given in the call vs session */
if($mode == "maxmindtelephone") {
	if($_REQUEST['callCode'] == $_SESSION['gamecp']['orderDetails']['callCode']){
		$mode = "doPayment";
	} else $smarty->display("order/maxmindtelephone.tpl");
}

// This is the 'primary' mode to do payments, based on this mode it will take the paymentMethod and do what it says.
if($mode == "doPayment") {
	$password=$Order->whitelist($_SESSION['gamecp']['orderDetails']['password'], "clean");
	$paymentMethod=$Order->whitelist($_SESSION['gamecp']['orderDetails']['paymentMethod'], "clean");
	if(!is_array($_SESSION['gamecp']['orderDetails'])) $Order->Error($LNG_MISSINGDETAILS);
	$qid=$Order->AddToQueue();
	$_SESSION['gamecp']['orderDetails']['qid'] = $qid;
	if(!$_SESSION['gamecp']['orderDetails']['qid']) $Order->Error($LNG_ORDERFAILED);
	$orderDetails=$_SESSION['gamecp']['orderDetails'];


	if((taxEnable == "yes" && !isset($_SESSION['gamecp']['orderDetails']['taxtotal'])) && (isset($_SESSION['gamecp']['orderDetails']['existingcustomer']) && (isset($_SESSION['gamecp']['orderDetails']['taxeduser']) && $_SESSION['gamecp']['orderDetails']['taxeduser'] == "1") || (!isset($_SESSION['gamecp']['orderDetails']['existingcustomer']) || $_SESSION['gamecp']['orderDetails']['existingcustomer']==false))){
		$Order->Taxes();
		$_SESSION['gamecp']['orderDetails']['packageGross']=$_SESSION['gamecp']['orderDetails']['packageGross']+$_SESSION['gamecp']['orderDetails']['taxtotal'];
		$smarty->assign('taxitems', $_SESSION['gamecp']['orderDetails']['taxes']);
	}
	
	if(isset($_SESSION['gamecp']['orderDetails']['existingcustomercredit']) && $_SESSION['gamecp']['orderDetails']['existingcustomercredit']){
		$credit=$_SESSION['gamecp']['orderDetails']['existingcustomercredit'];
		$totalDue=$_SESSION['gamecp']['orderDetails']['packageGross'];
		if($credit > 0){
			if($credit >= $totalDue){
				$acctcredit=$totalDue;
				$free=true;
				$totalDue="0";

			} else {
				$totalDue=$totalDue-$credit;
				$acctcredit=$credit;
			}
			$_SESSION['gamecp']['orderDetails']['packageGross']=$totalDue;
			if($acctcredit > 0){
				$GameCP->loadIncludes("billing");
				$Billing=new Billing(); 

				$Billing->CreditDedeuctUser($_SESSION['gamecp']['orderDetails']['userid'], $acctcredit);
			}
		}

		unset($_SESSION['gamecp']['orderDetails']['existingcustomercredit']);
	}

	foreach($orderDetails as $o => $i) @define($o, $i);
	$urlstring= "";
	$info['gross']=			$Order->FormatNumber($_SESSION['gamecp']['orderDetails']['packageGross']);
	$info['plaingross']=	$Order->RemFormatNumber($_SESSION['gamecp']['orderDetails']['packageGross']);
	$info['firstname']=		$_SESSION['gamecp']['orderDetails']['firstname'];
	$info['lastname']=		$_SESSION['gamecp']['orderDetails']['lastname'];
	$info['address']=		$_SESSION['gamecp']['orderDetails']['address'];
	$info['address2']=		$_SESSION['gamecp']['orderDetails']['address2'];
	$info['email']=			$_SESSION['gamecp']['orderDetails']['email'];
	$info['phone']=			$_SESSION['gamecp']['orderDetails']['phone'];
	$info['city']=			$_SESSION['gamecp']['orderDetails']['city'];
	$info['state']=			$_SESSION['gamecp']['orderDetails']['state'];
	$info['country']=		$_SESSION['gamecp']['orderDetails']['country'];
	$info['zip']=			$_SESSION['gamecp']['orderDetails']['zip'];
	$info['password']=		$_SESSION['gamecp']['orderDetails']['password'];
	$info['qid']=			$_SESSION['gamecp']['orderDetails']['qid'];
	$info['packageName']=	$_SESSION['gamecp']['orderDetails']['packageName'];
	$info['packageSlots']=	$_SESSION['gamecp']['orderDetails']['packageSlots'];
	$info['packageTerm']=	$_SESSION['gamecp']['orderDetails']['packageTerm'];


	$hook_vars='';
	run_hook("order_dopayment");

	$bid="1";

	$smarty->assign("orderform","true");
	$smarty->assign("info",array($info));
	$smarty->assign("bid",$bid);
	$smarty->assign("qid",$qid);
	$smarty->assign('urlstring', $urlstring);
	$smarty->assign('encodedstring', urlencode(base64_encode($urlstring)));
	$smarty->assign('return', "/order/index.php");
	$smarty->assign('MAILINGADDRESS', nl2br(MAILINGADDRESS));
	$smarty->assign("today", time());

	if(isset($_SERVER['REMOTE_ADDR'])) $hostname = @gethostbyaddr($_SERVER['REMOTE_ADDR']);
	$smarty->assign('hostname', $hostname);

	if(paypalSubscriptions == "yes")$smarty->assign("paypalSubscriptions", "true");
	if(maxEnable == "yes")			$smarty->assign("maxEnable", "true");
	if(maxPhoneAuth == "yes")		$smarty->assign("maxPhoneAuth", "true");
	
	if($_SESSION['gamecp']['orderDetails']['packageTerm'] == "monthly") { $monthlyterm="1"; } else
	if($_SESSION['gamecp']['orderDetails']['packageTerm'] == "quarterly") { $monthlyterm="3"; } else
	if($_SESSION['gamecp']['orderDetails']['packageTerm'] == "semiannualy") { $monthlyterm="6"; } else
	if($_SESSION['gamecp']['orderDetails']['packageTerm'] == "annauly") { $monthlyterm="12"; } else
	if($_SESSION['gamecp']['orderDetails']['packageTerm'] == "2years") { $monthlyterm="24"; } else $monthlyterm="1"; 

	$GameCP->loadIncludes("billing");
	$Billing=new Billing(); 
	$Billing->InvoiceDescription('order', $info);


	$smarty->assign("monthlyterm", $monthlyterm);
	$smarty->display("billing/tos.tpl");

	if($_SESSION['gamecp']['orderDetails']['packageGross'] == "0.00"){
		$smarty->display("billing/payment-free.tpl");
		$_SESSION['gamecp']['orderDetails']['freeorder']=true;
	} else {

		if(!$paymentMethod) $Order->Error($LNG_SELECTPAYMENT); 
		
		$Order->LoadGateway($paymentMethod);

		$gateway=$Order->GetGateways($paymentMethod);
		$gateway=$gateway[0];
		$smarty->assign('gatewayTesting', $gateway['testing']);
		$smarty->assign('value1', $gateway['value1']);
		$smarty->assign('value2', $gateway['value2']);
		$smarty->assign('value3', $gateway['value3']);
		$smarty->assign('privkey', urlencode(md5($gateway['value1'].$bid)));
		$smarty->assign('gateway', $gateway);

		$smarty->display("gateways/".$paymentMethod."/form.tpl");
	}

	$_SESSION['gamecp']['orderDetails']['last_mode']=$_SERVER['QUERY_STRING'];

	$Event->EventLogAdd($_SESSION['gamecp']['orderDetails']['email'], "Order Page Viewd by IP: ". $_SERVER['REMOTE_ADDR']." Hostname: $hostname  Product View: ". serialize($_SESSION));
	
}

if($finishSetup == "finishsetup") {

	$hook_vars='';
	run_hook("order_finishsetup");
	
	if(isset($_SESSION['gamecp']['orderDetails']['freeorder'])) unset($_SESSION['gamecp']['orderDetails']['freeorder']);

	$Event->EventLogAdd($_SESSION['gamecp']['orderDetails']['email'], "Finish Order Page Viewd by IP: ". $_SERVER['REMOTE_ADDR']." Product View: ". serialize($_SESSION));
	if($orderStatus == "Completed"){
		if($_SESSION['gamecp']['orderDetails']['qid']){
			$qInfo=$Order->GetQueueStatus();
			if($qInfo[1] == "3"){
				$mod=unserialize($qInfo[2]);
				if($paidPrice >= $_SESSION['gamecp']['orderDetails']['packageGross']){
					$mod['status']="Completed";
				} else $mod['status']="Pending";
				$mod['paidPrice']=$paidPrice;
				if(isset($paidFee)) $mod['fee']=$paidFee;
				if(isset($transactionid)) $mod['transactionid']=$transactionid;
				if(isset($subscr_idALT)) $mod['subscr_id']=$subscr_idALT;
				sql_query($safesql->query("UPDATE queue SET `mod`='%s', `status`='0' where id='%i'", array(serialize($mod), $GameCP->whitelist($_SESSION['gamecp']['orderDetails']['qid'], "int")))) or die(mysql_error()); 
				$GameCP->loadIncludes("panel");
				$Panel=new Panel();
				$Panel->ExecQueue($_SESSION['gamecp']['orderDetails']['qid']);
				$Order->Complete(emailNotify, $mod);
			}
			unset($_SESSION['gamecp']['orderDetails']['qid']);
		}
		$smarty->assign("femail", $_SESSION['gamecp']['orderDetails']['email']);
		$smarty->display("order/order-completed.tpl");
	}elseif($orderStatus == "Pending"){
		$emailtpl="Payment-Pending";
		$smarty->assign("femail", $_SESSION['gamecp']['orderDetails']['email']);
		$smarty->display("order/queued-page.tpl");
	}else{
		$emailtpl="Payment-Failed";
		$smarty->assign("femail", $_SESSION['gamecp']['orderDetails']['email']);
		$smarty->display("order/failed-page.tpl");
	}

	if(isset($emailtpl)){
		if(!isset($paidPrice)) $paidPrice="0";
		if(!isset($responseMessage)) $responseMessage='';

		$extravars=array();
		$extravars[]=array("var" => "\$Var1", "value" => "Order");
		$extravars[]=array("var" => "\$Var2", "value" => $_SESSION['gamecp']['orderDetails']['qid']);
		$extravars[]=array("var" => "\$Var3", "value" => $responseMessage);
		$extravars[]=array("var" => "\$cid", "value" => "");
		$extravars[]=array("var" => "\$Status", "value" => $orderStatus);
		$extravars[]=array("var" => "\$Payment", "value" => $paidPrice);

		$GameCP->loadIncludes('email');
		$Email = new Email();
		$Email->templatename = $emailtpl."-Queue";
		$Email->GetTemplateStuff();
		$Email->ReplaceStuff($extravars);
		$Email->SendtoAllManagers();
	}
}

$smarty->display("order/footer.tpl");
$smarty->display("footers/external.tpl");

?>