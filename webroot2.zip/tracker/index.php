<?php 
$noheader = true;
require("../includes/config.inc.php");
if( !function_exists("imagecopymerge") ) 
{
    exit( "Missing gd functions" );
}

if( !$q ) 
{
    header("location: ../index.php");
    exit();
}

$map = "n/a";
$hostname = "n/a";
$ipport = "n/a";
$status = "down";
$total = "0";
$active = "0";
$GameCP->loadIncludes("game");
$Game = new Game();
$GameCP->loadIncludes("query");
$Query = new Query();
$serviceInfo = $Game->GetService($GameCP->whitelist($_REQUEST["q"]));
$serverStatus = $Query->GameQ($GameCP->whitelist($_REQUEST["q"]));
if( !is_array($serviceInfo) || !is_array($serverStatus) ) 
{
    exit();
}

$lastplayers = unserialize($serviceInfo["lastplayers"]);
if( is_array($lastplayers) ) 
{
    $player_usage = $lastplayers[10];
}
else
{
    $player_usage = array(  );
}

if( isset($serverStatus[0]) ) 
{
    $total = $serverStatus[0];
}

if( isset($serverStatus[1]) ) 
{
    $active = $serverStatus[1];
}

if( isset($serverStatus[2]) ) 
{
    $status = $serverStatus[2];
}

if( isset($serverStatus[5]) ) 
{
    $ipport = $serverStatus[5];
}

if( isset($serverStatus[6]) ) 
{
    $map = $serverStatus[6];
}

if( isset($serverStatus[7]) ) 
{
    $hostname = substr($serverStatus[7], 0, 38);
}

$ip = $serviceInfo["ip"];
$port = $serviceInfo["port"];
$ipport = substr($ipport, "0", "20");
$x = "80";
$w = "525";
$font_file = "fonts/verdana_0.ttf";
$font_fileb = "fonts/verdanab_0.ttf";
$fontsize = "11";
$x_gap = 10;
$y_max = 60;
$x1 = 400;
$y1 = 20;
if( isset($s) ) 
{
    if( $s == "s" ) 
    {
        $fontsize = "8";
        $image_height = "20";
        $image_width = "350";
        $x_gap = 2.2;
        $y_max = 17;
        $x1 = 268;
        $y1 = 8;
        $my_img = imagecreatetruecolor($image_width, $image_height);
        list($r, $g, $b) = hex2rgb("#" . $GameCP->whitelist($t));
        $text_colour = imagecolorallocate($my_img, $r, $g, $b);
        list($r, $g, $b) = hex2rgb("#" . $GameCP->whitelist($gl));
        $line_colour = imagecolorallocate($my_img, $r, $g, $b);
        list($r, $g, $b) = hex2rgb("#" . $GameCP->whitelist($_REQUEST["b"]));
        $bordercolors = imagecolorallocate($my_img, $r, $g, $b);
        list($r, $g, $b) = hex2rgb("#" . $GameCP->whitelist($gbg));
        $statbg = imagecolorallocatealpha($my_img, $r, $g, $b, 75);
        $statborder = imagecolorallocate($my_img, 98, 64, 20);
        $online = imagecolorallocate($my_img, 36, 255, 0);
        $offline = imagecolorallocate($my_img, 255, 0, 0);
        list($r1, $g1, $b1) = hex2rgb("#" . $bg1);
        list($r2, $g2, $b2) = hex2rgb("#" . $GameCP->whitelist($bg2));
        for( $i = 0; $i < $image_height; $i++ ) 
        {
            $r = $r2 - $r1 != 0 ? intval($r1 + ($r2 - $r1) * $i / $image_height) : $r1;
            $g = $g2 - $g1 != 0 ? intval($g1 + ($g2 - $g1) * $i / $image_height) : $g1;
            $b = $b2 - $b1 != 0 ? intval($b1 + ($b2 - $b1) * $i / $image_height) : $b1;
            $fill = imagecolorallocate($my_img, $r, $g, $b);
            imageline($my_img, 0, $i, $image_width, $i, $fill);
        }
        if( $status == "up" ) 
        {
            $onoff = $online;
        }
        else
        {
            $onoff = $offline;
            $hostname = "Server is offline";
        }

        imagefilledrectangle($my_img, 20, 4, 24, 15, $statborder);
        imagefilledrectangle($my_img, 21, 5, 23, 14, $onoff);
        imagefttext($my_img, 7, 0, 26, 8, $text_colour, $font_file, $hostname);
        imagefttext($my_img, $fontsize, 0, 26, 18, $text_colour, $font_fileb, "" . $ipport . " " . $active . "/" . $total . " " . $map);
        if( is_file("logo.png") ) 
        {
            $src = imagecreatefrompng("logo.png");
            imagecopymerge_alpha($my_img, $src, 330, 0, 0, 0, 18, 20, 100);
        }

        if( is_file("icons/" . $serviceInfo["gameQcode"] . ".gif") ) 
        {
            $src = imagecreatefromgif("./icons/" . $serviceInfo["gameQcode"] . ".gif");
            imagecopymerge_alpha($my_img, $src, 2, 2, 0, 0, 16, 16, 100);
        }

        imagefilledrectangle($my_img, 270, 2, 320, 17, $statbg);
        if( 16 < max($player_usage) ) 
        {
            $reduction = round(max($player_usage) / 16, "1");
        }

        $recution = "0";
        for( $i = "0"; $i < 24; $i++ ) 
        {
            $x2 = $x1 + $x_gap;
            $time = date("H") - $i;
            if( $time < 0 ) 
            {
                $time = $time + 24;
            }

            if( isset($player_usage[$time]) ) 
            {
                $point = round($player_usage[$time] / $reduction);
            }
            else
            {
                $point = 0;
            }

            $y2 = $y_max - $point;
            if( $i != "0" ) 
            {
                imageline($my_img, $x1, $y1, $x2, $y2, $line_colour);
            }

            $x1 = $x2;
            $y1 = $y2;
        }
    }
    else
    {
        if( $s == "l" ) 
        {
            $fontsize = "9";
            $titlesize = "7";
            $image_height = "95";
            $image_width = "560";
            $x_gap = 4.5;
            $y_max = 50;
            $x1 = 442;
            $y1 = 30;
            if( is_file("../includes/copyright.php") ) 
            {
                $slogan = domainName;
            }
            else
            {
                $slogan = "Managed with GameCP";
            }

            if( is_file("./bg/" . $serviceInfo["gameQcode"] . ".png") ) 
            {
                $my_img = imagecreatefrompng("./bg/" . $serviceInfo["gameQcode"] . ".png");
            }
            else
            {
                $my_img = imagecreatetruecolor("560", "95");
            }

            list($r, $g, $b) = hex2rgb("#" . $GameCP->whitelist($tc));
            $title_color = imagecolorallocate($my_img, $r, $g, $b);
            list($r, $g, $b) = hex2rgb("#" . $GameCP->whitelist($ts));
            $title_shadow = imagecolorallocate($my_img, $r, $g, $b);
            list($r, $g, $b) = hex2rgb("#" . $GameCP->whitelist($t));
            $text_colour = imagecolorallocate($my_img, $r, $g, $b);
            list($r, $g, $b) = hex2rgb("#" . $GameCP->whitelist($gl));
            $line_colour = imagecolorallocate($my_img, $r, $g, $b);
            list($r, $g, $b) = hex2rgb("#" . $GameCP->whitelist($_REQUEST["b"]));
            $bordercolors = imagecolorallocate($my_img, $r, $g, $b);
            list($r, $g, $b) = hex2rgb("#" . $GameCP->whitelist($gbg));
            $statbg = imagecolorallocatealpha($my_img, $r, $g, $b, 30);
            $statborder = imagecolorallocate($my_img, 98, 64, 20);
            $online = imagecolorallocate($my_img, 36, 255, 0);
            $white = imagecolorallocate($my_img, 255, 255, 255);
            $offline = imagecolorallocate($my_img, 255, 0, 0);
            if( $status == "up" ) 
            {
                $onoff = $online;
                $onofftxt = "Online";
            }
            else
            {
                $onoff = $offline;
                $onofftxt = "Offline";
                $hostname = "Server is offline";
            }

            imagefttext($my_img, $titlesize, 0, 113, 15, $title_shadow, $font_fileb, "SERVER NAME:");
            imagefttext($my_img, $titlesize, 0, 112, 14, $title_color, $font_fileb, "SERVER NAME:");
            imagefttext($my_img, $titlesize, 0, 422, 15, $title_shadow, $font_fileb, "PLAYER HISTORY");
            imagefttext($my_img, $titlesize, 0, 423, 14, $title_color, $font_fileb, "PLAYER HISTORY");
            imagefttext($my_img, $fontsize, 0, 112, 28, $text_colour, $font_fileb, $hostname);
            imagefttext($my_img, $titlesize, 0, 113, 42, $title_shadow, $font_fileb, "IP ADDRESS:PORT");
            imagefttext($my_img, $titlesize, 0, 112, 41, $title_color, $font_fileb, "IP ADDRESS:PORT");
            imagefttext($my_img, $fontsize, 0, 112, 56, $text_colour, $font_fileb, $ip . ":" . $port);
            imagefttext($my_img, $titlesize, 0, 303, 42, $title_shadow, $font_fileb, "STATUS:");
            imagefttext($my_img, $titlesize, 0, 302, 41, $title_color, $font_fileb, "STATUS:");
            imagefttext($my_img, $fontsize, 0, 302, 56, $onoff, $font_fileb, $onofftxt);
            imagefttext($my_img, $titlesize, 0, 143, 70, $title_shadow, $font_fileb, "PLAYERS:");
            imagefttext($my_img, $titlesize, 0, 142, 69, $title_color, $font_fileb, "PLAYERS:");
            imagefttext($my_img, $fontsize, 0, 142, 83, $text_colour, $font_fileb, "" . $active . "/" . $total);
            imagefttext($my_img, $fontsize, 0, 143, 83, $text_colour, $font_fileb, "" . $active . "/" . $total);
            imagefttext($my_img, $titlesize, 0, 303, 70, $title_shadow, $font_fileb, "CURRENT MAP:");
            imagefttext($my_img, $titlesize, 0, 302, 69, $title_color, $font_fileb, "CURRENT MAP:");
            imagefttext($my_img, $fontsize, 0, 302, 83, $text_colour, $font_fileb, $map);
            if( is_file("logo.png") ) 
            {
                $src = imagecreatefrompng("logo.png");
                imagecopymerge_alpha($my_img, $src, 422, 69, 0, 0, 18, 20, 100);
                imagefttext($my_img, "7", 0, 442, 82, $text_colour, $font_fileb, $slogan);
            }

            imagefilledrectangle($my_img, 422, 20, 555, 58, $statbg);
            imagefttext($my_img, "6", 0, 428, 28, $white, $font_file, max($player_usage));
            if( 0 < round(max($player_usage) / 2) ) 
            {
                imagefttext($my_img, "6", 0, 428, 41, $white, $font_file, round(max($player_usage) / 2));
            }

            imagefttext($my_img, "6", 0, 428, 55, $white, $font_file, "0");
            imageline($my_img, 443, 25, 443, 55, $white);
            imageline($my_img, 453, 52, 453, 55, $white);
            imageline($my_img, 463, 52, 463, 55, $white);
            imageline($my_img, 473, 52, 473, 55, $white);
            imageline($my_img, 483, 52, 483, 55, $white);
            imageline($my_img, 493, 52, 493, 55, $white);
            imageline($my_img, 503, 52, 503, 55, $white);
            imageline($my_img, 513, 52, 513, 55, $white);
            imageline($my_img, 523, 52, 523, 55, $white);
            imageline($my_img, 533, 52, 533, 55, $white);
            imageline($my_img, 543, 52, 543, 55, $white);
            imageline($my_img, 440, 25, 443, 25, $white);
            imageline($my_img, 440, 38, 443, 38, $white);
            imageline($my_img, 440, 52, 550, 52, $white);
            if( 16 < max($player_usage) ) 
            {
                $reduction = round(max($player_usage) / 16, "1");
            }

            $recution = "0";
            for( $i = "0"; $i < 24; $i++ ) 
            {
                $x2 = $x1 + $x_gap;
                $time = date("H") - $i;
                if( $time < 0 ) 
                {
                    $time = $time + 24;
                }

                if( isset($player_usage[$time]) ) 
                {
                    $point = round($player_usage[$time] / $reduction);
                }
                else
                {
                    $point = 0;
                }

                $y2 = $y_max - $point;
                if( $i != "0" ) 
                {
                    imageline($my_img, $x1, $y1, $x2, $y2, $line_colour);
                }

                $x1 = $x2;
                $y1 = $y2;
            }
            imagefilledarc($my_img, 124, 74, 20, 20, 0, 360, $online, IMG_ARC_PIE);
            imagefilledarc($my_img, 124, 74, 20, 20, round($active * 360 / $total), 360, $offline, IMG_ARC_PIE);
        }

    }

    $x = 0;
    $y = 0;
    $w = imagesx($my_img) - 1;
    $h = imagesy($my_img) - 1;
    imageline($my_img, $x, $y, $x, $y + $h, $bordercolors);
    imageline($my_img, $x, $y, $x + $w, $y, $bordercolors);
    imageline($my_img, $x + $w, $y, $x + $w, $y + $h, $bordercolors);
    imageline($my_img, $x, $y + $h, $x + $w, $y + $h, $bordercolors);
    header("Content-type: image/png");
    imagepng($my_img);
    imagecolordeallocate($line_color);
    imagecolordeallocate($text_colour);
    imagecolordeallocate($background);
    imagedestroy($my_img);
}
else
{
    if( isset($_REQUEST["q"]) ) 
    {
        $map = $serverStatus[6];
        $mapimgdir = $serviceInfo["mapimgdir"];
        $smarty->assign("showmap", $Game->MapImage($mapimgdir, $map));
        $smarty->assign("serviceInfo", $serviceInfo);
        $smarty->assign("serverStatus", $serverStatus);
        $smarty->display("tracker/tracker.tpl");
    }

}

function hex2rgb($color)
{
    $color = str_replace("#", "", $color);
    $s = strlen($color) / 3;
    $rgb[] = hexdec(str_repeat(substr($color, 0, $s), 2 / $s));
    $rgb[] = hexdec(str_repeat(substr($color, $s, $s), 2 / $s));
    $rgb[] = hexdec(str_repeat(substr($color, 2 * $s, $s), 2 / $s));
    return $rgb;
}

function imagecopymerge_alpha($dst_im, $src_im, $dst_x, $dst_y, $src_x, $src_y, $src_w, $src_h, $pct)
{
    $cut = imagecreatetruecolor($src_w, $src_h);
    imagecopy($cut, $dst_im, 0, 0, $dst_x, $dst_y, $src_w, $src_h);
    imagecopy($cut, $src_im, 0, 0, $src_x, $src_y, $src_w, $src_h);
    imagecopymerge($dst_im, $cut, $dst_x, $dst_y, 0, 0, $src_w, $src_h, $pct);
}



